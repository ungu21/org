<?php

die('OK');

?>