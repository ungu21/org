<?php $__env->startSection('title', 'Testimonial | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Kebijakan Privasi
          </h1>
          <p style="color:#fff">Testimonial</p>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                    <?php if(count($testimonials) == 0): ?>
                       <h3>Belum ada testimonial</h3>
                    <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                          <div class="card mt-4 card-primary wow zoomInUp animation-delay-7" style="visibility: hidden; animation-name: none;">
                            <div class="ms-hero-bg-primary ms-hero-img-coffee">
                                <?php if($data->user->image != null): ?>
                                    <img src="<?php echo e(asset('admin-lte/dist/img/avatar/'.$data->user->image)); ?>" alt="<?php echo e($data->user->name); ?>" class="img-avatar-circle profile" data-name="<?php echo e($data->user->name); ?>"> </div>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('admin-lte/dist/img/avatar5.png')); ?>" class="img-avatar-circle profile" data-name="<?php echo e($data->user->name); ?>"> </div>
                                <?php endif; ?>
                              
                            <blockquote class="blockquote mt-4">
                              <p><?php echo e($data->review); ?></p>
                              <footer>
                                <?php echo e($data->user->name); ?> (<?php echo e(substr($data->user->phone, 0, -3)); ?>XXX)
                              </footer>
                            </blockquote>
                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div> 
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebProgramming\WebpulsaNew\newpay\resources\views/testimoni.blade.php ENDPATH**/ ?>