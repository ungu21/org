
<?php $__env->startSection('title', '404 Halaman Tidak Ditemukan | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', 'Perkenalan singkat mengenai kami '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Puslsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/background/img-home.png')); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Slideshow Section -->
<section id="slideshow">
   <div class="container">
      <div class="row">
         <div class="no-slider" style="margin-top: 100px;">
            <div class="animate-block" style="text-align: center;">
            <div class="col-md-6 col-md-offset-3">
               <h2><span id="word-rotating">Halaman Tidak Ditemukan</span></h2>
               <p style="margin-top: 10px;margin-bottom: 80px;">Halaman yang anda cari tidak ditemukan.</p>
              </div>
            </div> <!--/ animate-block -->
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
</section>
<!-- End Slideshow Section -->

<!-- Start Feature Section -->
<section id="feature" class="padding-2x">
   <div class="container">
      <div class="row">
            <div align="center">
                <span style="font-size:150px;">404</span><br>
                <h2 style="font-weght:bold;">Halaman Tidak Ditemukan</h2>
                <p style="margin-bottom:10px;">Tautan yang anda ikuti mungkin telah rusak atau halaman telah dihapus.</p>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary"><i class="fa fa-home" style="margin-right:5px;"></i>Kembali Ke Halaman Home</a>
            </div>
        
      </div>
   </div>
</section>
<!-- End Feature Section -->
<section id="twitter-feed" class="grey-bg padding-1x">
   <div class="container">
      <div class="row">
         <div class="col-md-8 col-md-offset-2">
            <div class="section-heading text-center">
               <h2 class="title" style="font-style: italic;">"<?php echo e($GeneralSettings->motto); ?>"</h2>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mydn5829/system/resources/views/errors/404.blade.php ENDPATH**/ ?>