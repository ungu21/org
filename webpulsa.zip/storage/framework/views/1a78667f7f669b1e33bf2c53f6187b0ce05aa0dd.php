<?php $__env->startSection('title', $GeneralSettings->nama_sistem. ' | '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>
<?php $__env->startSection('img-back'); ?>
<?php $__env->startSection('style'); ?>
<style>
@media (max-width: 767px){
    .nav-tabs>li {
        width: 16.66%;
    }
}
</style>
<?php $__env->stopSection(); ?>
             <section id="isi-product" class="isi-product pulsa " style="background-image: url('images/background.png'); background-size: 100% auto; background-repeat: no-repeat;">
             <div class="overlay">&nbsp;</div>
              <div class="container v3">
              <div>
             <span>
                <h1 style="text-align:left;"><span style="/* color: rgb(255,255,255); */">Jual Isi Pulsa Online Murah,</span><br><span style="/* color: rgb(255,255,255); */">All Operator</span></h1>
             </span>
            </div>
            <div id="" class="product-tabs">
              <ul class="nav nav-tabs form-tabs" role="tablist">
                <?php $i=0; ?>
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i++; ?>
                  <li role="presentation" class="<?php echo e($i == 1?'active':''); ?>">
                    <a href="#<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" aria-controls="<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" role="tab" data-toggle="tab" title="<?php echo e($kt->product_name); ?>"><i class="fa fa-<?php echo e($kt->icon); ?>"></i><?php echo e($kt->product_name); ?></a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li role="presentation" class="">
                  <a href="#tagihan" aria-controls="tagihan" role="tab" data-toggle="tab" title="Tagihan"><i class="fa fa-building"></i>Tagihan</a>
                </li>
              </ul>
              <div class="panel-body" style="background: #fff;border-bottom-left-radius: 4px;border-bottom-right-radius: 4px;border-radius: 0 0 5px 5px;-webkit-border-radius: 0 0 5px 5px;-moz-border-radius: 0 0 5px 5px;-ms-border-radius: 0 0 5px 5px;-o-border-radius: 0 0 5px 5px;box-shadow: 0 2px 10px 0 rgba(0,0,0,.16);}">
                    <div class="tab-content">
                      <?php $i=0; ?>
                      <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $i++; ?>
                        <div role="tabpanel" class="tab-pane <?php echo e($i == 1?'active':''); ?>" id="<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>">
                              <?php if(in_array(strtoupper($kt->type), ["REGULER","INTERNET","SMS","TRANSFER","LAIN","GAME"])): ?>
                                <div class="col-md-12">
                                  <div class="field-container input-bg input-phone">
                                    <input name="target" id="target_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" type="number" class="field" placeholder="No Pengisian" required="required" autocomplete="off" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==14) return false;">
                                    <label for="No Pengisian" class="floating-label">No Pengisian</label>
                                  </div>
                                </div>
                                 <div class="col-md-6">
                                      <div class="field-container input-bg">
                                      <select id="provider_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" name="provider_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" class="field" required="required">
                                        <option>Pilih Provider</option>
                                        <?php $__currentLoopData = $kt->pembelianoperator->sortBy('product_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <option value="<?php echo e($data->id); ?>"><?php echo e($data->product_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                      <label for="Provider" class="floating-label">Provider</label>
                                     </div>
                                 </div>
                                 <div class="col-md-6">
                                      <div class="field-container input-bg">
                                      <select id="product_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" name="product_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" class="field" required="required">
                                        <option>Pilih Produk</option>
                                      </select>
                                      <label for="Produk" class="floating-label">Produk</label>
                                     </div>
                                 </div>
                              <?php elseif(in_array(strtoupper($kt->type), ["PLN"])): ?>
                                <div class="col-md-12">
                                  <div class="field-container input-bg input-phone">
                                    <input name="target" id="target_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" type="number" class="field" placeholder="No Pengisian" required="required" autocomplete="off">
                                    <label for="No Pengisian" class="floating-label">No Pengisian</label>
                                  </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="field-container input-bg">
                                    <select id="product_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" name="product_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" class="field" required="required">
                                      <option>Pilih Produk</option>
                                      <?php $__currentLoopData = $produkPLN; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($produk->product_id); ?>"><?php echo e($produk['product_name']); ?> (Rp <?php echo e(number_format($produk['price'], 0, '.', '.')); ?>)</option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="Produk" class="floating-label">Produk</label>
                                   </div>
                                 </div>
                                 <div class="col-md-6">
                                  <div class="field-container input-bg">
                                    <input id="target_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" name="np_hp" type="number" class="field id_plgn" placeholder="Nomor Handphone Pembeli" required="required" maxlength="64" autocomplete="off">
                                    <label for="Nomor Handphone" class="floating-label">Nomor Handphone Pembeli</label>
                                  </div>
                                  <label for="Product" class="floating-label">Product</label>
                                 </div>
                              <?php endif; ?>
                            <?php if((Auth::check())): ?>
                            <div class="col-md-6">
                                <div class="field-container input-bg input-password">
                                      <input id="pin_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" name="pin" type="number" class="field" placeholder="Masukkan PIN Anda" required="required" autocomplete="off" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==4) return false;">
                                      <label for="PIN" class="floating-label">PIN</label>
                                </div>
                                <button id="btn_<?php echo e(str_replace(' ','',strtolower($kt->product_name))); ?>" class="btn btn-lg btn-primary">BELI SEKARANG</button>
                            </div>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>"><button class="btn btn-lg btn-primary">BELI SEKARANG</button></a>
                            <?php endif; ?>
                        </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>       
              </div>
            </div>
         </div>
      </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    @media  screen and (max-width: 780px) {
        .table{
            font-size:12px;
        }
    }
</style>

<style>
  .post-content p {
      font-size: 1em;
      line-height: 1.7;
      margin-bottom: 10px;
  }

  p {
      margin: 0 0 9.5px;
  }
  p {
      display: block;
      -webkit-margin-before: 1em;
      -webkit-margin-after: 1em;
      -webkit-margin-start: 0px;
      -webkit-margin-end: 0px;
  }
  .entry-title, .entry-title a {
      font-family: "Roboto Slab", "Open Sans", sans-serif !important;
      font-size: 1.25em;
      font-weight: bold;
      margin-bottom: 25px;
  }
</style>

      <div class="temp-wrap">
         <section id="benefit" class="benefit">
            <div class="container">
              <div id="post-content  post-content--narrow">
                <h3 class="post-content__title  entry-title center">Mengapa memilih kami?</h3>
              </div>
               <p class="post-content__text">Kami merupakan salah satu server pulsa elektrik termurah yang ada di Indonesia, Sebagai distributor pulsa peran kami adalah mempermudah bisnis pulsa menjadi lebih sederhana dengan sistem Multichip, yang artinya anda tidak perlu lagi banyak chip dan ponsel untuk tiap-tiap operator, karena kami telah menyediakan berbagai sistem pengisian pulsa seperti Website, WebApps, Aplikasi Messanger dan API untuk melakukan pengisian pulsa All Operator, Pembayaran PLN Prabayar, Voucher Game Online dll</p>
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-easy">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">Pendaftaran Gratis Dan Mudah</h3>
                       <p class="post-content__text">Tanpa biaya pendaftaran 100% Gratis, setelah mendaftar akun anda langsung aktif dan dapat melakukan deposit.</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-practice">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">Transaksi Otomatis 24 Jam</h3>
                       <p>Tengah malam kamu masih bisa melakukan transaksi Pulsa, Paket Internet, Paket SMS, Token PLN, dan Voucher Game.</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-voucher">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">Jalur Trasanksi Online</h3>
                       <p>Kami menyediakan beberapa jalur transaksi online, dijamin tanpa biaya sms, yaitu transaksi via Website dan WebApps.</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                         <h3 class="post-content__title  entry-title center">Produk Pulsa Paling Lengkap</h3>
                         <p>Tersedia Produk yang lengkap seperti Pulsa All Oprator, Paket Data, Voucher Game, Token PLN, Pembayaran PPOB, Dll</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">Harga Terbaik dan Terpercaya</h3>
                       <p>Kami terus melakukan inovasi dan penambahan fitur, sehingga transaksi semakin lancar dengan harga paling murah.</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">WebApps</h3>
                       <p>Memiliki Fitur WebApps yang menyerupai aplikasi android tetapi tidak perlu untuk mendownload dan tidak boros memori.</p>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">SMS Buyer</h3>
                       <p>SMS Buyer merupakan notifikasi berupa pesan singkat yang akan terkirim kepada pembeli jika transaksi yang di lakukan sukses.</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                      <div id="post-content  post-content--narrow">
                       <h3 class="post-content__title  entry-title center">Refund Transaksi</h3>
                       <p>Pengembalian Saldo jika transaksi yang dilakukan mendapatkan status sukses tetapi pulsa/produk belum masuk kepada pembeli.</p>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-6 col-lg-4">
                     <div class="benefit-img benefit-secure">&nbsp;</div>
                       <div class="block-icon">
                          <span class="icon-chat fa-3x"></span>
                       </div>
                       <h3 class="post-content__title  entry-title center">Bantuan CS Ramah</h3>
                       <p>Kami menyediakan beberapa tempat bertanya atau komplain mulai dari live chat, telegram, whatsapp, facebook dan telpon.</p>
                     </div>
                  </div>
               </div>
            </div>
         </section>
         <section id="content-highlight" class="product-info">
           <div class="container">
              <div class="row">
                 <div class="col-md-6 col-md-offset-3">
                    <div class="section-heading text-center">
                       <h2 class="title">Harga Produk</h2>
                       <p>Salah Satu Harga Produk Terbaik Kami. <br>Update <?php echo e(date("d-m-Y")); ?></p>
                    </div>
                 </div>
              </div>
              <div class="row">
                 <!-- item -->
                 <div class="col-sm-12 col-md-12 text-center">
                    <div class="panel-pricing popular">
                       <div class="price-heading">
                          <table class="table table-striped table-condensed">
                             <thead>
                                <tr>
                                   <th>Produk & Nominal</th>
                                   <th>Harga</th>
                                   <th>Status</th>
                                </tr>
                                
                             </thead>
                             <tbody align="left">
                                <?php if(isset($operator->pembelianproduk) && count($operator->pembelianproduk) > 0): ?>
                                <?php $__currentLoopData = $operator->pembelianproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($data->product_name); ?></td>
                                  <td>Rp <?php echo e(number_format($data->price, 0, '.', '.')); ?></td>
                                  <?php if($data->status == 1): ?>
                                  <td><p class="text-success">TERSEDIA</p></td>
                                  <?php else: ?>
                                  <td><p class="text-danger">GANGGUAN</p></td>
                                  <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                <?php else: ?>
                                <tr>
                                   <td colspan="3" align="center" style="font-style: italic;">Produk Belum Tersedia</td>
                                </tr>
                                <?php endif; ?>
                             </tbody>
                          </table>
                       </div>
                       <div class="panel-pricing-footer">
                          <a class="btn btn-view-all" href="<?php echo e(url('/price/pembelian/pulsa-all-operator')); ?>">Lihat Semua</a>
                       </div>
                    </div>
                 </div>
                 <!-- /item -->
              </div>
           </div>
         </section>

         <section id="content-highlight" class="product-info">
           <div class="container">
              <div class="row">
                 <div class="col-sm-6 col-md-6">
                    <!-- Start Contact Form -->
                    <div class="enquiry-box padding-2x">
                       <p style="font-size: 14px;">Jika ada pertanyaan, Pengaduan, Kritik dan Saran silahkan kirimkan pesan Anda di sini.</p style="font-size: 15px;">
                       <form id="contact-form" method="post" action="<?php echo e(url('/messages')); ?>" role="form" novalidate="true">
                       <?php echo e(csrf_field()); ?>

                          <?php if($errors->has('first_name') or $errors->has('last_name') or $errors->has('email') or $errors->has('message') or $errors->has('phone') ): ?>
                          <div class="alert alert-danger">
                                <span style="font-size: 12px;">Pesan tidak terkirim. Periksa kembali data yang anda input, baik dari penulisan dan format.</span>
                          </div>
                          <?php endif; ?>
                          <?php if(Session::has('alert-success')): ?>
                          <div class="alert alert-success">
                                <span style="font-size: 12px;"><?php echo e(Session::get('alert-success')); ?></span>
                          </div>
                          <?php endif; ?>
                          <div class="controls">
                             <div class="row">
                                <div class="col-md-6">
                                   <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                      <input name="first_name" class="form-control" placeholder="Masukkan Nama Depan *" required="required" data-error="Nama Depan tidak boleh kosong." type="text">
                                      <div class="help-block with-errors" style="font-size: 11px;"></div>
                                   </div>
                                </div>
                                <div class="col-md-6">
                                   <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                      <input name="last_name" class="form-control" placeholder="Masukkan Nama Belakang *" required="required" data-error="Nama Depan tidak boleh kosong." type="text">
                                      <div class="help-block with-errors" style="font-size: 11px;"></div>
                                   </div>
                                </div>
                             </div>
                             <div class="row">
                                <div class="col-md-6">
                                   <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                      <input name="email" class="form-control" placeholder="Masukkan Alamat Email *" required="required" data-error="Alamat Email tidak boleh kosong." type="email">
                                      <div class="help-block with-errors" style="font-size: 11px;"></div>
                                   </div>
                                </div>
                                <div class="col-md-6">
                                   <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                                      <input name="phone" class="form-control" placeholder="Masukkan Nomor Handphone *" required="required" data-error="Nomor Handphone tidak boleh kosong." type="text">
                                      <div class="help-block with-errors" style="font-size: 11px;"></div>
                                   </div>
                                </div>
                             </div>
                             <div class="row">
                                <div class="col-md-12">
                                   <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                                      <textarea name="message" class="form-control" placeholder="Masukkan Isi Pesan Anda *" rows="4" required="required" data-error="Pesan tidak boleh kosong."></textarea>
                                      <div class="help-block with-errors" style="font-size: 11px;"></div>
                                   </div>
                                </div>
                                <div class="col-md-12">
                                   <input class="btn btn-secondary btn-send disabled" value="Send message" type="submit">
                                </div>
                             </div>
                          </div>
                       </form>
                    </div>
                 </div>
                 <div class="col-sm-6 col-md-6">
                    <div class="contact-info padding-2x">
                       <div class="medium">
                          <div class="medium-left">
                             <i class="icon-map fa-3x" aria-hidden="true"></i>
                          </div>
                          <div class="medium-body">
                             <h4 class="medium-heading">Alamat</h4>
                             <p><?php echo e($GeneralSettings->alamat); ?></p>
                          </div>
                       </div>
                       <div class="medium">
                          <div class="medium-left">
                             <i class="icon-envelope fa-3x" aria-hidden="true"></i>
                          </div>
                          <div class="medium-body">
                             <h4 class="medium-heading">Email Kami</h4>
                             <p><a href="mailto:<?php echo e($GeneralSettings->email); ?>"><?php echo e($GeneralSettings->email); ?></a></p>
                          </div>
                       </div>
                       <div class="medium">
                          <div class="medium-left">
                             <i class="icon-lifesaver fa-3x" aria-hidden="true"></i>
                          </div>
                          <div class="medium-body">
                             <h4 class="medium-heading">Hotline Kami</h4>
                             <p><?php echo e($GeneralSettings->hotline); ?></p>
                          </div>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
         </section>
          

         <section class="download-separator hidden-xs">&nbsp;</section>
         <section id="download" class="download">
            <div class="container">
               <div class="download-text">
                  <p class="title">Download Aplikasi <?php echo e($GeneralSettings->nama_sistem); ?></p>
                  <!-- <p><?php echo e($GeneralSettings->motto); ?></p> -->
                  <div><a href="https://play.google.com/store/apps/details?id=apps.tripay.co.id" class="download-link googleplay">&nbsp;</a></div>
                  <h2 class="title" style="font-style: italic;"><p>"<?php echo e($GeneralSettings->motto); ?>"</p></h2>
               </div>
               <div class="download-img hidden-xs">&nbsp;</div>
            </div>
         </section>

      </div>
      
      


<!-- Modal -->
    <div aria-labelledby="myModalLabel" class="modal fade" id="myModal" role="dialog" tabindex="-1">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">×</span></button>
					<h4 class="text-center modal-title">Detail Tagihan</h4>
				</div>
				<div class="modal-body" id="modal_body">
					<div class="box-body" style="color: #6E6C6C">
						<form action="<?php echo e(route('bayartagihan')); ?>" id="boxresult" method="post" name="boxresult"></form>
					</div>
				</div>
				<div class="modal-footer" id="modal_footer"></div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<!--<script src="https://multireload.com/demo/sepulsa/assets/js/notify.min.js"></script>-->
<script>

 $(window).on('load', function() {  

    <?php if(Session::has('alert-success')): ?>
         toastr.success("<?php echo e(Session::get('alert-success')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-info')): ?>
         toastr.info("<?php echo e(Session::get('alert-info')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-warning')): ?>
         toastr.warning("<?php echo e(Session::get('alert-warning')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-error')): ?>
         toastr.error("<?php echo e(Session::get('alert-error')); ?>");
     <?php endif; ?>

    function rupiah(nStr) {
           nStr += '';
           x = nStr.split('.');
           x1 = x[0];
           x2 = x.length > 1 ? '.' + x[1] : '';
           var rgx = /(\d+)(\d{3})/;
           while (rgx.test(x1))
           {
              x1 = x1.replace(rgx, '$1' + '.' + '$2');
           }
           return "Rp " + x1 + x2;
    }

    Array.prototype.inArray = function (value)
    {
       var i;
       for (i=0; i < this.length; i++)
       {
       if (this[i] == value)
       {
       return true;
       }
       }
       return false;
    };

    var kategori = <?php echo json_encode($kategori); ?>;
    kategori.forEach(function(value) {

        var IDparam  = (value.product_name.toLowerCase()).replace(/\s+/g, '');
        var provider = "provider_"+IDparam;
        var target   = "target_"+IDparam;
        var butonpay = "btn_"+IDparam;

        // FOR GET PROVIDER
        $("#"+provider).on('change', function() {
            getProduct(IDparam, $("#"+provider).val());

        });

        // FOR GET TARGET
        var exception =["REGULER","INTERNET","TRANSFER","SMS"];
        if(exception.inArray(value.type)){
        //   console.log('type', value.type);
          $("#target_"+IDparam+"").on("input propertychange paste", function() {
             var parent = value.id;
             if ( $("#"+target).val().length > 3){
                 var prefix = $("#"+target).val().substring(0, 4);
                 getPulsa(prefix, IDparam, parent);
             }
             if ( $("#"+target).val().length == 0){
                 getOperator(IDparam, parent);
             }
          });
        }

        // FOR BUTTON PAY
        $("#"+butonpay).on('click', function() {
            var id_operator = $("#"+provider).val();
            var type        = value.type;
            beli(IDparam, type, id_operator);
        });

    });
    
    function getPulsa($prefix, $cat, $parent) {
            $('#product_'+$cat).append('<option value="" selected="selected">Loading...</option>');
            $('#provider_'+$cat).append('<option value="" selected="selected">Loading...</option>');
            $.ajax({
                url: 'process/prefixproduct',
                dataType: "json",
                type: "GET",
                data: {
                    'prefix': $prefix,
                    'parent': $parent
                },
                success: function (response) {
                    $('#product_'+$cat).empty();
                    $('#provider_'+$cat).empty();
                    $.each(response.produk, function(index, produkObj){
                        harga = parseInt(produkObj.price);
                        if (produkObj.status == 0) {
                            $('#product_'+$cat).append('<option value="'+produkObj.product_id+'" style="color: #C8C8C8;" disabled>'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                        }else{
                            $('#product_'+$cat).append('<option value="'+produkObj.product_id+'">'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                        }
                    });
                    $.each(response.operator, function(index, operatorObj){
                        if (operatorObj.status == 0) {
                            $('#provider_'+$cat).append('<option value="'+operatorObj.id+'" style="color: #C8C8C8;" disabled>'+operatorObj.product_name+'</option>');
                        }else{
                            $('#provider_'+$cat).append('<option value="'+operatorObj.id+'">'+operatorObj.product_name+'</option>');
                        }
                    });
                },
                error: function (response) {
                    toastr.error("Data tidak ditemukan, periksa kembali nomor handphone tujuan anda");
                        $('#provider_'+$cat).empty();
                        $('#provider_'+$cat).append('<option value="" selected="selected">Pilih Operator ...</option>');
                        $('#product_'+$cat).empty();
                        $('#product_'+$cat).append('<option value="" selected="selected">Pilih Produk ...</option>');
                }

            });
        }
        
    function getOperator($cat, $parent){
            $('#product_'+$cat).append('<option value="" selected="selected">Loading...</option>');
            $('#provider_'+$cat).append('<option value="" selected="selected">Loading...</option>');
            $.ajax({
                url: '/process/getoperator',
                dataType: "json",
                type: "GET",
                data: {
                    'category': $parent
                },
                success: function (response) {
                    if(response.length != 0){
                        $('#provider_'+$cat).empty();
                        $('#provider_'+$cat).append('<option value="" selected="selected">Pilih Operator ...</option>');
                        $('#product_'+$cat).empty();
                        $('#product_'+$cat).append('<option value="" selected="selected">Pilih Produk ...</option>');
                        $.each(response, function(index, operatorObj){
                                if (operatorObj.status == 0) {
                                    $('#provider_'+$cat).append('<option value="'+operatorObj.id+'" style="color: #C8C8C8;" disabled>'+operatorObj.product_name+'</option>');
                                }else{
                                    $('#provider_'+$cat).append('<option value="'+operatorObj.id+'">'+operatorObj.product_name+'</option>');
                                }
                        });
                    }
                },
                error: function (response) {
                    toastr.error("Data tidak ditemukan, periksa kembali nomor handphone tujuan anda");
                    $('#provider_'+$cat).empty();
                    $('#provider_'+$cat).append('<option value="" selected="selected">Pilih Operator ...</option>');
                    $('#product_'+$cat).empty();
                    $('#product_'+$cat).append('<option value="" selected="selected">Pilih Produk ...</option>');

                }

            });
        }
    
    function getProduct($product, $operator) {
            $('#product_'+$product).empty();
            $('#product_'+$product).append('<option value="" selected="selected">Loading...</option>');
        $.ajax({
                url: 'process/findproduct',
                dataType: "json",
                type: "GET",
                data: {
                    'pembelianoperator_id': $operator
                },
                success: function (response) {
                    $('#product_'+$product).empty();
                    $.each(response, function(index, produkObj){
                            harga = parseInt(produkObj.price);
                            if (produkObj.status == 0) {
                                $('#product_'+$product).append('<option value="'+produkObj.product_id+'" style="color: #C8C8C8;" disabled>'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                            }else{
                                $('#product_'+$product).append('<option value="'+produkObj.product_id+'">'+produkObj.product_name+'</option>');
                            }
                        });
                },
                error: function (response) {
                    toastr.error("TERJADI KESALAHAN, SILAHKAN REFRESH HALAMAN DAN LAKUKAN LAGI.");
                    $('#product_'+$product).empty();
                    $('#product_'+$product).append('<option value="" selected="selected">Pilih Produk ...</option>');
                }

            });
    }
    
    function beli($category, $type, id_operator){
        $.blockUI({ css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .5,
              color: '#fff'
        } });
        
        var target   = $('#target_'+$category).val();
        var pin      = $('#pin_'+$category).val();
        var provider = $('#provider_'+$category).val();
        var product  = $('#product_'+$category).val();
        
        if($type == "PLN"){
            var no_meter_pln = $('#no_meter_pln').val();
            if( no_meter_pln == '' ){
                $.unblockUI();
                toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
                return false;
            }
        }else{
            var provider = $('#provider_'+$category).val();
            if( provider == '' ){
                $.unblockUI();
                toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
                return false;
            }
        }

        if( target == ''){
            $.unblockUI();
            toastr.error("MOHON MAAF, BIDANG NO PENGISIAN TIDAK BOLEH KOSONG.");
            return false;
        }

        
        if( pin == ''){
            $.unblockUI();
            toastr.error("MOHON MAAF, BIDANG PIN TIDAK BOLEH KOSONG.");
            return false;
        }

        if(product == '' ){
            $.unblockUI();
            toastr.error("MOHON MAAF, BIDANG ISIAN PRODUK TIDAK BOLEH KOSONG.");
            return false;
        }
        

        $.ajax({
            url: "<?php echo e(url('/member/process/orderproduct/home')); ?>",
            method: "POST",
            data: {
                _token:"<?php echo e(csrf_token()); ?>",
                'submit':$('input[name=submit]').val(),
                'target': target,
                'no_meter_pln' : no_meter_pln,
                'pin': pin,
                'produk':product,
                'pembelianoperator_id': id_operator,
                'type': $type
            },
            success: function(response){
                if (response.success === false) {
                    $.unblockUI();
                    toastr.error(response.message);
                    return false;
                }

                $.unblockUI();
                toastr.success(response.message);
                
                $('#target_'+$category).val('')
                $('#pin_'+$category).val('')
                getOperator($category, id_operator);
                
            },
            error: function(response){
                $.unblockUI();
                // console.log(response.responseText);
                if(response.success == 0){
                    toastr.error(response.message)
                    return false;
                }
            }
        })
    }
    
    $('#provider_tagihan').on('change', function(e){
           var pembayaranoperator_id = $('#provider_tagihan').val();
           $('#product_tagihan').empty();
           $('#product_tagihan').append('<option value="" selected="selected">Loading...</option>');

            $.ajax({
                url: '/process/findproduct/pembayaran',
                dataType: "json",
                type: "GET",
                data: {
                    'pembayaranoperator_id': pembayaranoperator_id,
                    //'pembayarankategori_id': value.id
                },
                success: function (response) {
                    $('#product_tagihan').empty();
                    if(response.length != 0){
                        $.each(response, function(index, produkObj){
                            harga = parseInt(produkObj.price_markup);
                            if (produkObj.status == 0) {
                                $('#product_tagihan').append('<option value="'+produkObj.product_name+'" style="color: #C8C8C8;" disabled>'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                            }else{
                                $('#product_tagihan').append('<option value="'+produkObj.code+'">'+produkObj.product_name+' <b>(Biaya Admin '+rupiah(harga)+')</b></option>');
                            }
                        });

                    }else{
                        toastr.error("Sistem <?php echo e($GeneralSettings->nama_sistem); ?> sedang melakukan MAINTENANCE, untuk itu kami mohon untuk tidak melakukan transaksi terlebih dahulu. Trimakasih");
                    }

                },
                error: function (response) {
                    $('#product_tagihan').empty();
                    $('#product_tagihan').append('<option value="" selected="selected">-- Pilih Produk --</option>');
                    toastr.error("TERJADI KESALAHAN, SILAHKAN REFRESH HALAMAN DAN LAKUKAN LAGI.");
                }

            });
        });
        
    $('#cek_tagihan').on('click', btnCekTagihan);
    function btnCekTagihan(){
        $.blockUI({ css: {
              border: 'none',
              padding: '15px',
              backgroundColor: '#000',
              '-webkit-border-radius': '10px',
              '-moz-border-radius': '10px',
              opacity: .5,
              color: '#fff'
          } });
        var pembayaranoperator_id = $('#provider_tagihan').val();
        var produk_pembayaran = $('#product_tagihan').val();
        var nomor_rekening = $('#id_pelanggan').val();
        var target = $('#no_hp').val();
        var pin = $('#pin_tagihan').val();

            if( produk_pembayaran == '' || nomor_rekening == '' || target == '' || pin == '' ){
                $.unblockUI();
                toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
                //return false;
            }

            $.ajax({

                    url: "member/process/cektagihan/home",

                    method: "POST",
                    data: {
                        _token:"<?php echo e(csrf_token()); ?>",
                        'submit':$('input[name=submit]').val(),
                        'produk': produk_pembayaran,
                        'nomor_rekening': nomor_rekening,
                        'target': target,
                        'pin': pin
                    },

                    success: function(response){
                        if (response.success == false) {
                            $.unblockUI();
                            toastr.error(response.message);
                            return;
                        }else{
                            var order_id = response.id;
                            var tagihan_id = response.tagihan_id;
                            var tanggal = response.created_at;
                            var phone = response.phone;
                            var nama = response.nama;
                            var bulan = response.periode;
                            var produk_ppob = response.product_name;
                            var no_pelanggan = response.no_pelanggan;
                            var jml_tagihan = parseInt(response.jumlah_tagihan);
                            var jml_bayar = parseInt(response.jumlah_bayar);
                            var admin = parseInt(response.admin);
                            var token = response.token;
                            $.unblockUI();
                            $('#boxresult').empty();
                            $('#boxresult').append('<input type="hidden" name="_token" value="'+token+'">');
                            $('#boxresult').append('<input type="hidden" name="order_id" value="'+order_id+'">');
                            $('#boxresult').append('<input type="hidden" name="tagihan_id" value="'+tagihan_id+'">');
                            $('#boxresult').append('<input type="hidden" name="jumlah_tagihan" value="'+jml_tagihan+'">');
                            $('#boxresult').append('<input type="hidden" name="admin" value="'+admin+'">');
                            $('#boxresult').append('<input type="hidden" name="harga" value="'+jml_bayar+'">');
                            $('#boxresult').append('<input type="hidden" name="bulan" value="'+bulan+'">');
                            $('#boxresult').append('<input type="hidden" name="produk_ppob" value="'+produk_ppob+'">');
                            $('#boxresult').append('<input type="hidden" name="target_phone" value="'+phone+'">');
                            $('#boxresult').append('<div id="box-body" style="color:black">');
                            $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Order ID</span><span class="pull-right" style="font-size:14px">Tanggal</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+order_id+'</span><span class="pull-right" style="font-size:14px">'+tanggal+'</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nomor Handphone</span><span class="pull-right" style="font-size:14px">Jumlah Tagihan</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+phone+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(jml_tagihan)+'</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nomor / ID Pelanggan</span><span class="pull-right" style="font-size:14px">Admin</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+no_pelanggan+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(admin)+'</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nama Pelanggan</span><span class="pull-right" style="font-size:14px">Jumlah Bayar</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+nama+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(jml_bayar)+'</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Status</span></div><div class="clearfix"></div>');
                            $('#box-body').append('<div><span class="pull-left text-default" style="font-size:18px;font-weight:bold;">MENUNGGU</span></div><div class="clearfix"></div>');
                            $('#modal_footer').append('<button type="submit" id="bayar" class="btn btn-default btn-block btn-lg">Bayar Tagihan</button>');
                            $('#myModal').modal('show');
                            
                        }
                    },
                    error: function(response){
                        $.unblockUI();
                        // console.log(response.responseText);
                        if(response.success == 0){
                            showalert(response.message, 'danger');
                            toastr.error(response.message);
                            return false;
                        }
                    }
                })
    }

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webpulsa baru\produk1\resources\views/home.blade.php ENDPATH**/ ?>