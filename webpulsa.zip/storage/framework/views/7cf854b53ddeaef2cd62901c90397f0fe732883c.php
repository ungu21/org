

<?php $__env->startSection('content'); ?>
<?php 
   $bulan = array(
      '01' => 'Januari',
      '02' => 'Februari',
      '03' => 'Maret',
      '04' => 'April',
      '05' => 'Mei',
      '06' => 'Juni',
      '07' => 'Juli',
      '08' => 'Agustus',
      '09' => 'September',
      '10' => 'Oktober',
      '11' => 'November',
      '12' => 'Desember',
); ?>
<style>
@media  screen and (max-width: 780px) {
    .title-beli{
        font-size:11px;
    }
    .height-info{
        height: 500px;
    }
}
</style>
<section class="content-header hidden-xs">
<h1>Home <small>Dashboard</small></h1>
<ol class="breadcrumb">
   <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
   <li class="active">Dashboard</li>
</ol>
</section>
<section class="content">
	<div class="row">
		<div class="col-md-6">
            <?php if($countTagihan > 0): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="callout callout-warning">
                        <div class="row">
                            <div class="col-md-12">
                              <!--<h4>Info !</h4>-->
                              <b>Halo sobat... <br/>Anda mempunyai <?php echo e($countTagihan); ?> Tagihan pembayaran yang belom anda selesaikan!</b><br/>
                              <?php $no=0; ?>
                              <?php $__currentLoopData = $tagihanNonBuy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $no++; ?>
                                  <?php if($no == '4'): ?>
                                    <br/>
                                    <br/>
                                    <a href="<?php echo e(url('/member/tagihan-pembayaran')); ?>"><b>SELENGKAPNYA >>></b></a>
                                  <?php else: ?>
                                    <br/>
                                        <?php echo e($no); ?>.&nbsp;
                                         ID: <?php echo e(isset($tgh['id'])?$tgh['id'] : '-'); ?>&nbsp;
                                        <?php echo e(isset($tgh['product_name'])?$tgh['product_name'] : '-'); ?>&nbsp;
                                        <?php echo e(isset($tgh['no_pelanggan'])?$tgh['no_pelanggan'] : '-'); ?>&nbsp;
                                        <?php echo e(isset($tgh['nama'])?$tgh['nama'] : '-'); ?>&nbsp;
                                        <?php echo e(isset($tgh['periode'])?$tgh['periode'] : '-'); ?>&nbsp;
                                        <a href="<?php echo e(url('/member/tagihan-pembayaran/'.$tgh['id'].'')); ?>"><b>KLIK .</b></a>
                                  <?php endif; ?>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
		    <?php if($GeneralSettings->status == 0 || $GeneralSettings->status_server == 0): ?>
		    <div class="box box-widget" style="margin-bottom: 10px;background-color: #FDFDFD;text-align:center;">
		        <h6 style="padding:10px;margin-top:0px;font-style:italic;">Sistem <?php echo e($GeneralSettings->nama_sistem); ?> sedang melakukan MAINTENANCE, untuk itu kami mohon untuk tidak melakukan transaksi terlebih dahulu. Trimakasih</h6>
		    </div>
		    <?php endif; ?>
		    
            <div class="box box-widget" style="margin-bottom: 10px;background-color: #FDFDFD">
                <div class="box-body">
                    <h4 style="margin-bottom: 0px;margin-top: 0px;" class="pull-left text-primary"><span class="icon-wallet" style="margin-right: 6px;"></span>Rp. <?php echo e(number_format(Auth::user()->saldo,0,'.','.')); ?></h4>
                    <a href="<?php echo e(url('/member/deposit')); ?>" class="btn-loading label label-primary pull-right" style="font-size: 13px;padding-bottom: 5px;padding-top: 5px;"><i class="fa fa-plus-circle" style="margin-right: 3px;"></i> Isi Saldo</a>
                </div>
            </div>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                     <?php $no = 0; ?>
                     <?php $__currentLoopData = $getimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $no++ ?>
                        <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($no); ?>" <?php echo e($no == 1?'class="active"':''); ?>></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                 <?php $no=0; ?>
                 <?php $__currentLoopData = $getimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php $no++ ?>
                    <div class="item <?php echo e($no== 1?'active':''); ?>"><img src="<?php echo e(asset($img->img_path)); ?>"></div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="row" style="margin-top:10px;">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="grid" cellspacing="0">
                            <?php
                                $chunk = array_chunk($menu,3);
                            ?>
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td style="width:33.3%;height:70px;cursor:pointer;" onclick="location.href='<?php echo e(url('/member/bayar', $data['slug'])); ?>'">
                                            <a href="<?php echo e(url('/member/bayar', $data['slug'])); ?>" class="btn-loading">
                                                <img class="icon__width" src="<?php echo e(asset('assets/images/icon_web/'.$data['icon'])); ?>"><br>
                                                <small class="title-beli"><?php echo e($data['product_name']); ?></small>
                                            </a>
                                        </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 hidden-xs hidden-sm">
            <ul class="timeline">
                <!-- timeline time label -->
                <li class="time-label"><span class="bg-blue" style="padding-right: 20px;padding-left: 20px;">Pusat Informasi</span></li>
                <!-- /.timeline-label -->
                <!-- timeline item -->
                <?php if($info->count() > 0): ?>
                <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <?php if($data->type == 'INFO'): ?>
                    <i class="fa fa-info bg-blue"></i>
                    <?php elseif($data->type == 'PROMO'): ?>
                    <i class="fa fa-tags bg-blue"></i>
                    <?php elseif($data->type == 'MAINTENANCE'): ?>
                    <i class="fa fa-wrench bg-blue"></i>
                    <?php endif; ?>
                    <div class="timeline-item">
                        <span class="time"><i class="fa fa-clock-o"></i> <?php echo e(date("d M Y H:m:s", strtotime($data->created_at))); ?></span>
                        <h3 class="timeline-header"><a href="#">[<?php echo e($data->type); ?>]</a> <?php echo e($data->title); ?></h3>
                        <div class="timeline-body"><?php echo $data->isi_informasi; ?></div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <li>
                    <i class="fa fa-exclamation-circle bg-blue"></i>
                    <div class="timeline-item">
                        <div class="timeline-body" style="padding-top: 5px;padding-bottom: 5px;text-align:center;">
                            <h4 style="font-style:italic;">Informasi belum tersedia</h4>
                        </div>
                    </div>
                </li>
                <?php endif; ?>
                
                <li>
                  <i class="fa fa-clock-o bg-gray"></i>
                </li>
              </ul>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php if(count($getimages) > 0): ?>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js"></script>
<script>
    $(".carousel").swipe({

  swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

    if (direction == 'left') $(this).carousel('next');
    if (direction == 'right') $(this).carousel('prev');

  },
  allowPageScroll:"vertical"

});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/member/pascabayar.blade.php ENDPATH**/ ?>