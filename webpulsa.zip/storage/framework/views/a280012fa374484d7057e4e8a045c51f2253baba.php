

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Pembayaran <small>Produk</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;"> Pembayaran</a></li>
        <li><a href="<?php echo e(url('/admin/pembayaran-produk')); ?>" class="btn-loading"> Produk</a></li>
        <li><a href="<?php echo e(url('/admin/pembayaran-produk', $kategori->slug)); ?>" class="btn-loading"> <?php echo e($kategori->product_name); ?></a></li>
    	<li class="active">Ubah Produk</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(url('/admin/pembayaran-produk', $kategori->slug)); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Ubah Produk</h3>
                </div>
                <form role="form" action="<?php echo e(url('/admin/pembayaran-produk/update/'.$produk->id)); ?>" method="post">
                <input name="_method" type="hidden" value="PATCH">
                <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <input type="hidden" name="kategori" value="<?php echo e($kategori->id); ?>">
		                    <input type="hidden" name="kategori_slug" value="<?php echo e($kategori->slug); ?>">
                        <div class="form-group<?php echo e($errors->has('operator') ? ' has-error' : ''); ?>">
                            <label>Operator : </label>
                            <select name="operator" class="form-control">
                                <option value="">-- Pilih Operator Pembayaran --</option>
                                <?php $__currentLoopData = $operator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($produk->pembayaranoperator_id == $data->id ? 'selected' : ''); ?>><?php echo e($data->product_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('operator', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('product_name') ? ' has-error' : ''); ?>">
                            <label>Nama Produk : </label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo e($produk->product_name ?? old('product_name')); ?>" placeholder="Masukkan Nama Produk">
                            <?php echo $errors->first('product_name', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                            <label>Kode Produk : </label>
                            <input type="text" class="form-control" name="code" value="<?php echo e($produk->code ?? old('code')); ?>" placeholder="Masukkan Kode Produk">
                            <?php echo $errors->first('code', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group">
                            <label>Biaya Default(Rp) (Server) : </label>
                            <input type="text" class="form-control" id="biaya_default" value="<?php echo e(number_format($produk->price_default, 0, '.', '.')); ?>" readonly disabled>
                        </div>
                        <div class="form-group<?php echo e($errors->has('markup') ? ' has-error' : ''); ?>">
                            <label>Markup Biaya(Rp) : </label>
                            <input type="text" class="form-control" name="markup" id="markup" value="<?php echo e(number_format($produk->markup, 0, '.', '.')); ?>" placeholder="Masukkan Biaya Admin">
                            <?php echo $errors->first('markup', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group">
                            <label>Biaya Admin(Rp) : </label>
                            <input type="text" class="form-control" id="biaya_admin" value="<?php echo e(number_format($produk->price_markup, 0, '.', '.')); ?>" readonly disabled>
                        </div>
                        <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                            <label>Status Produk : </label>
                            <select name="status" class="form-control">
                                <option value="1" <?php echo e($produk->status == 1 ? 'selected' : ''); ?>>Tersedia</option>
                                <option value="0" <?php echo e($produk->status == 0 ? 'selected' : ''); ?>>Gangguan</option>
                            </select>
                            <?php echo $errors->first('status', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="submit btn btn-primary btn-block">Update</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box box-solid box-penjelasan">
                <div class="box-header">
                    <i class="fa fa-server"></i>
                    <h3 class="box-title">Produk <?php echo e($kategori->product_name); ?> 10 Terakhir</h3>
                    <div class="box-tools pull-right box-minus" style="display:none;">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr class="text-primary">
                            <th>Nama Produk</th>
                            <th>Opearator</th>
                            <th>Kode</th>
                            <th>Status</th>
                        </tr>
                        <?php if($produks->count() > 0): ?>
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->product_name); ?></td>
                            <td><?php echo e($data->pembayaranoperator->product_name); ?></td>
                            <td><?php echo e($data->code); ?></td>
                            <?php if($data->status == 1): ?>
                            <td><label class="label label-success">Tersedia</label></td>
                            <?php else: ?>
                            <td><label class="label label-danger">Gangguan</label></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center;font-size: 13;font-style: italic;background-color: #F8F6F6">Data tidak ditemukan</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>


        <div class="col-md-6">
            <div class="box box-solid box-penjelasan">
                <div class="box-header">
                    <i class="fa fa-server"></i>
                    <h3 class="box-title">Produk <?php echo e($kategori->product_name); ?> 10 Terakhir</h3>
                    <div class="box-tools pull-right box-minus" style="display:none;">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr class="text-primary">
                            <th>Nama Produk</th>
                            <th>Opearator</th>
                            <th>Kode</th>
                            <th>Status</th>
                        </tr>
                        <?php if($produks->count() > 0): ?>
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->product_name); ?></td>
                            <td><?php echo e($data->pembayaranoperator->product_name); ?></td>
                            <td><?php echo e($data->code); ?></td>
                            <?php if($data->status == 1): ?>
                            <td><label class="label label-success">Tersedia</label></td>
                            <?php else: ?>
                            <td><label class="label label-danger">Gangguan</label></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4" style="text-align: center;font-size: 13;font-style: italic;background-color: #F8F6F6">Data tidak ditemukan</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

$(document).ready(function() {

    function autoMoneyFormat(b){
        var _minus = false;
        if (b<0) _minus = true;
        b = b.toString();
        b=b.replace(".","");
        b=b.replace("-","");
        c = "";
        panjang = b.length;
        j = 0;
        for (i = panjang; i > 0; i--){
        j = j + 1;
        if (((j % 3) == 1) && (j != 1)){
        c = b.substr(i-1,1) + "." + c;
        } else {
        c = b.substr(i-1,1) + c;
        }
        }
        if (_minus) c = "-" + c ;
        return c;
    }

      function price_to_number(v){
      if(!v){return 0;}
          v=v.split('.').join('');
          v=v.split(',').join('');
      return Number(v.replace(/[^0-9.]/g, ""));
      }

      function number_to_price(v){
      if(v==0){return '0,00';}
          v=parseFloat(v);
          // v=v.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
          v=v.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
          v=v.split('.').join('*').split(',').join('.').split('*').join(',');
      return v;
      }

      function formatNumber (num) {
        return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
      }

    $('#markup').keyup(function(){
        var markup = parseInt(price_to_number($('#markup').val()));
        var biaya_admin = autoMoneyFormat(parseInt(price_to_number($('#biaya_default').val())) + markup);
        var autoMoney = autoMoneyFormat(markup);
        $('#markup').val(autoMoney);
        $('#biaya_admin').val(biaya_admin);
    });

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/admin/pembayaran/produk/edit.blade.php ENDPATH**/ ?>