

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
	<h1>Detail <small>Deposit</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/member')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('/member/deposit')); ?>" class="btn-loading"> Deposit</a></li>
    	<li class="active">Detail Deposit #<?php echo e($deposits->id); ?></li>
   </ol>
   </section>
   <section class="content">
      <div class="row">
         <div class="col-md-6">
            <div class="box box-default">
               <div class="box-header with-border">
                  <h3 class="box-title"><a href="<?php echo e(url('/member/deposit')); ?>" class="btn-loading hidden-lg"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Detail Deposit</h3>
                  <div class="box-tools pull-right">
                     <a href=""><i class="fa fa-print fa-lg" style="margin-top: 8px;margin-right: 5px;"></i></a>
                  </div>
               </div>
               <div class="box-body" style="color: #6E6C6C">
                  <table>
                     <tr>
                        <td width="50px">
                           <img src="<?php echo e(asset('img/logo/'.$logoku[0]->img)); ?>" style="display: inline;width: 60px; margin-right:10px;">
                        </td>
                        <td>
                           <span class="custom__text-green" style="font-size: 20px;font-weight: bold;">SALDO <?php echo e(strtoupper($GeneralSettings->nama_sistem)); ?></span><br>
                           <span>TOPUP Saldo</span>
                        </td>
                     </tr>
                  </table>
                  <div style="margin-top: 10px;">
                     <span class="pull-left">Order ID</span>
                     <span class="pull-right">Tanggal</span>
                  </div>
                  <div class="clearfix"></div>
                  <div>
                     <span class="pull-left custom__text-green" style="font-size: 20px;font-weight: bold;"><?php echo e($deposits->id); ?></span>
                     <span class="pull-right"><?php echo e(date("d M Y H:m:s", strtotime($deposits->created_at))); ?></span>
                  </div>
                  <div class="clearfix"></div>
                  <div style="margin-top: 10px;">
                     <span">Metode Pembayaran</span>
                  </div>
                  <div>
                     <span class="custom__text-green" style="font-size: 20px;font-weight: bold;"><?php echo e($deposits->bank->nama_bank); ?></span>
                  </div>
                  <div style="margin-top: 10px;">
                     <span">Nominal Transfer</span>
                  </div>
                  <div>
                     <span class="custom__text-green" style="font-size: 20px;font-weight: bold;">Rp <?php echo e(number_format($deposits->nominal_trf, 0 ,'.', '.')); ?>,-</span>
                  </div>
                  <div style="margin-top: 10px;">
                     <span">Status</span>
                  </div>
                  <div>
                     <?php if($deposits->status == 0): ?>
                     <span class="text-warning" style="font-size: 20px;font-weight: bold;">MENUNGGU</span>
                     <?php elseif($deposits->status == 1): ?>
                     <span class="text-success" style="font-size: 20px;font-weight: bold;">BERHASIL</span>
                     <?php elseif($deposits->status == 3): ?>
                     <span class="text-primary" style="font-size: 20px;font-weight: bold;">VALIDASI</span>
                     <?php elseif($deposits->status == 2): ?>
                     <span class="text-danger" style="font-size: 20px;font-weight: bold;">GAGAL</span>
                     <?php endif; ?>
                     
                  </div>
                  <div style="margin-top: 10px;">
                     <span">Catatan</span>
                  </div>
                  <div>
                     <?php if($deposits->status == 0): ?>
                        <small>Menunggu pembayaran sebesar Rp <?php echo e(number_format($deposits->nominal_trf, 0 ,'.', '.')); ?>. Nominal sudah termasuk kode unik dan akan dijadikan saldo. Mohon transfer sesuai nominal dibawah</small>
                     <?php elseif($deposits->status == 1): ?>
                        <small>Deposit sebesar Rp <?php echo e(number_format($deposits->nominal_trf, 0 ,'.', '.')); ?> berhasil ditambahkan</small>
                     <?php elseif($deposits->status == 3): ?>
                        <small>Pembayaran telah di konfirmasi, proses validasi pembayaran. Jika kami belum menerima pembayaran anda atau anda tidak transfer sesuai nominal yang tertera, maka deposit oromatis akan kembali kepada status MENUNGGU.</small>
                     <?php elseif($deposits->status == 2): ?>
                        <small>Transaksi anda sudah dibatalkan, silahkan ulangi.</small>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
         
         <?php if($deposits->status != 1 and $deposits->status == 0): ?>
         <div class="col-md-6">
            <div class="box box-solid">
               <div class="box-header with-border">
                  <h3 class="box-title">#Step 1 - Detail Pembayaran</h3>
               </div><!-- /.box-header -->
               <div class="box-body">
                  <div align="center">
                     <p>Silahkan melakukan pembayaran ke nomor rekening dibawah ini</p>
                     <img src="<?php echo e(asset('img/banks/'.$deposits->bank->image)); ?>" alt="<?php echo e($deposits->bank->nama_bank); ?>" width="25%" class="">
                     <p style="margin-top: 10px;font-weight: bold;">
                        <?php echo e($deposits->bank->no_rek); ?> <br>
                        <?php echo e($deposits->bank->atas_nama); ?>

                     </p>
                     <p>Silahkan Transfer tepat sebesar :</p>
                     <center><span style="background-color:#D5D5D5;color:#4F4F4F;font-weight:bold;font-size:18px;padding:5px 8px;"><?php echo e($deposits->nominal_trf); ?></span></center>
                  </div>                  
               </div><!-- /.box-body -->
            </div><!-- /.box -->
         </div>
         <div class="col-md-6">
            <div class="box box-solid">
               <div class="box-header with-border">
                  <h3 class="box-title">#Step 2 - Konfirmasi Pembayaran</h3>
               </div><!-- /.box-header -->
               <div class="box-body">
                  <div align="center">
                      <form action="<?php echo e(url('member/deposit/konfirmasi')); ?>" method="post" enctype="multipart/form-data">
                          <?php echo csrf_field(); ?>
                          <div class="form-group">
                              <label>Upload Bukti Pembayaran</label>
                              <input class="form-control" name="bukti" id="bukti" type="file">
                              <input type="hidden" name="id" value="<?php echo e($deposits->id); ?>">
                          </div>
                         <p>Setelah anda melakukan pembayaran kerekening di atas, silahkan upload bukti pembayaran dan konfirmasi Pembayaran Anda dengan mengkil tombol di bawah ini</p>
                         <button type="submit" class="submit btn btn-primary btn-block">Saya Sudah Transfer</button>
                      </form>
                  </div>
               </div><!-- /.box-body -->
            </div><!-- /.box -->
         </div>
         <?php else: ?>
         <div class="col-md-6 hidden-xs hidden-ms">
            <div class="box box-default">
               <div class="box-header">
                  <h3 class="box-title"><i class="fa fa-info-circle" style="margin-right:5px;"></i> Keterangan Status Transaksi</h3>
               </div>
               <div class="box-body" style="color: #6E6C6C">
                  <table class="table table-hover table-striped">
                     <tr>
                        <th>Satus</th>
                        <th>Keterangan</th>
                     </tr>
                     <tr>
                        <td><label class="label label-warning">PROSES</label></td>
                        <td>Sedang di proses</td>
                     </tr>
                     <tr>
                        <td><label class="label label-success">BERHASIL</label></td>
                        <td>Transaksi anda berhasil</td>
                     </tr>
                     <tr>
                        <td><label class="label label-primary">REFUND</label></td>
                        <td>Saldo anda di kembalikan</td>
                     </tr>
                     <tr>
                        <td><label class="label label-danger">GAGAL</label></td>
                        <td>Transaksi Gagal diproses</td>
                     </tr>
                     <tr>
                        <td><label class="label label-warning">PENDING</label></td>
                        <td>Transaksi pending, menunggu antrian untuk di proses</td>
                     </tr>
                     <tr>
                        <td><label class="label label-success">DIPROSES</label></td>
                        <td>Transaksi telah di proses dari antrian</td>
                     </tr>
                     <tr>
                        <td><label class="label label-warning">MENUNGGU</label></td>
                        <td>Menunggu Pembayaran</td>
                     </tr>
                     <tr>
                        <td><label class="label label-primary">VALIDASI</label></td>
                        <td>Validasi Pembayaran</td>
                     </tr>
                  </table>
               </div>
            </div>
         </div>
         <?php endif; ?>
      </div>
   </section>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/member/deposit/show.blade.php ENDPATH**/ ?>