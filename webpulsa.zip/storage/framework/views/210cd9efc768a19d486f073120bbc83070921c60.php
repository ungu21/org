<?php $__env->startSection('title', 'FAQ | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5"><i class="fa fa-question-circle"></i> Hal yang sering ditanyakan
          </h1>
        </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                <h3 class="color-primary text-center mb-4">Tidak Ada Minimal Deposit</h3>
                 <div class="row">
        <?php if($faqs->count() > 0): ?>
         <?php $i=1 ?>
         <?php $__currentLoopData = array_chunk($faqs->all(), 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-sm-6">
            <div class="panel-group ms-collapse no-margin" id="accordion<?php echo e($i); ?>" role="tablist" aria-multiselectable="true">
            <!-- Start FAQ Block -->
            <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-info">
                  <div class="card-header" role="tab" id="heading_<?php echo e($data->id); ?>">
                    <h4 class="card-title ms-rotate-icon">
                      <a class="withripple collapsed" role="button" data-toggle="collapse" href="#collapse-<?php echo e($data->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($data->id); ?>">
                        <i class="zmdi zmdi-help-outline"></i> Q : <?php echo e($data->pertanyaan); ?> <div class="ripple-container"></div></a>
                    </h4>
                  </div>
                  <div id="collapse-<?php echo e($data->id); ?>" class="card-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo e($data->id); ?>" data-parent="#accordion<?php echo e($i); ?>" style="">
                    <div class="card-body">
                      <p><?php echo e($data->jawaban); ?></p>
                    </div>
                  </div>
               </div>
               <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End FAQ Block -->
         </div>
         <?php $i++ ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
         </div>
                </div>
            </div> 
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/faq.blade.php ENDPATH**/ ?>