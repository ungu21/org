<?php $__env->startSection('title', 'Cara Transaksi | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city ms-hero-bg-primary">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Cara Transaksi
          </h1>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
               <div class="card-body">
                  <div class="row">
                     <div class="col-sm-4 col-md-4">
                        <!-- Start User Friendly Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-user-plus color-primary"></i>
                           </div>
                           <h3>Melakukan Pendaftaran</h3>
                           <p>Pendaftaran tanpa biaya 100% Gratis, setelah mendaftar akun anda langsung aktif dan dapat melakukan deposit.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                     <div class="col-sm-4 col-md-4">
                        <!-- Start Supper Fast Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-money color-success"></i>
                           </div>
                           <h3>Melakukan Deposit Saldo</h3>
                           <p>Langkah selanjutnya melakukan Deposit Saldo agar dapat digunakan untuk transaksi semua produk terlengkap dari kami.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                     <div class="col-sm-4 col-md-4">
                        <!-- Start Analytics Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-shopping-basket color-danger"></i>
                           </div>
                           <h3>Melakukan Transaksi</h3>
                           <p>Langkah terakhir melakukan transaksi pulsa anda dengan produk pulsa terlengkap dan termurah dari kami TriPay.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                  </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center" style="font-size:20px;">Cara Memasang WebApps TriPay Di Smartphone</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 text-center">
                        <img src="https://produk.tripay.co.id/assets/images/slider/step-1" class="img-rounded" width="40%">
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <h3>Langkah Pertama</h3>
                        <p>Langkah pertama untuk memasang apps TriPay di 
                            smartphone anda adalah dengan mengakses situs TriPay yang dapat di akses di <a href="https://produk.tripay.co.id">TriPay</a>. 
                            Dalam membuka situs TriPay di sarankan untuk menggunakan browser Crome, karena dalam panduan ini menggunakan browser Crome.</p>
                    </div>
                </div>

                <div class="row" style="margin-top:50px;">
                  <div class="col-md-6 text-right">
                      <h3>Langkah Kedua</h3>
                      <p>Langkah Kedua adalah dengan menekan 3 tanda titik pada sebelah kanan atas browser anda, 
                      dan akan menampilkan beberapa pilihan seperti pada gambar di samping ini.
                      Selanjutnya pilih "<b>Tambahkan Ke Layar Utama</b>" jika bahasa smartphone anda menggunakan bahasa inggris atau bahasa lainnya sesuaikan dengan pilihan tersebut.</p>
                  </div>
                  <div class="col-md-6 text-center">
                      <img src="https://produk.tripay.co.id/assets/images/slider/step-2" class="img-rounded" width="40%">
                  </div>
                </div>

                <div class="row" style="margin-top:50px;">
                  <div class="col-md-6 text-center">
                      <img src="https://produk.tripay.co.id/assets/images/slider/step-3" class="img-rounded" width="40%">
                  </div>
                  <div class="col-md-6 text-left">
                      <h3>Langkah Terakhir</h3>
                      <p>Langkah Terakhir akan menampilan hasil dari langkah sebelumnya, saat muncul seperti gambar di samping silahkan pilih <b>Tambahkan</b> 
                      dan selanjutnya kembali ke menu smartphone anda dan dapatkan webapps TriPay sudah tersedia di smartphone anda.
                      Transaksi anda akan semakin mudah dengan menggunakan salah satu fitur dari TriPay ini.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/cara-transaksi.blade.php ENDPATH**/ ?>