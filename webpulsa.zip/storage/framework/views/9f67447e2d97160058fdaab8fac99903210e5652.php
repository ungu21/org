
<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#"><img src="<?php echo e(asset('img/logo/'.$logoku[1]->img.'')); ?>" style="max-width:150px"></a>
    </div><!-- /.login-logo -->
    <div class="login-box-body">
        <form action="<?php echo e(url('/register')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group has-feedback <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <input type="text" name="name" class="form-control" placeholder="Nama Lengkap" value="<?php echo e(old('name')); ?>">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <?php echo $errors->first('name', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input type="email" name="email" class="form-control" placeholder="Alamat Email" value="<?php echo e(old('email')); ?>">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php echo $errors->first('email', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                <input type="number" name="phone" class="form-control" placeholder="Nomor Handphone" value="<?php echo e(old('phone')); ?>">
                <span class="glyphicon glyphicon-phone form-control-feedback"></span>
                <?php echo $errors->first('phone', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                <input type="text" name="city" class="form-control" placeholder="Kota Sekarang" value="<?php echo e(old('city')); ?>">
                <span class="glyphicon glyphicon-map-marker form-control-feedback"></span>
                <?php echo $errors->first('city', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                <input type="password" name="password" class="form-control" placeholder="Kata Sandi">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php echo $errors->first('password', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                <input type="password" name="password_confirmation" class="form-control" placeholder="Ulangi Kata Sandi">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php echo $errors->first('password_confirmation', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group has-feedback <?php echo e($errors->has('pin') ? ' has-error' : ''); ?>">
                <input type="number" name="pin" minlength="4" maxlength="4" class="form-control" placeholder="Buat 4 digit PIN transaksi">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <?php echo $errors->first('pin', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            
            
            <?php if( !empty(Cookie::get('ref')) || !empty(request()->get('ref')) ): ?>
            <div class="form-group has-feedback">
            <input type="text" class="form-control" name="kode_referral" placeholder="Kode Refferal (opsional)" value="<?php echo e(!empty(Cookie::get('ref')) ? Cookie::get('ref') : request()->get('ref')); ?>" readonly disabled>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <?php else: ?>
            <div class="form-group has-feedback <?php echo e($errors->has('kode_referral') ? ' has-error' : ''); ?>">
            <input type="text" name="kode_referral" maxlength="4" class="form-control" placeholder="Kode Refferal (opsional)">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            </div>
            <?php endif; ?>
            
            <p style="font-size: 13px;text-align:center;">Dengan menekan Daftar Akun, saya mengkonfirmasi telah menyetujui <a href="<?php echo e(url('/tos')); ?>" class="custom__text-green" style="color: #378CFF;text-decoration: underline;">Syarat dan Ketentuan</a>, serta <a href="<?php echo e(url('/privacy-policy')); ?>" class="custom__text-green" style="color: #378CFF;text-decoration: underline;">Kebijakan Privasi</a> <?php echo e($GeneralSettings->nama_sistem); ?>.</p>
            <div class="form-group">
                <button type="submit" class="submit btn btn-primary btn-block btn-flat">Daftar</button>
            </div>
        </form>
        <div align="center">
            <span>Sudah punya akun?</span>
            <h5 style="margin-top:5px;margin-bottom:0px;font-weight:bold;font-size:17px;"><a href="<?php echo e(url('/login')); ?>" class="custom__text-green">Masuk Sekarang</a></h5>
        </div>

    </div><!-- /.login-box-body -->
</div><!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/auth/register.blade.php ENDPATH**/ ?>