

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Pengaturan <small>Pusat Informasi</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;">Pengaturan</a></li>
        <li><a href="<?php echo e(route('pusat-informasi.index')); ?>" class="btn-loading"> Pusat Informasi</a></li>
    	<li class="active">Tambah Informasi</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-8">
            <div class="box box-green">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(route('pusat-informasi.index')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Tambah Informasi</h3>
                </div>
                <form role="form" action="<?php echo e(route('pusat-informasi.store')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label>Title : </label>
                            <input type="text" class="form-control" name="title"  placeholder="Masukkan Title Informasi">
                            <?php echo $errors->first('title', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                            <label>Type Informasi : </label>
                            <select name="type" class="form-control">
                                <option value="INFO">INFO</option>
                                <option value="PROMO">PROMO</option>
                                <option value="MAINTENANCE">MAINTENANCE</option>
                            </select>
                            <?php echo $errors->first('type', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('isi_informasi') ? ' has-error' : ''); ?>">
                            <label>Isi Informasi : </label>
                            <textarea class="textarea" name="isi_informasi" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                            <?php echo $errors->first('isi_informasi', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function () {
        //bootstrap WYSIHTML5 - text editor
        $(".textarea").wysihtml5();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/admin/pengaturan/pusat-informasi/create.blade.php ENDPATH**/ ?>