
<?php $__env->startSection('meta', '<meta http-equiv="refresh" content="60">'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
<h1>Kontrol menu <small>Menu dan sub menu</small></h1>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-dashboard"></i> Kontrol Menu</a></li>
  <li class="active">Menu dan sub menu</li>
</ol>
</section>
<section class="content">
   <div class="row">
      <div class="col-md-6">
        <div class="box box-solid box-penjelasan">
            <div class="box-header">
                <i class="fa fa-text-width"></i>
                <h3 class="box-title">Edit Kontrol menu</h3>
                <div class="box-tools pull-right box-minus" style="display:none;">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                </div>
            </div><!-- /.box-header -->
          
          <?php if($section_active == 'MENU'): ?>
            <form role="form" action="<?php echo e(url('/admin/kontrol-menu/updateSaveMenu', $datamenu->id)); ?>" method="post">
            <input name="_method" type="hidden" value="PATCH">
            <?php echo e(csrf_field()); ?>

                <div class="box-body">
                    <div class="form-group<?php echo e($errors->has('caption') ? ' has-error' : ''); ?>">
                        <label>Nama Menu: </label>
                            <input type="text" id="caption" class="form-control" name="caption" value="<?php echo e($datamenu->caption); ?>">
                    </div>
                    <div class="form-group">
                        <!-- <label>Harga Produk: </label> -->
                        <label>Icon: </label>
                            <input type="text" id="icon" class="form-control" name="icon" value="<?php echo e($datamenu->icon); ?>" placeholder="Icon">
                    </div>
                    <div class="form-group">
                        <label>Permission Menu: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="permission" id="permission" class="form-control">
                                <?php $__currentLoopData = $getRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($data->id == $datamenu->permission_menu?'selected':''); ?> ><?php echo e($data->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <label>Status: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="status" id="status" class="form-control">
                                <option value="1" <?php echo e(1==$datamenu->status?'selected':''); ?>>ACTIVE</option>
                                <option value="0" <?php echo e(0==$datamenu->status?'selected':''); ?>>NON ACTIVE</option>
                            </select>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                </div>
            </form>
          <?php elseif($section_active == 'SUBMENU'): ?>
            <form role="form" action="<?php echo e(url('/admin/kontrol-menu/updateSaveSubmenu', $datamenu->id)); ?>" method="post">
            <input name="_method" type="hidden" value="PATCH">
            <?php echo e(csrf_field()); ?>

                <div class="box-body">
                    <div class="form-group<?php echo e($errors->has('caption_sub') ? ' has-error' : ''); ?>">
                        <label>Nama Menu: </label>
                            <input type="text" id="caption_sub" class="form-control" name="caption_sub" value="<?php echo e($datamenu->caption_sub); ?>">
                    </div>
                    <div class="form-group">
                        <label>Parent Menu: </label>
                            <select name="parent_menu" id="parent_menu" class="form-control">
                                <?php $__currentLoopData = $getSubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataParent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dataParent->id); ?>" <?php echo e($dataParent->id == $datamenu->idparent?'selected':''); ?>><?php echo e(strtoupper($dataParent->caption)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <!-- <label>Harga Produk: </label> -->
                        <label>Icon: </label>
                            <input type="text" id="icon_sub" class="form-control" name="icon_sub" value="<?php echo e($datamenu->icon_sub); ?>" placeholder="Icon">
                    </div>
                    <div class="form-group<?php echo e($errors->has('url') ? ' has-error' : ''); ?>">
                        <!-- <label>Harga Produk: </label> -->
                        <label>URL: </label>
                            <input type="text" id="url" class="form-control" name="url" value="<?php echo e($datamenu->url); ?>" placeholder="Url">
                    </div>
                    <div class="form-group">
                        <label>Permission Menu: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="permission" id="permission" class="form-control">
                                <?php $__currentLoopData = $getRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($data->id == $datamenu->permission_menu?'selected':''); ?> ><?php echo e($data->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <label>Status: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="status_sub" id="status_sub" class="form-control">
                                <option value="1" <?php echo e(1==$datamenu->status_sub?'selected':''); ?>>ACTIVE</option>
                                <option value="0" <?php echo e(0==$datamenu->status_sub?'selected':''); ?>>NON ACTIVE</option>
                            </select>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                </div>
            </form>
          <?php elseif($section_active == 'SUBMENU2'): ?>
            <form role="form" action="<?php echo e(url('/admin/kontrol-menu/updateSaveSubmenu2', $datamenu->id)); ?>" method="post">
            <input name="_method" type="hidden" value="PATCH">
            <?php echo e(csrf_field()); ?>

                <div class="box-body">
                    <div class="form-group<?php echo e($errors->has('caption_sub2') ? ' has-error' : ''); ?>">
                        <label>Nama Menu: </label>
                            <input type="text" id="caption_sub2" class="form-control" name="caption_sub2" value="<?php echo e($datamenu->caption_sub2); ?>">
                    </div>
                    <div class="form-group">
                        <label>Parent Menu: </label>
                            <select name="parent_menu" id="parent_menu" class="form-control">
                                <?php $__currentLoopData = $getSubMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataParentSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dataParentSub->id); ?>" <?php echo e($dataParentSub->id == $datamenu->idparent?'selected':''); ?>><?php echo e(strtoupper($dataParentSub->caption_sub)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <!-- <label>Harga Produk: </label> -->
                        <label>Icon: </label>
                            <input type="text" id="icon_sub2" class="form-control" name="icon_sub2" value="<?php echo e($datamenu->icon_sub2); ?>" placeholder="Icon">
                    </div>
                    <div class="form-group<?php echo e($errors->has('url') ? ' has-error' : ''); ?>">
                        <!-- <label>Harga Produk: </label> -->
                        <label>URL: </label>
                            <input type="text" id="url" class="form-control" name="url" value="<?php echo e($datamenu->url); ?>" placeholder="Url">
                    </div>
                    <div class="form-group">
                        <label>Permission Menu: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="permission" id="permission" class="form-control">
                                <?php $__currentLoopData = $getRole; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($data->id == $datamenu->permission_menu?'selected':''); ?> ><?php echo e($data->display_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        <label>Status: </label>
                            <!-- <input type="text" id="permission_menu" class="form-control" name="permission_menu" value="<?php echo e($datamenu->display_name); ?>"> -->
                            <select name="status_sub2" id="status_sub2" class="form-control">
                                <option value="1" <?php echo e(1==$datamenu->status_sub2?'selected':''); ?>>ACTIVE</option>
                                <option value="0" <?php echo e(0==$datamenu->status_sub2?'selected':''); ?>>NON ACTIVE</option>
                            </select>
                    </div>
                </div>

                <div class="box-footer">
                    <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                </div>
            </form>
          <?php endif; ?>
      </div>
      </div>

   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/produk3/resources/views/admin/kontrol-menu/show.blade.php ENDPATH**/ ?>