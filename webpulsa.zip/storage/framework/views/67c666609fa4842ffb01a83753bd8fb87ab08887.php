

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Setting <small>Sistem</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="Javascript:;">Pengaturan</a></li>
      <li class="active">Setting Sistem</li>
   </ol>
   </section>
   <section class="content">
      <div class="row">
         <div class="col-md-6">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title">Setting Sistem</h3>
               </div>
               <form role="form" action="<?php echo e(url('/admin/setting', $settings->id)); ?>" method="post">
               <?php echo e(csrf_field()); ?>

                  <div class="box-body">
                     <div class="form-group<?php echo e($errors->has('nama_sistem') ? ' has-error' : ''); ?>">
                        <label>Nama Sistem : </label>
                        <input type="text" class="form-control" name="nama_sistem" value="<?php echo e($settings->nama_sistem); ?>"  placeholder="Masukkan Nama Sistem">
                        <?php echo $errors->first('nama_sistem', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('motto') ? ' has-error' : ''); ?>">
                        <label>Motto : </label>
                        <input type="text" class="form-control" name="motto" value="<?php echo e($settings->motto); ?>"  placeholder="Masukkan Motto Sistem">
                        <?php echo $errors->first('motto', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                        <label>Deskripsi : </label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Masukkan Deskripsi Sistem"><?php echo e($settings->description); ?></textarea>
                        <?php echo $errors->first('description', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('pemilik') ? ' has-error' : ''); ?>">
                        <label>Nama Pemilik : </label>
                        <input type="text" class="form-control" name="pemilik" value="<?php echo e($settings->pemilik); ?>"  placeholder="Masukkan Nama Pemilik Sistem">
                        <?php echo $errors->first('pemilik', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
                        <label>Alamat : </label>
                        <textarea name="alamat" class="form-control" rows="3" placeholder="Masukkan Alamat Kantor/Lokasi Usaha"><?php echo e($settings->alamat); ?></textarea>
                        <?php echo $errors->first('alamat', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label>Email Kontak : </label>
                        <input type="text" class="form-control" name="email" value="<?php echo e($settings->email); ?>"  placeholder="Masukkan Email">
                        <?php echo $errors->first('email', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('hotline') ? ' has-error' : ''); ?>">
                        <label>Hotline/No Telepon : </label>
                        <input type="text" class="form-control" name="hotline" value="<?php echo e($settings->hotline); ?>"  placeholder="Masukkan Hotline/Nomor Handphone kontak">
                        <?php echo $errors->first('hotline', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
                        <label>Website : </label>
                        <input type="text" class="form-control" name="website" value="<?php echo e($settings->website); ?>"  placeholder="Masukkan Website/Domain Sistem">
                        <?php echo $errors->first('website', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('skin') ? ' has-error' : ''); ?>">
                        <label>Skin : </label>
                        <div id="customColor" class="input-group" data-color="rgb(<?php echo e($settings->skin); ?>)">
                           <input type="text" class="form-control" name="skin" value="<?php echo e($settings->skin); ?>"  placeholder="">
                           <span class="input-group-addon"><i></i></span>
                        </div>
                        <small>Type skin wajib RGB</small>
                        <?php echo $errors->first('skin', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('facebook_url') ? ' has-error' : ''); ?>">
                        <label>Facebook URL : </label>
                        <input type="url" class="form-control" name="facebook_url" value="<?php echo e($settings->facebook_url); ?>"  placeholder="">
                        <?php echo $errors->first('facebook_url', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('twitter_url') ? ' has-error' : ''); ?>">
                        <label>Twitter URL : </label>
                        <input type="url" class="form-control" name="twitter_url" value="<?php echo e($settings->twitter_url); ?>"  placeholder="">
                        <?php echo $errors->first('twitter_url', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('instagram_url') ? ' has-error' : ''); ?>">
                        <label>Instagram URL : </label>
                        <input type="url" class="form-control" name="instagram_url" value="<?php echo e($settings->instagram_url); ?>"  placeholder="">
                        <?php echo $errors->first('instagram_url', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('youtube_url') ? ' has-error' : ''); ?>">
                        <label>Youtube URL : </label>
                        <input type="url" class="form-control" name="youtube_url" value="<?php echo e($settings->youtube_url); ?>"  placeholder="">
                        <?php echo $errors->first('youtube_url', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                  </div>

                  <div class="box-footer">
                     <button type="reset" class="btn btn-default">Reset</button>
                     <button type="submit" class="submit btn btn-primary">Simpan</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </section>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
   $(function(){
      $('#customColor').colorpicker({
         useAlpha: false
      });
   })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/produk3/resources/views/admin/pengaturan/sistem/index.blade.php ENDPATH**/ ?>