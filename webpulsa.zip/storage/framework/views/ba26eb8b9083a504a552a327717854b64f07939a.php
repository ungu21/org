<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Pembayaran <small>Kategori</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;"> Pembayaran</a></li>
        <li><a href="<?php echo e(route('pembayaran-kategori.index')); ?>" class="btn-loading"> Kategori</a></li>
    	<li class="active">Tambah Kategori</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-green">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(route('pembayaran-kategori.index')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Ubah Kategori</h3>
                </div>
                <form role="form" action="<?php echo e(route('pembayaran-kategori.update', $kategori->id)); ?>" method="post" enctype="multipart/form-data">
                <input name="_method" type="hidden" value="PATCH">
                <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        
                        <div class="form-group<?php echo e($errors->has('product_name') ? ' has-error' : ''); ?>">
                            <label>Nama Kategori : </label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo e($kategori->product_name ?? old('product_name')); ?>"  placeholder="Masukkan Nama Kategori">
                            <?php echo $errors->first('product_name', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('icon') ? ' has-error' : ''); ?>">
                            <label>Icon Kategori : </label>
                            <img src="<?php echo e(asset('assets/images/icon_web/'.$kategori->icon)); ?>" class="img-responsive" style="width: 50px; height: 50px;">
                            <input type="file" class="form-control image" name="icon" value="<?php echo e($kategori->icon ?? old('icon')); ?>">
                            <?php echo $errors->first('icon', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                            <label>Status Kategori : </label>
                            <select name="status" class="form-control">
                                <option value="1" <?php echo e($kategori->status == 1 ? 'selected' : ''); ?>>AKTIF</option>
                                <option value="0" <?php echo e($kategori->status == 0 ? 'selected' : ''); ?>>TIDAK AKTIF</option>
                            </select>
                            <?php echo $errors->first('status', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('sort_product') ? ' has-error' : ''); ?>">
                            <label>Nomor Urut : </label>
                            <input type="number" class="form-control" name="sort_product" value="<?php echo e($kategori->sort_product ?? old('sort_product')); ?>" placeholder="Nomor urut kategori">
                            <?php echo $errors->first('sort_product', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box box-solid box-penjelasan">
                <div class="box-header">
                    <i class="fa fa-text-width"></i>
                    <h3 class="box-title">Data Kategori Pembayaran</h3>
                    <div class="box-tools pull-right box-minus" style="display:none;">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table class="table table-hover">
                        <tr class="custom__text-green">
                            <th>Nama Kategori</th>
                            <th>Icon</th>
                            <th>Status</th>
                        </tr>
                        <?php if($kategoris->count() > 0): ?>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->product_name); ?></td>
                            <td><i class="fa fa-<?php echo e($data->icon); ?>"></i></td>
                            <?php if($data->status == 1): ?>
                            <td><label class="label label-success">AKTIF</label></td>
                            <?php else: ?>
                            <td><label class="label label-danger">TIDAK AKTIF</label></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="3" style="text-align: center;font-size: 13;font-style: italic;background-color: #F8F6F6">Data tidak ditemukan</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webpulsa\resources\views/admin/pembayaran/kategori/edit.blade.php ENDPATH**/ ?>