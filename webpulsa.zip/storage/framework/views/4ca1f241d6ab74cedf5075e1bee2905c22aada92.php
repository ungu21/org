<?php $__env->startSection('title', 'Cara Transaksi | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', 'Cara Transaksi di '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Puslsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>
<?php $__env->startSection('content-head'); ?>
   <span>
      <h1 style="text-align:left;">
        <span style="/* color: rgb(255,255,255); */">Cara Transaksi,</span><br><span style="/* color: rgb(255,255,255); */">Bersama Kami kembangkan bisnis anda</span></h1>
   </span>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<style>
  .box-content {
      border-bottom: 1px solid #e7ebee;
      padding-top: 20px;
      position: relative;
      bottom: -15px;
  }

  .text-center {
      text-align: center;
  }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="temp-wrap">
  <!-- Start Feature Section -->
 <section id="content-highlight" class="">
    <section class="content">
       <div class="container">
          <div class="row">
             <div class="col-md-12" style="margin-bottom: 30px;">
                <div class="section-heading text-center" style="margin-bottom: 30px;">
                   <h2 class="page-title">Mulai Bisnis Anda</h2>
                   <p>3 Langkah Mudah memulai bisnis anda bersama kami</p>
                </div>
             </div>
             <div class="col-sm-4 col-md-4">
                <!-- Start User Friendly Block -->
                <div class="job-info box-padding text-center">
                   <div class="block-icon">
                      <span aria-hidden="true" class="icon-browser fa-3x"></span>
                   </div>
                   <h3>Melakukan Pendaftaran</h3>
                   <p>Pendaftaran tanpa biaya 100% Gratis, setelah mendaftar akun anda langsung aktif dan dapat melakukan deposit.</p>
                </div>
                <!-- End Block -->
             </div>
             <div class="col-sm-4 col-md-4">
                <!-- Start Supper Fast Block -->
                <div class="job-info box-padding text-center">
                   <div class="block-icon">
                      <span class="icon-wallet fa-3x"></span>
                   </div>
                   <h3>Melakukan Deposit Saldo</h3>
                   <p>Langkah selanjutnya melakukan Deposit Saldo agar dapat digunakan untuk transaksi semua produk terlengkap dari kami.</p>
                </div>
                <!-- End Block -->
             </div>
             <div class="col-sm-4 col-md-4">
                <!-- Start Analytics Block -->
                <div class="job-info box-padding text-center">
                   <div class="block-icon">
                      <span class="icon-basket fa-3x"></span>
                   </div>
                   <h3>Melakukan Transaksi</h3>
                   <p>Langkah terakhir melakukan transaksi pulsa anda dengan produk pulsa terlengkap dan termurah dari kami <?php echo e($GeneralSettings->nama_sistem); ?>.</p>
                </div>
                <!-- End Block -->
             </div>
          </div>
       </div>
    </section>
  </section>
  <!-- End Feature Section -->

  <section id="content-highlight" class="">
    <section class="content">
      <div class="container">
          <div class="row">
           <div class="col-md-12" style="margin-bottom: 30px;">
              <div class="section-heading text-center" style="margin-bottom: 30px;">
                 <h2 class="page-title">Jalur Transaksi</h2>
                 <p>Kami memiliki beberapa jalur untuk melakukan transaksi.</p>
              </div>
           </div>
           <div class="col-sm-4 col-md-4">
              <!-- Start User Friendly Block -->
              <div id="box">
                <div class="box-padding text-center">
                   <div class="block-icon">
                      <span aria-hidden="true" class="fa fa-globe fa-3x"></span>
                   </div>
                   <h3>Transaksi Via Website</h3>
                   <p>Jalur transaksi kami saat ini adalah melalui website yang dapat di akses melalui perangkat komputer atau perangkat smartphone anda.</p>
                </div>
              </div>
              <!-- End Block -->
           </div>
           
           <div class="col-sm-4 col-md-4">
              <!-- Start Analytics Block -->
              <div id="box">
                <div class="box-padding text-center">
                   <div class="block-icon">
                      <span class="fa fa-telegram fa-3x"></span>
                   </div>
                   <h3>Transaksi Via Mesangger</h3>
                   <p>Kami juga menyediakan jalur transaksi melalui aplikasi messanger seperti Line, Telegram dan lain lain (coming soon).</p>
                </div>
              </div>
              <!-- End Block -->
           </div>
           <div class="col-sm-4 col-md-4">
              <!-- Start Analytics Block -->
              <div id="box">
                <div class="box-padding text-center">
                   <div class="block-icon">
                      <span class="fa fa-code fa-3x"></span>
                   </div>
                   <h3>Transaksi Via API</h3>
                   <p>API <?php echo e($GeneralSettings->nama_sistem); ?> merupakan jalur yang dapat digunakan agen/mitra/host untuk bertransaksi dengan cepat dan stabil (coming soon).</p>
                </div>
              </div>
              <!-- End Block -->
           </div>
        </div>
      </div>
    </section>
  </section>

  <!-- Start Screenshot Section -->
  <!--  <section id="content-highlight" class="">
      <section class="content">
        <div class="container">
      	  <div class="row">
      	    <div class="col-md-6 col-md-offset-3">
                <div class="section-heading text-center">
      		    <h2 class="page-title">App <?php echo e($GeneralSettings->nama_sistem); ?></h2>
      			<p><?php echo e($GeneralSettings->nama_sistem); ?> menerapkan fitur WebApps pada sistemnya sehingga website <?php echo e($GeneralSettings->nama_sistem); ?> dapat di jadikan seperti sejenis aplikasi android di smartphone anda.</p>
                </div>
              </div>
      	  </div>
      	  <div class="row">
      	    <div id="slide-screen" class="owl-carousel">
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/1.png')); ?>" alt="screenshot1"></div>
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/2.png')); ?>" alt="screenshot2"></div>
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/3.png')); ?>" alt="screenshot3"></div>
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/4.png')); ?>" alt="screenshot4"></div>
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/5.png')); ?>" alt="screenshot5"></div>
      		  <div><img class="img-rounded" src="<?php echo e(asset('assets/images/slider/6.png')); ?>" alt="screenshot6"></div>
      		</div>
      	  </div>
    	 </div>
      </section>
    </section> -->
    <!-- End Screenshot Section -->  
    
  <section id="content-highlight" class="">
      <section class="content">
        <div class="container">
          <div class="row">
      	    <div class="col-md-7 col-md-offset-3">
                <div class="section-heading text-center">
      		    <h2 class="page-title" style="font-size:20px;">Cara Memasang WebApps <?php echo e($GeneralSettings->nama_sistem); ?> Di Smartphone</h2>
      			     <small>Berikut beberapa cara untuk memasang Apps <?php echo e($GeneralSettings->nama_sistem); ?> di smartphone kamu.</small>
                <p>
                </div>
              </div>
      	   </div>
    	    <div class="row">
        	    <div id="step-1">
        	        <div class="col-md-6 text-center">
        	            <img src="<?php echo e(asset('assets/images/slider/step-1')); ?>" class="img-rounded" width="40%">
            	    </div>
            	    <div class="col-md-6">
            	        <h3>Langkah Pertama</h3>
            	        <p>Langkah pertama untuk memasang apps <?php echo e($GeneralSettings->nama_sistem); ?> di 
            	        smartphone anda adalah dengan mengakses situs <?php echo e($GeneralSettings->nama_sistem); ?> yang dapat di akses di <a href="<?php echo e(url('/')); ?>"><?php echo e($GeneralSettings->nama_sistem); ?></a>. 
            	        Dalam membuka situs <?php echo e($GeneralSettings->nama_sistem); ?> di sarankan untuk menggunakan browser Crome, karena dalam panduan ini menggunakan browser Crome.</p>
            	    </div>
        	    </div>
    	    </div>
    	    <div class="row" style="margin-top:50px;">
        	    <div id="step-2">
            	    <div class="col-md-6 text-right">
            	        <h3>Langkah Kedua</h3>
            	        <p>Langkah Kedua adalah dengan menekan 3 tanda titik pada sebelah kanan atas browser anda, 
            	        dan akan menampilkan beberapa pilihan seperti pada gambar di samping ini.
            	        Selanjutnya pilih "<b>Tambahkan Ke Layar Utama</b>" jika bahasa smartphone anda menggunakan bahasa inggris atau bahasa lainnya sesuaikan dengan pilihan tersebut.</p>
            	    </div>
            	    <div class="col-md-6 text-center">
        	            <img src="<?php echo e(asset('assets/images/slider/step-2')); ?>" class="img-rounded" width="40%">
            	    </div>
        	    </div>
    	    </div>
    	    <div class="row" style="margin-top:50px;">
        	    <div id="step-2">
        	        <div class="col-md-6 text-center">
        	            <img src="<?php echo e(asset('assets/images/slider/step-3')); ?>" class="img-rounded" width="40%">
            	    </div>
            	    <div class="col-md-6 text-left">
            	        <h3>Langkah Terakhir</h3>
            	        <p>Langkah Terakhir akan menampilan hasil dari langkah sebelumnya, saat muncul seperti gambar di samping silahkan pilih <b>Tambahkan</b> 
            	        dan selanjutnya kembali ke menu smartphone anda dan dapatkan webapps <?php echo e($GeneralSettings->nama_sistem); ?> sudah tersedia di smartphone anda.
            	        Transaksi anda akan semakin mudah dengan menggunakan salah satu fitur dari <?php echo e($GeneralSettings->nama_sistem); ?> ini.</p>
            	    </div>
            	    
        	    </div>
    	    </div>
        </div>
      </section>
  </section>

   <section class="download-separator hidden-xs">&nbsp;</section>
   <section id="download" class="download">
      <div class="container">
         <div class="download-text">
            <p class="page-title">Download Aplikasi <?php echo e($GeneralSettings->nama_sistem); ?></p>
            <!-- <p><?php echo e($GeneralSettings->motto); ?></p> -->
            <div><a href="https://play.google.com/store/apps/details?id=apps.tripay.co.id" class="download-link googleplay">&nbsp;</a></div>
            <h2 class="page-title" style="font-style: italic;"><p>"<?php echo e($GeneralSettings->motto); ?>"</p></h2>
         </div>
         <div class="download-img hidden-xs">&nbsp;</div>
      </div>
   </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webpulsa baru\produk1\resources\views/cara-transaksi.blade.php ENDPATH**/ ?>