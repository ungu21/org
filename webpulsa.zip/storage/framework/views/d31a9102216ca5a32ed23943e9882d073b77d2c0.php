

<?php $__env->startSection('content'); ?>
<style>
    /* body {
      padding: 25px;
    } */

    /* h1 {
      font-size: 1.5em;
      margin-top: 0;
    } */

    /* #table-log {
        font-size: 0.85rem;
    } */

    /* .sidebar {
        font-size: 0.85rem;
        line-height: 1;
    } */

    /* .btn {
        font-size: 0.7rem;
    } */

    .stack {
      font-size: 0.85em;
    }

    .date {
      min-width: 75px;
    }

    .text {
      word-break: break-all;
    }

    a.llv-active {
      z-index: 2;
      background-color: #f5f5f5;
      border-color: #777;
    }

    .list-group-item {
      word-wrap: break-word;
    }
  </style>
<section class="content-header">
<h1>Pengaturan <small>Log viewer</small></h1>
<ol class="breadcrumb">
 	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
    <li><a href="Javascript:;">Pengaturan</a></li>
 	<li class="active">Log viewer</li>
</ol>
</section>
<section class="content">
   <div class="row">
      <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title">Log viewer</h3>

               <div class="pull-right">
                 <?php if($current_file): ?>
                   <a href="?dl=<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($current_file)); ?>">
                     <span class="fa fa-download"></span> Download file
                   </a>
                   -
                   <a id="clean-log" href="?clean=<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($current_file)); ?>">
                     <span class="fa fa-sync"></span> Clean file
                   </a>
                   -
                   <a id="delete-log" href="?del=<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($current_file)); ?>">
                     <span class="fa fa-trash"></span> Delete file
                   </a>
                   <?php if(count($files) > 1): ?>
                     -
                     <a id="delete-all-log" href="?delall=true">
                       <span class="fa fa-trash-alt"></span> Delete all files
                     </a>
                   <?php endif; ?>
                 <?php endif; ?>
               </div>

               <!-- <a href="<?php echo e(route('bank.create')); ?>" class="btn-loading btn btn-primary pull-right" data-toggle="tooltip" data-placement="left" title="Tambah Data Bank" style="padding: 3px 7px;"><i class="fa fa-plus"></i></a> -->
            </div><!-- /.box-header -->
            <div class="box-body table-responsive">
                  <div class="col-md-12 table-container">
                    <h4><i class="fa fa-calendar" aria-hidden="true"></i> Laravel Log Viewer</h4>
                    <div class="list-group">
                      <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="?l=<?php echo e(\Illuminate\Support\Facades\Crypt::encrypt($file)); ?>"
                           class="list-group-item <?php if($current_file == $file): ?> llv-active <?php endif; ?>">
                          <?php echo e($file); ?>

                        </a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($logs === null): ?>
                      <div>
                        Log file >50M, please download it.
                      </div>
                    <?php else: ?>
                      <table id="table-log" class="table table-striped" data-ordering-index="<?php echo e($standardFormat ? 2 : 0); ?>">
                        <thead>
                        <tr>
                          <?php if($standardFormat): ?>
                            <th>Level</th>
                            <th>Context</th>
                            <th>Date</th>
                            <th></th>
                          <?php else: ?>
                            <th>Line number</th>
                            <th></th>
                          <?php endif; ?>
                          <th>Content</th>
                          <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr data-display="stack<?php echo e($key); ?>">
                            <?php if($standardFormat): ?>
                              <td class="text-<?php echo e($log['level_class']); ?>"><span class="fa fa-<?php echo e($log['level_img']); ?>" aria-hidden="true"></span> &nbsp;<?php echo e($log['level']); ?></td>
                              <td class="text"><?php echo e($log['context']); ?></td>
                              <td></td>
                            <?php endif; ?>
                            <td class="date"><?php echo e($log['date']); ?></td>
                            <td class="text">
                              <?php echo e($log['text']); ?>

                              <?php if(isset($log['in_file'])): ?> <br/><?php echo e($log['in_file']); ?><?php endif; ?>
                              <?php if($log['stack']): ?>
                                <div class="stack" id="stack<?php echo e($key); ?>"
                                     style="display: none; white-space: pre-wrap;"><?php echo e(trim($log['stack'])); ?>

                                </div><?php endif; ?>
                            </td>
                            <td class="text">
                              <?php if($log['stack']): ?>
                                <button type="button" class="float-right expand btn btn-outline-dark btn-sm mb-2 ml-2" data-display="stack<?php echo e($key); ?>">
                                  <span class="fa fa-search"></span>
                                </button>
                              <?php endif; ?>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    <?php endif; ?>
                  </div>
            </div>
        </div>
      </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $(document).ready(function () {
    $('.table-container tr').on('click', function () {
      $('#' + $(this).data('display')).toggle();
    });

    Pace.track(function(){
      $('#table-log').DataTable({
        "order": [$('#table-log').data('orderingIndex'), 'desc'],
        "stateSave": true,
        "stateSaveCallback": function (settings, data) {
          window.localStorage.setItem("datatable", JSON.stringify(data));
        },
        "stateLoadCallback": function (settings) {
          var data = JSON.parse(window.localStorage.getItem("datatable"));
          if (data) data.start = 0;
          return data;
        }
      });
    });

    $('#delete-log, #clean-log, #delete-all-log').click(function () {
      return confirm('Are you sure?');
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mydn5829/system/resources/views/vendor/laravel-log-viewer/log.blade.php ENDPATH**/ ?>