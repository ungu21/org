<?php $__env->startSection('title', $GeneralSettings->nama_sistem. ' | '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Agen Pulsa Murah, Pulsa Online 24 Jam, Distributor Pulsa, Bisnis menguntungkan, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>
<?php $__env->startSection('css'); ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
<style type="text/css">
   .navbar, .ms-header, .ms-footer, .ms-footbar {
         display: relative;
   }
   #order_form .form-group label.control-label{color:#fff!important;margin: 3px 0 0;}
   #order_form .form-group .form-control{background-color: #03a9f4!important;}
   #order_form .form-control{color:#fff!important;}
   #order_form .form-group{padding-bottom: 0px;margin: 0px 0 0;}
   .card-payment{
      margin-left:15px;
      border-radius: 8px;
      border: none;
   }
   .payment-card{
      padding: 1rem;
      text-align: center !important;
   }
   
   .card-payment > .payment-card{
      width: 150px; 
      height: 73px;
      box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      -webkit-box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      -moz-box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      border: none;
      border-radius: 8px;
   }
   
   .card-payment > .payment-card:hover{
      width: 150px; 
      height: 73px;
      box-shadow: 0px 8px 24px 0px var(--custom-color) !important;
      -webkit-box-shadow: 0px 8px 24px 0px var(--custom-color-hover) !important;
      -moz-box-shadow: 0px 8px 24px 0px var(--custom-color-hover) !important;
      border: solid 1px var(--custom-color);
      border-radius: 8px;
   }
    .mobile-none{
      display:none;
    }
    .mobile-block{
      display:block;
    }

@media(min-width:576px){
    .mobile-none{
      display:block !important;
    }
    .mobile-block{
      display:none !important;
    }
}

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<header class="ms-hero ms-hero-material" style="padding: 30px 0;">
      <div class="container index-1">
         <div class="row">
            <div class="col-lg-7 mobile-none">
               <h1 class="text-uppercase animated fadeInDown animation-delay-5 typed-title">Kenapa harus <?php echo e($GeneralSettings->nama_sistem); ?> ?</h1>
               <p class="lead lead-sm animated fadeInLeft animation-delay-7 color-light">Beberapa keuntungan & kelebihan dibanding yang lain</p>
               <ul class="ms-list-arrow">
                  <li class="animated fadeInUp animation-delay-7">Harga lebih murah dibanding harga di konter-konter dekat rumah Anda.</li>
                  <li class="animated fadeInUp animation-delay-10">Kapan pun Anda bisa melakukan pembelian karena buka 24 jam non stop.</li>
                  <li class="animated fadeInUp animation-delay-13">Transaksi diproses secara cepat dan otomais oleh sistem dalam hitungan detik.</li>
               </ul>
               <div class="ms-margin">
                  <a class="btn btn-primary btn-raised btn-app wow flipInX animation-delay-20" href="javascript:void(0)">
                  <div class="btn-container">
                     <i class="fa fa-html5"></i> <span>Tersedia di</span><br>
                     <strong>Web App</strong>
                  </div></a> <a class="btn btn-primary btn-raised btn-app wow flipInX animation-delay-26" href="javascript:void(0)">
                  <div class="btn-container">
                     <i class="fa fa-android"></i> <span>Tersedia di</span><br>
                     <strong>Play Store</strong>
                  </div></a>
               </div>
            </div>
            <div class="col-lg-5 mt-4">
                  <div class="card card-primary-inverse">
                     <div class="card-header">
                      <ul class="nav nav-tabs" style="background:none">
                        <li ="current"><a data-toggle="tab" href="#home" class="active show">Pembelian</a></li>
                        <li><a data-toggle="tab" href="#menu1">Tagihan PPOB</a></li>
                      </ul>
                     </div>
                     <div class="card-body">

                  <div class="tab-content">
                    <div id="home" class="tab-pane fade in active show">
                      <div id="order_form" class="form-horizontal">
                        <div class="form-group is-empty">
                           <label class="control-label" for="kategori_pembelian">Pembelian</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-tags" style="padding-top: 10px;"></i>
                              </span>
                              <select class="form-control" id="kategori_pembelian">
                                 <option>-- Pilih Pembelian --</option>
                                 <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->product_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                        
                        <div class="form-group is-empty">
                           <label class="control-label" for="nomor-hp">Nomor HP</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-address-book-o" style="padding-top: 10px;"></i>
                              </span>
                              <input type="number" id="target_pembelian" placeholder="Nomor HP" name="target" class="form-control" required="required" autocomplete="off">
                           </div>
                        </div>
                        
                        <div class="form-group is-empty" id="operator_pembelian_field">
                           <label class="control-label" for="produk-select">Operator</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-signal" style="padding-top: 10px;"></i>
                              </span>
                              <select class="form-control" name="pembelian_operator" id="pembelian_operator">
                                 <option>-- Pilih Operator --</option>
                              </select>
                           </div>
                        </div>
                        
                        <div class="form-group is-empty" id="meteranpln_field">
                           <label class="control-label" for="nomor-hp">Nomor Meteran</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-bolt" style="padding-top: 10px;"></i>
                              </span>
                              <input id="no_meter_pln" name="no_meter_pln" type="number" class="form-control" placeholder="ID Pelanggan" required="required" maxlength="64" autocomplete="off">
                           </div>
                        </div>
                        
                        <div class="form-group is-empty">
                           <label class="control-label" for="produk-select">Pilih Produk</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-tablet" style="padding-top: 10px;"></i>
                              </span>
                              <select class="form-control" name="pembelian_produk" id="pembelian_produk">
                                 <option>-- Pilih Produk --</option>
                              </select>
                           </div>
                        </div>
                        
                        <div class="row">
                            
                        <?php if((Auth::check())): ?>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-left" id="pin">
                                 <div class="form-group is-empty" style="padding: 8px 0 0 8px">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="fa fa-lock" style="padding-top: 10px;"></i></span> <input autocomplete="off" class="form-control" id="pin_pembelian" name="pin" placeholder="PIN Transaksi" required="required" type="text">
                                    </div>
                                 </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-center" style="margin-bottom: 0">
                                 <button class="btn btn-warning btn-raised btn-block" onclick="beli()">Order Sekarang</button>
                              </div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-6 col-xs-6">
                              
                            </div>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-center" style="margin-bottom: 0">
                                <a href="<?php echo e(url('/login')); ?>" class="btn btn-warning btn-raised btn-block">
                                 Order Sekarang
                                </a>
                              </div>
                            </div>
                        <?php endif; ?>
                           
                        </div>
                    </div>
                </div>
                <div id="menu1" class="tab-pane fade">
                    <div id="home" class="tab-pane fade in active show">
                      <div id="order_form" class="form-horizontal">
                        <div class="form-group is-empty">
                           <label class="control-label" for="kategori_pembelian">Provider/Operator</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-tags" style="padding-top: 10px;"></i>
                              </span>
                              <select class="form-control" id="provider_tagihan">
                                 <option>-- Pilih Pembayaran --</option>
                                <?php $__currentLoopData = $tagihan_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan_provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tagihan_provider->id); ?>"><?php echo e($tagihan_provider->product_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>
                        
                        <div class="form-group is-empty">
                           <label class="control-label" for="produk-select">Jenis Tagihan</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-tablet" style="padding-top: 10px;"></i>
                              </span>
                              <select class="form-control" name="product_tagihan" id="product_tagihan">
                                 <option>-- Pilih Jenis Tagihan --</option>
                              </select>
                           </div>
                        </div>
                        
                        <div class="form-group is-empty">
                           <label class="control-label" for="nomor-hp">ID Pelanggan</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-address-book-o" style="padding-top: 10px;"></i>
                              </span>
                              <input type="number" id="id_pelanggan" placeholder="Nomor / ID Pelanggan" name="nomor_rekening" class="form-control" required="required" autocomplete="off">
                           </div>
                        </div>
                        
                        <div class="form-group is-empty">
                           <label class="control-label" for="nomor-hp">Nomor HP</label>
                           <div class="input-group">
                              <span class="input-group-addon">
                              <i class="fa fa-address-book-o" style="padding-top: 10px;"></i>
                              </span>
                              <input type="number" id="no_hp" placeholder="Nomor HP" name="target_pembayaran" class="form-control" required="required" autocomplete="off">
                           </div>
                        </div>
                        
                        <div class="row">
                            
                        <?php if((Auth::check())): ?>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-left" id="pin">
                                 <div class="form-group is-empty" style="padding: 8px 0 0 8px">
                                    <div class="input-group">
                                       <span class="input-group-addon"><i class="fa fa-lock" style="padding-top: 10px;"></i></span> <input autocomplete="off" class="form-control" id="pin_tagihan" name="pin" placeholder="PIN Transaksi" required="required" type="text">
                                    </div>
                                 </div>
                              </div>
                            </div>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-center" style="margin-bottom: 0">
                                 <button class="btn btn-warning btn-raised btn-block" id="cek_tagihan">Order Sekarang</button>
                              </div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-6 col-xs-6">
                              
                            </div>
                            <div class="col-md-6 col-xs-6">
                              <div class="form-group text-center" style="margin-bottom: 0">
                                <a href="<?php echo e(url('/login')); ?>" class="btn btn-warning btn-raised btn-block">
                                 Order Sekarang
                                </a>
                              </div>
                            </div>
                        <?php endif; ?>
                           
                        </div>
                    </div>
                </div>
              </div>
                        
                     </div>
                  </div>
               </div>
         </div>
             <div class="col-lg-7 mobile-block">
               <h1 class="text-uppercase animated fadeInDown animation-delay-5 typed-title">Kenapa harus <?php echo e($GeneralSettings->nama_sistem); ?> ?</h1>
               <p class="lead lead-sm animated fadeInLeft animation-delay-7 color-light">Beberapa keuntungan & kelebihan dibanding yang lain</p>
               <ul class="ms-list-arrow">
                  <li class="animated fadeInUp animation-delay-7">Harga lebih murah dibanding harga di konter-konter dekat rumah Anda.</li>
                  <li class="animated fadeInUp animation-delay-10">Kapan pun Anda bisa melakukan pembelian karena buka 24 jam non stop.</li>
                  <li class="animated fadeInUp animation-delay-13">Transaksi diproses secara cepat dan otomais oleh sistem Kami.</li>
               </ul>
               <div class="ms-margin">
                  <a class="btn btn-primary btn-raised btn-app wow flipInX animation-delay-20" href="javascript:void(0)">
                  <div class="btn-container">
                     <i class="fa fa-html5"></i> <span>Tersedia di</span><br>
                     <strong>Web App</strong>
                  </div></a> <a class="btn btn-primary btn-raised btn-app wow flipInX animation-delay-26" href="javascript:void(0)">
                  <div class="btn-container">
                     <i class="fa fa-android"></i> <span>Tersedia di</span><br>
                     <strong>Play Store</strong>
                  </div></a>
               </div>
            </div>
      </div>
   </header>
   <div class="container mt-6">
      <section class="mb-4">
         <h2 class="text-center no-mt mb-6 wow fadeInUp">Kami berikan yang terbaik</h2>
         <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-shopping-bag"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Kesempatan Menjadi Reseller</h4>
                     <p>Anda bisa meningkatkan akun menjadi Reseller dan dapatkan harga termurah.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-gift"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Tersedia Produk Promo</h4>
                     <p>Dapatkan produk promo khusus untuk Anda yang telah bergabung bersama kami.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-user-plus"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Pendaftaran Gratis</h4>
                     <p>Kami tidak memungut biaya untuk pendaftaran menjadi member Kami</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-money"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Isi Deposit Terjangkau</h4>
                     <p>Cukup mengisi deposit (saldo akun) anda bisa menikmati keuntungannya</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-credit-card"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Proses Transaksi Semakin Mudah</h4>
                     <p>Anda tak perlu transfer berulang-ulang cukup isi deposit akun untuk transaksi.</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 mb-2">
               <div class="ms-icon-feature wow flipInX animation-delay-4">
                  <div class="ms-icon-feature-icon">
                     <span class="ms-icon ms-icon-lg ms-icon-inverse"><i class="fa fa-bell-o"></i></span>
                  </div>
                  <div class="ms-icon-feature-content">
                     <h4 class="color-primary">Tersedia Laporan Transaksi</h4>
                     <p>Laporan transaksi akan dikirimkan ke akun dan email yang anda daftarkan</p>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div><!-- container -->
   <div class="wrap ms-hero-img-keyboard ms-hero-bg-info color-dark hidden-xs">
      <div class="container">
         <h1 class="color-white text-center mb-4">kami dalam angka</h1>
         <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
               <div class="card card-royal card-body text-center wow zoomInUp animation-delay-2">
                  <h2 class=""><span id="total_trx_sukses"><?php echo e($totaltransaksi); ?></span></h2><i class="fa fa-4x fa-refresh fa-spin color-royal"></i>
                  <p class="mt-2 no-mb lead small-caps">total transaksi</p>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <div class="card card-success card-body text-center wow zoomInUp animation-delay-5">
                  <h2 class=""><span id="total_users"><?php echo e($totaluser); ?></span></h2><i class="fa fa-4x fa-user-plus color-success"></i>
                  <p class="mt-2 no-mb lead small-caps">member terdaftar</p>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <div class="card card-danger card-body text-center wow zoomInUp animation-delay-4">
                  <h2 class=""><span id="total_providers"><?php echo e($totaloperator); ?></span></h2><i class="fa fa-4x fa-ticket color-danger"></i>
                  <p class="mt-2 no-mb lead small-caps">total operator</p>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <div class="card card-info card-body text-center wow zoomInUp animation-delay-3">
                  <h2 class=""><span id="total_vouchers"><?php echo e($totalproduk); ?></span></h2><i class="fa fa-4x fa-tags color-info"></i>
                  <p class="mt-2 no-mb lead small-caps">total produk</p>
               </div>
            </div>
         </div>
         <div class="text-center color-white mw-800 center-block mt-4">
            <p class="lead lead-lg">Semakin bertambahnya transaksi dan member yang terdaftar, kami akan selalu meningkatkan kualitas layanan kami</p><a class="btn btn-raised btn-white color-info wow flipInX animation-delay-8" href="contact-us"><i class="fa fa-space-shuttle"></i> Ada masalah? Lapor segera</a>
         </div>
      </div>
   </div>
   <div class="container mt-6">
      <div class="card wow fadeInUp">
         <div class="card-body card-body-big">
            <h3 class="text-center fw-500">Testimonials</h3>
            <div class="mw-800 center-block">
            <?php if($testimonials->count() > 0): ?>
            <?php 
                $i = 0;
            ?>
               <div class="carousel-cards carousel slide" data-ride="carousel" id="carousel-example-generic">
                  <div class="carousel-inner pb-4" role="listbox">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="carousel-item <?php echo e($i == 0 ? 'active' : ''); ?>">
                        <blockquote class="blockquote ms-blockquote">
                           <p class="lead"><?php echo e($data->review); ?></p>
                           <footer>
                              <strong><?php echo e($data->user->name); ?></strong>,
                              <cite title="Source Title"><?php echo e($data->user->city); ?></cite>
                           </footer>
                        </blockquote>
                     </div>
                <?php
                    $i++;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
               <ol class="carousel-indicators carousel-indicators-primary">
                <?php for($no = 0; $no < $i; $no++): ?>
                        <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($no); ?>" class="<?php echo e($no == 0 ? 'active' : ''); ?>"></li>
                <?php endfor; ?>
               </ol>
               </div>
            <?php else: ?>
                Belum Ada Testimoni
            <?php endif; ?>
            </div>
         </div>

         <div class="text-center mb-4">
            <a class="btn btn-raised btn-primary color-white wow flipInX animation-delay-8" href="<?php echo e(url('/testimonial')); ?>" style="visibility: visible; animation-name: flipInX;"><i class="fa fa-list"></i> Lihat Semua<div class="ripple-container"></div></a>
         </div>
      </div>
   </div><!-- container -->
   <div class="wrap ms-hero-img-coffee ms-hero-bg-dark ms-bg-fixe mt-6">
      <div class="container">
         <div class="text-center mb-4">
            <h2 class="uppercase color-white">FAQ</h2>
            <p class="lead uppercase color-light">Hal yang sering ditanyakan</p>
         </div>
         <div class="row">
        <?php if($faqs->count() > 0): ?>
         <?php $i=1 ?>
         <?php $__currentLoopData = array_chunk($faqs->all(), 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-sm-6">
            <div class="panel-group ms-collapse no-margin" id="accordion<?php echo e($i); ?>" role="tablist" aria-multiselectable="true">
            <!-- Start FAQ Block -->
            <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-info">
                  <div class="card-header" role="tab" id="heading_<?php echo e($data->id); ?>">
                    <h4 class="card-title ms-rotate-icon">
                      <a class="withripple collapsed" role="button" data-toggle="collapse" href="#collapse-<?php echo e($data->id); ?>" aria-expanded="false" aria-controls="collapse-<?php echo e($data->id); ?>">
                        <i class="zmdi zmdi-help-outline"></i> Q : <?php echo e($data->pertanyaan); ?> <div class="ripple-container"></div></a>
                    </h4>
                  </div>
                  <div id="collapse-<?php echo e($data->id); ?>" class="card-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo e($data->id); ?>" data-parent="#accordion<?php echo e($i); ?>" style="">
                    <div class="card-body">
                      <p><?php echo e($data->jawaban); ?></p>
                    </div>
                  </div>
               </div>
               <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End FAQ Block -->
         </div>
         <?php $i++ ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
         </div>
      </div><!--container -->
   </div><!-- container -->
   <section class="mt-4 hidden-xs">
      <div class="container">
         <h1 class="color-primary text-center mb-4">Metode Pembayaran</h1>
         <div class="row d-flex justify-content-center">
            <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-xs-4 col-sm-4 mb-1">
               <div class="card wow fadeInUp card-payment" style="visibility: visible; animation-name: fadeInUp;">
                  <div class="payment-card">
                     <img alt="Bank BCA" class="" width="auto" height="30px" src="<?php echo e(url('img/banks/'.$data->image)); ?>">
                  </div>
               </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </div>
      </div>
   </section>
  <!-- Modal -->
    <div aria-labelledby="myModalLabel" class="modal fade modal-primary" id="myModal" role="dialog" tabindex="-1">
		<div class="modal-dialog animated zoomIn animated-3x" role="document">
			<div class="modal-content">
				<div class="modal-body" id="modal_body" style="padding: 20px 25px 5px;">
					<h2 class="text-warning" style="margin-bottom: 0px;margin-top: 0px;font-style:bold">Detail Tagihan</h2><hr style="margin:1rem 0 1rem">
					<div class="box-body" style="color: #6E6C6C">
						<form action="<?php echo e(route('bayartagihan')); ?>" id="boxresult" method="post" name="boxresult"></form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js"></script>
<script>
//untuk format rupiah
function rupiah(nStr) {
       nStr += '';
       x = nStr.split('.');
       x1 = x[0];
       x2 = x.length > 1 ? '.' + x[1] : '';
       var rgx = /(\d+)(\d{3})/;
       while (rgx.test(x1))
       {
          x1 = x1.replace(rgx, '$1' + '.' + '$2');
       }
       return "Rp " + x1 + x2;
}


$("#meteranpln_field").hide();
$("#operator_pembelian_field").hide();
$("#kategori_pembelian").on('change', function() {
    var kategori_pembelian = $("#kategori_pembelian").val();
    console.log(kategori_pembelian);
    if( kategori_pembelian == 7){
        $("#meteranpln_field").show();
        $("#operator_pembelian_field").hide();
        get_produk(kategori_pembelian);
    }else{
        $("#meteranpln_field").hide();
        $("#operator_pembelian_field").show();
        get_operator_pembelian(kategori_pembelian);
        $("#no_meter_pln").val('');
    }
});

$("#pembelian_operator").on('change', function() {
    var pembelian_operator = $("#pembelian_operator").val();
    get_produk(pembelian_operator);
});

$("#target_pembelian").on("input propertychange paste", function() {
    if($("#kategori_pembelian").val() == 1 || $("#kategori_pembelian").val() == 2){
        if ( $("#target_pembelian").val().length > 3){
           var prefix = $("#target_pembelian").val().substring(0, 4);
           getPulsa(prefix, $("#kategori_pembelian").val());
        }
        if ( $("#target_pembelian").val().length == 0){
           get_operator_pembelian($("#kategori_pembelian").val());
        }  
    }
   
});

function getPulsa($prefix, $parent) {
    $('#pembelian_produk').empty().append('<option value="" selected="selected">Loading...</option>');
    $('#pembelian_operator').empty().append('<option value="" selected="selected">Loading...</option>');
    $.ajax({
        url: 'process/prefixproduct',
        dataType: "json",
        type: "GET",
        data: {
            'prefix': $prefix,
            'parent': $parent
        },
        success: function (response) {
            $('#pembelian_produk').empty();
            $('#pembelian_operator').empty();
            $.each(response.produk, function(index, produkObj){
                harga = parseInt(produkObj.price);
                if (produkObj.status == 0) {
                    $('#pembelian_produk').append('<option value="'+produkObj.product_id+'" style="color: #C8C8C8;" disabled>'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                }else{
                    $('#pembelian_produk').append('<option value="'+produkObj.product_id+'">'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                }
            });
            $.each(response.operator, function(index, operatorObj){
                if (operatorObj.status == 0) {
                    $('#pembelian_operator').append('<option value="'+operatorObj.id+'" style="color: #C8C8C8;" disabled>'+operatorObj.product_name+'</option>');
                }else{
                    $('#pembelian_operator').append('<option value="'+operatorObj.id+'">'+operatorObj.product_name+'</option>');
                }
            });
        },
        error: function (response) {
            toastr.error("Data tidak ditemukan, periksa kembali nomor handphone tujuan anda");
            $('#pembelian_operator').empty();
            $('#pembelian_operator').append('<option value="" selected="selected">Pilih Operator ...</option>');
            $('#pembelian_produk').empty();
            $('#pembelian_produk').append('<option value="" selected="selected">Pilih Produk ...</option>');
        }
    });
}

function get_operator_pembelian($id){
    $('#pembelian_operator').html('<option value="" selected="selected">Loading...</option>');
    $('#pembelian_produk').html('<option value="" selected="selected">Loading...</option>');
        $.ajax({
            url: '/process/getoperator',
            dataType: "json",
            type: "GET",
            data: {
                'category': $id
            },
            success: function (response) {
                if(response.length != 0){
                    $('#pembelian_operator').html('<option value="" selected="selected">Pilih Operator ...</option>');
                    $('#pembelian_produk').html('<option value="" selected="selected">Pilih Produk ...</option>');
                    $.each(response, function(index, operatorObj){
                        if (operatorObj.status == 0) {
                            $('#pembelian_operator').append('<option value="'+operatorObj.id+'" style="color: #C8C8C8;" disabled>'+operatorObj.product_name+'</option>');
                        }else{
                            $('#pembelian_operator').append('<option value="'+operatorObj.id+'">'+operatorObj.product_name+'</option>');
                        }
                    });
                }
            },
            error: function (response) {
                toastr.error("Data tidak ditemukan, periksa kembali nomor handphone tujuan anda");
                $('#pembelian_operator').html('<option value="" selected="selected">-- Pilih Operator --</option>');
                $('#pembelian_produk').html('<option value="" selected="selected">-- Pilih Peoduk --</option>');
            }
        });
}

function get_produk($id){
    $('#pembelian_produk').html('<option value="" selected="selected">Loading...</option>');
        $.ajax({
            url: 'process/findproduct',
            dataType: "json",
            type: "GET",
            data: {
                'category_id': $id
            },
            success: function (response) {
                if(response.length != 0){
                    $('#pembelian_produk').html('<option value="" selected="selected">Pilih Produk ...</option>');
                    $.each(response, function(index, operatorObj){
                        if (operatorObj.status == 0) {
                            $('#pembelian_produk').append('<option value="'+operatorObj.product_id+'" style="color: #C8C8C8;" disabled>'+operatorObj.product_name+'</option>');
                        }else{
                            $('#pembelian_produk').append('<option value="'+operatorObj.product_id+'">'+operatorObj.product_name+'</option>');
                        }
                    });
                }
            },
            error: function (response) {
                toastr.error("Terjadi Kesalahan, Permintaan tidak dapat diproses");
                $('#pembelian_produk').html('<option value="" selected="selected">-- Pilih Peoduk --</option>');
            }
        });
}

function beli(){
    $.blockUI({ css: {
        border: 'none',
        padding: '15px',
        backgroundColor: '#000',
        '-webkit-border-radius': '10px',
        '-moz-border-radius': '10px',
        opacity: .5,
        color: '#fff'
    } });
    
    var target = $('#target_pembelian').val();
    var pin = $('#pin_pembelian').val();
    var product = $('#pembelian_produk').val();
    
    if($("#kategori_pembelian").val() == 7){
        var no_meter_pln = $('#no_meter_pln').val();
        if( no_meter_pln == '' ){
            $.unblockUI();
            toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
            return false;
        }
    }else{
        var provider = $('#pembelian_operator').val();
        if( provider == '' ){
            $.unblockUI();
            toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
            return false;
        }
    }
    if( target == '' || pin == '' || product == '' ){
        $.unblockUI();
        toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
        return false;
    }
    
    $.ajax({
        url: "member/process/orderproduct/home",
        method: "POST",
        data: {
            _token:"<?php echo e(csrf_token()); ?>",
            'target': target,
            'no_meter_pln' : no_meter_pln,
            'pin': pin,
            'produk':product,
            'pembelianoperator_id': $('#pembelian_operator').val(),
            'type': $('#pembelian_operator').val()
        },
        success: function(response){
            if (response.success == false) {
                $.unblockUI();
                toastr.error(response.message);
                return;
            }
            $.unblockUI();
            toastr.success(response.message);
        
            $('#target_'+$category).val('')
            $('#pin_'+$category).val('')
            getOperator($category, $id);
            
        },
        error: function(response){
            $.unblockUI();
            if(response.success == 0){
            toastr.error(response.message)
            return false;
            }
        }
    })
}

$('#provider_tagihan').on('change', function(e){
    var pembayaranoperator_id = $('#provider_tagihan').val();
   $('#product_tagihan').empty();
   $('#product_tagihan').append('<option value="" selected="selected">Loading...</option>');
    $.ajax({
        url: '/process/findproduct/pembayaran',
        dataType: "json",
        type: "GET",
        data: {
            'pembayaranoperator_id': pembayaranoperator_id,
        },
        success: function (response) {
            $('#product_tagihan').empty();
            if(response.length != 0){
                $.each(response, function(index, produkObj){
                    harga = parseInt(produkObj.price_markup);
                    if (produkObj.status == 0) {
                        $('#product_tagihan').append('<option value="'+produkObj.product_name+'" style="color: #C8C8C8;" disabled>'+produkObj.product_name+' ('+rupiah(harga)+')</option>');
                    }else{
                        $('#product_tagihan').append('<option value="'+produkObj.code+'">'+produkObj.product_name+' <b>(Biaya Admin '+rupiah(harga)+')</b></option>');
                    }
                });
            }else{
                toastr.error("Sistem sedang melakukan MAINTENANCE, untuk itu kami mohon untuk tidak melakukan transaksi terlebih dahulu. Trimakasih");
            }
        },
        error: function (response) {
            $('#product_tagihan').empty();
            $('#product_tagihan').append('<option value="" selected="selected">-- Pilih Produk --</option>');
            toastr.error("TERJADI KESALAHAN, SILAHKAN REFRESH HALAMAN DAN LAKUKAN LAGI.");
        }
    });
});

$('#cek_tagihan').on('click', btnCekTagihan);
function btnCekTagihan(){
    $.blockUI({ css: {
          border: 'none',
          padding: '15px',
          backgroundColor: '#000',
          '-webkit-border-radius': '10px',
          '-moz-border-radius': '10px',
          opacity: .5,
          color: '#fff'
      } });
    var pembayaranoperator_id = $('#provider_tagihan').val();
    var produk_pembayaran = $('#product_tagihan').val();
    var nomor_rekening = $('#id_pelanggan').val();
    var target = $('#no_hp').val();
    var pin = $('#pin_tagihan').val();

    if( produk_pembayaran == '' || nomor_rekening == '' || target == '' || pin == '' ){
        $.unblockUI();
        toastr.error("MOHON MAAF, BIDANG ISIAN OPERATOR TIDAK BOLEH KOSONG.");
        //return false;
    }

    $.ajax({
        url: "member/process/cektagihan/home",
        method: "POST",
        data: {
            _token:"<?php echo e(csrf_token()); ?>",
            'submit':$('input[name=submit]').val(),
            'produk': produk_pembayaran,
            'nomor_rekening': nomor_rekening,
            'target': target,
            'pin': pin
        },
    
        success: function(response){
            if (response.success == false) {
                $.unblockUI();
                toastr.error(response.message);
                return false;
            }else{
                var order_id = response.id;
                var tagihan_id = response.tagihan_id;
                var tanggal = response.created_at;
                var phone = response.phone;
                var nama = response.nama;
                var bulan = response.periode;
                var produk_ppob = response.product_name;
                var no_pelanggan = response.no_pelanggan;
                var jml_tagihan = parseInt(response.jumlah_tagihan);
                var jml_bayar = parseInt(response.jumlah_bayar);
                var admin = parseInt(response.admin);
                var token = response.token;
                $.unblockUI();
                $('#boxresult').empty();
                $('#boxresult').append('<input type="hidden" name="_token" value="'+token+'">');
                $('#boxresult').append('<input type="hidden" name="order_id" value="'+order_id+'">');
                $('#boxresult').append('<input type="hidden" name="tagihan_id" value="'+tagihan_id+'">');
                $('#boxresult').append('<input type="hidden" name="jumlah_tagihan" value="'+jml_tagihan+'">');
                $('#boxresult').append('<input type="hidden" name="admin" value="'+admin+'">');
                $('#boxresult').append('<input type="hidden" name="harga" value="'+jml_bayar+'">');
                $('#boxresult').append('<input type="hidden" name="bulan" value="'+bulan+'">');
                $('#boxresult').append('<input type="hidden" name="produk_ppob" value="'+produk_ppob+'">');
                $('#boxresult').append('<input type="hidden" name="target_phone" value="'+phone+'">');
                $('#boxresult').append('<div id="box-body" style="color:black">');
                $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Order ID</span><span class="pull-right" style="font-size:14px">Tanggal</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+order_id+'</span><span class="pull-right" style="font-size:14px">'+tanggal+'</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nomor Handphone</span><span class="pull-right" style="font-size:14px">Jumlah Tagihan</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+phone+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(jml_tagihan)+'</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nomor / ID Pelanggan</span><span class="pull-right" style="font-size:14px">Admin</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+no_pelanggan+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(admin)+'</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Nama Pelanggan</span><span class="pull-right" style="font-size:14px">Jumlah Bayar</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div><span class="pull-left text-primary" style="font-size:18px;font-weight:bold;">'+nama+'</span><span class="pull-right text-primary" style="font-size:18px;font-weight:bold;">'+rupiah(jml_bayar)+'</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div style="margin-top:5px"><span class="pull-left" style="font-size:14px">Status</span></div><div class="clearfix"></div>');
                $('#box-body').append('<div><span class="pull-left text-default" style="font-size:18px;font-weight:bold;">MENUNGGU</span></div><div class="clearfix"></div>');
                $('#box-body').append('<button type="submit" id="bayar" class="btn btn-default btn-block btn-lg">Bayar Tagihan</button>');
                $('#myModal').modal('show');
            }
        },
        error: function(response){
            $.unblockUI();
            if(response.success == 0){
                showalert(response.message, 'danger');
                toastr.error(response.message);
                return false;
            }
        }
    })
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webpulsa baru\produk2\resources\views/home.blade.php ENDPATH**/ ?>