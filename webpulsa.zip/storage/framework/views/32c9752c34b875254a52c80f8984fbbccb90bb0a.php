<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('/admin-lte/plugin/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Halaman <small><a href="<?php echo e(url($page->slug)); ?>" class="custom__text-green" target="_blank"><?php echo e($page->title); ?></a></small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;">Halaman Statis</a></li>
    	<li class="active"><?php echo e($page->title); ?></li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-8">
            <div class="box box-green">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e($page->title); ?></h3><br/>
                    <a href="<?php echo e(url($page->slug)); ?>" class="custom__text-green" target="_blank"><?php echo e(url($page->slug)); ?></a>
                </div>
                <form role="form" action="" method="POST">
                <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group">
                            <label>Judul : </label>
                            <input type="text" class="form-control" name="title" placeholder="" style="width: 100%; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" value="<?php echo e($page->title); ?>" required>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="form-group">
                            <label>Isi Konten : </label>
                            <textarea class="textarea" name="content" placeholder="" style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo e(html_entity_decode($page->content, ENT_QUOTES)); ?></textarea>
                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('/admin-lte/plugin/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script>
    $(function() {
        $('textarea[name=content]').wysihtml5();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebProgramming\WebpulsaNew\newpay\resources\views/admin/static-page.blade.php ENDPATH**/ ?>