
<?php $__env->startSection('title', 'Kebijakan Privasi | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Kebijakan Privasi
          </h1>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                <p>
                    <?php
                        $content = html_entity_decode($page->content, ENT_QUOTES);
                        $content = str_replace('[site_name]', $GeneralSettings->nama_sistem, $content);
                        $content = str_replace('[site_url]', url('/'), $content);
                        $content = str_replace('[site_motto]', $GeneralSettings->motto, $content);
                    ?>
                    <?php echo $content; ?>

                </p>
            </div> 
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/privacy-policy.blade.php ENDPATH**/ ?>