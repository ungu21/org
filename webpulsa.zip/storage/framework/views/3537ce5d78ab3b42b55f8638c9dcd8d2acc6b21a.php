<?php $__env->startSection('title', 'Testimonial | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', 'Testimonial Agen, Mitra & Pembeli tetang '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Slideshow Section -->
<section id="slideshow">
   <div class="container">
      <div class="row">
         <div class="no-slider" style="margin-top: 100px;">
            <div class="animate-block" style="text-align: center;">
            <div class="col-md-6 col-md-offset-3">
               <h1><span id="word-rotating">Testimonial</span></h1>
               <p style="margin-top: 10px;margin-bottom: 80px;font-size: 15px;">Pendapat mereka yang sudah mencoba bertransaksi di <?php echo e($GeneralSettings->nama_sistem); ?></p>
              </div>
            </div> <!--/ animate-block -->
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
</section>
<!-- End Slideshow Section -->

<!-- Start Feature Section -->
<section id="feature" class="padding-2x">
   <div class="container">
      <div class="row">
         <?php if($testimonials->count() > 0): ?>
         <ul class="review-timeline">
            <?php $no=1; ?>
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($no%2==1): ?>
            <li>
            <?php else: ?>
            <li class="review-timeline-inverted">
            <?php endif; ?>
               <div class="review-timeline-thumb">
                  <?php if($data->user->image != null): ?>
                  <img class="img-circle img-responsive" src="<?php echo e(asset('admin-lte/dist/img/avatar/'.$data->user->image)); ?>" alt="client-1">
                  <?php else: ?>
                  <img class="img-circle img-responsive" src="<?php echo e(asset('admin-lte/dist/img/avatar5.png')); ?>" alt="client-1">
                  <?php endif; ?>
               </div>
               <div class="review-timeline-panel">
                  <div class="review-timeline-body">
                     <p style="font-style: italic;">"<?php echo e($data->review); ?>"</p>
                     <ul class="reviewer">
                        <li><h4 style="text-transform: capitalize;"><?php echo e($data->user->name); ?> / <?php echo e($data->user->city); ?></h4></li>
                        <li>
                           <div class="stars"> Rated : 
                                <?php
                                    for($i=1;$i<=$data->rate;$i++){
                                ?>
                                        <i class="fa fa-star"></i>
                                <?php
                                    }
                                ?>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </li>
            <?php $no++ ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <li class="clearfix" style="float: none;"></li>
         </ul>
         <?php else: ?>
         <div align="center">
            <i class="fa fa-frown-o fa-5x"></i>
            <h3>Belum ada testimoni</h3>
            <small>Jadilah yang pertama memberikan testimoni pada kami</small>
         </div>
         <?php endif; ?>
      </div>
   </div>
</section>
<!-- End Feature Section -->

<section id="twitter-feed" class="grey-bg padding-1x">
   <div class="container">
      <div class="row">
         <div class="col-md-8 col-md-offset-2">
            <div class="section-heading text-center">
               <h2 class="title" style="font-style: italic;">"<?php echo e($GeneralSettings->motto); ?>"</h2>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webpulsa\resources\views/testimoni.blade.php ENDPATH**/ ?>