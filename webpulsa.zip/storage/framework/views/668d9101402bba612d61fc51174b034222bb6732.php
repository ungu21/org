

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
	<h1>Riwayat <small>Deposit</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/member')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
    	<li class="active">Riwayat Deposit</li>
   </ol>
   </section>
   <section class="content">
      <div class="row hidden-xs hidden-sm">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">Data Deposit Anda</h3>
               </div><!-- /.box-header -->
               <div class="box-body table-responsive">
               <table id="DataTable" class="table table-hover">
                  <thead>
                     <tr class="custom__text-green">
                        <th>Bank</th>
                        <th>Nominal Transfer</th>
                        <th>Status</th>
                        <th>Expire</th>
                        <th>Tgl Request</th>
                        <th>Tgl Update</th>
                        <th>#</th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php if($deposit->count() > 0): ?>
                  <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr style="font-size: 14px;">
                     <td><?php echo e($data->bank->nama_bank); ?></td>
                     <td>Rp <?php echo e(number_format($data->nominal_trf, 0, '.', '.')); ?></td>

                     <?php if($data->status == 0): ?>
                        <td><span class="label label-warning">MENUNGGU</span></td>
                     <?php elseif($data->status == 1): ?>
                        <td><span class="label label-success">BERHASIL</span></td>
                     <?php elseif($data->status == 3): ?>
                        <td><span class="label label-primary">VALIDASI</span></td>
                     <?php elseif($data->status == 2): ?>
                        <td><span class="label label-danger">GAGAL</span></td>
                     <?php endif; ?>

                     <?php if($data->expire == 1): ?>
                        <td><span class="label label-info">AKTIF</span></td>
                     <?php else: ?>
                        <td><span class="label label-danger">EXPIRE</span></td>
                     <?php endif; ?>

                     <td><?php echo e($data->created_at); ?></td>
                     <td><?php echo e($data->updated_at); ?></td>
                     <td>
                        <?php if($data->status == 0): ?>
                            <?php if(!empty($data->payment_url)): ?>
                              <a href="<?php echo e($data->payment_url); ?>" class="label label-primary custom__btn-green">Detail</a>
                            <?php else: ?>
                              <a href="<?php echo e(url('/member/deposit', $data->id)); ?>" class="label label-primary custom__btn-green">Detail</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(url('/member/deposit', $data->id)); ?>" class="label label-primary custom__btn-green">Detail</a>
                        <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                     <tr>
                     <td colspan='9' align='center'><small style='font-style: italic;'>Data tidak ditemukan</small></td>
                     </tr>
                  <?php endif; ?>
                  </tbody>
               </table>
            </div><!-- /.box-body -->
            
         </div><!-- /.box -->
      </div>
   </div>
   <div class="row hidden-lg hidden-md">
      <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title">Data Deposit Anda</h3>
            </div><!-- /.box-header -->
            <div class="box-body" style="padding: 0px;">
               <table class="table">
                  <?php if($deposit->count() > 0): ?>
                  <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <?php
                        $detailURL = $data->status == 0 ? (!empty($data->payment_url) ? $data->payment_url : url('/member/deposit', $data->id)) : url('/member/deposit', $data->id);
                    ?>
                  
                  <tr>
                     <td>
                        <a href="<?php echo e($detailURL); ?>" class="btn-loading" style="color: #464646">
                           <div><i class="fa fa-calendar"></i><small> <?php echo e(date("d M Y", strtotime($data->created_at))); ?></small></div>
                           <div style="font-size: 14px;font-weight: bold;">TOPUP Saldo Rp <?php echo e(number_format($data->nominal, 0, '.', '.')); ?></div>
                           <div><?php echo e($data->bank->nama_bank); ?></div>
                        </a>
                     </td>
                     <td align="right">
                        <a href="<?php echo e($detailURL); ?>" class="btn-loading" style="color: #464646">
                           <div><i class="fa fa-clock-o"></i><small> <?php echo e(date("H:m:s", strtotime($data->created_at))); ?></small></div>
                           <div>Rp <?php echo e(number_format($data->nominal_trf, 0, '.', '.')); ?></div>
                           
                           <?php if($data->status == 0): ?>
                              <div><span class="label label-warning">MENUNGGU</span></div>
                           <?php elseif($data->status == 1): ?>
                              <div><span class="label label-success">BERHASIL</span></div>
                           <?php elseif($data->status == 3): ?>
                              <div><span class="label label-primary">VALIDASI</span></div>
                           <?php elseif($data->status == 2): ?>
                              <div><span class="label label-danger">GAGAL</span></div>
                           <?php endif; ?>
                         
                        </a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <tr>
                      <td colspan="2" style="text-align:center;font-style:italic;">Riwayat Transaksi belum tersedia</td>
                  </tr>
                  <?php endif; ?>
               </table>
            </div><!-- /.box-body -->
            <div class="box-footer" align="center" style="padding-top:13px;">
               <?php echo $__env->make('pagination.default', ['paginator' => $deposit], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
         </div><!-- /.box -->
      </div>
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>

      $('#DataTable').DataTable();
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/member/deposit/riwayat-deposit.blade.php ENDPATH**/ ?>