<?php $__env->startSection('title', 'Harga Produk | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', 'Harga Produk Termurah & Terlengkap '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Puslsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Slideshow Section -->
<section id="slideshow">
    <div class="container">
        <div class="row">
            <div class="no-slider" style="margin-top: 100px;">
                <div class="animate-block" style="text-align: center;">
                    <div class="col-md-6 col-md-offset-3">
                        <h2><span id="word-rotating"><?php echo e($kategoris->product_name); ?></span></h2>
                        <p style="margin-top: 10px;margin-bottom: 80px;">Produk Terlengkap & Termurah Kami</p>
                    </div>
                </div> <!--/ animate-block -->
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</section>
<!-- End Slideshow Section -->
<!-- Start Feature Section -->
<section id="feature" class="padding-2x">
    <div class="container">
        <div class="col-md-12" style="margin-bottom: 30px;">
            <div class="section-heading text-center" style="margin-bottom: 30px;">
                <h2 class="title">Harga <?php echo e($kategoris->product_name); ?></h2>
                <p>Harga Produk Terbaik Kami<br>Update <?php echo e(date("d-m-Y")); ?></p>
            </div>
        </div>
        <!-- Nav tabs -->
        <div class="col-md-12" style="margin-bottom:50px;">
            <?php $__currentLoopData = $kategoris->pembayaranoperator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3 style="font-size: 20px;"><?php echo e($operator->product_name); ?></h3>
            <table class="table table-striped table-bordered" style="font-size: 15px;margin-bottom: 50px;">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kode</th>
                        <th class="text-right">Biaya Admin</th>
                        <th class="text-center">Status</th>
                    </tr> 
                </thead>
                <tbody align="left">
                    <?php if(count($operator->pembayaranproduk) > 0): ?>
                    <?php $__currentLoopData = $operator->pembayaranproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($produk->product_name); ?></td>
                        <td><?php echo e($produk->code); ?></td>
                        <td class="text-right">Rp <?php echo e(number_format($produk->price_markup, 0, '.', '.')); ?></td>
                        <?php if($produk->status == 1): ?>
                        <td class="text-center"><span class="label label-success">TERSEDIA</span></td>
                        <?php else: ?>
                        <td class="text-center"><span class="label label-danger">GANGGUAN</span></td>
                        <?php endif; ?>
                    </tr> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="3" align="center" style="font-style: italic;">Produk Belum Tersedia</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Feature Section -->

<section id="twitter-feed" class="grey-bg padding-1x">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="section-heading text-center">
                    <h2 class="title" style="font-style: italic;">"<?php echo e($GeneralSettings->motto); ?>"</h2>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webpulsa\resources\views/price-pembayaran.blade.php ENDPATH**/ ?>