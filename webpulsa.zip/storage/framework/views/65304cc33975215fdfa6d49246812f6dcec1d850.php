<?php $actual_link = "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>
<!-- ============================== Hai :D Lagi ngapain bro :D ================================================
YA UDAH INTIP SEDIKIT AJA YAHH :D
JANGAN BANYAK - BANYAK HAHAHAHA

Regards, P-Store.Net Tim :*
=======================================================================================================-->
<!DOCTYPE html>
<html lang="id">
   <head>

   <title><?php echo $__env->yieldContent('title'); ?></title>

   <!-- Basic Page Needs
   ================================================== -->
   <meta charset="utf-8">
   <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta http-equiv="Cache-control" content="public">
   <meta name="robot" content="index, follow">
   <!-- Mobile Specific Metas
   ================================================== -->
   <meta name="viewport" content="width=device-width, initial-scale=1">

   <!-- For Search Engine Meta Data  -->
   <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
   <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
   <meta name="author" content="<?php echo e($GeneralSettings->nama_sistem); ?>" />
   <meta property="business:contact_data:street_address" content="<?php echo e($GeneralSettings->alamat); ?>" />
   <meta property="business:contact_data:locality" content="Ngawi" />
   <meta property="business:contact_data:postal_code" content="63263" />
   <meta property="business:contact_data:country_name" content="Indonesia" />
   <meta property="business:contact_data:email" content="<?php echo e($GeneralSettings->email); ?>" />
   <meta property="business:contact_data:phone_number" content="<?php echo e($GeneralSettings->hotline); ?>" />
   <meta property="business:contact_data:website" content="<?php echo e($GeneralSettings->website); ?>" />

   <!-- Social Media Metta -->
   <meta property="fb:admins" content="<?php echo e($GeneralSettings->nama_sistem); ?>"/>
   <meta property="og:site_name" content="<?php echo e($GeneralSettings->nama_sistem); ?>">
   <meta property="og:url" content="<?php echo e($actual_link); ?>">
   <meta property="og:type" content="website">
   <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
   <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
   <meta property="og:image" content="<?php echo $__env->yieldContent('img'); ?>">

   <meta name="twitter:card" content="summary_large_image">
   <meta name="twitter:site" content="">
   <meta name="twitter:creator" content="">
   <meta name="twitter:url" content="<?php echo e($actual_link); ?>">
   <meta name="twitter:title" content="<?php echo $__env->yieldContent('title'); ?>">
   <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
   <meta name="twitter:image" content="<?php echo $__env->yieldContent('img'); ?>">

   <!-- Add to home screen for mobile -->
   <link rel="manifest" href="/manifest.json">
   <!-- for Safari on iOS -->
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-status-bar-style" content="#006CAA">
   <meta name="apple-mobile-web-app-title" content="<?php echo e($GeneralSettings->nama_sistem); ?>">
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <link rel="apple-touch-icon" href=" <?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>">
      <?php endif; ?>
    <?php endif; ?>
   <!-- for windows -->
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <meta name="msapplication-TileImage" content="<?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>">
      <?php endif; ?>
    <?php endif; ?>
   <meta name="msapplication-TileColor" content="#2F3BA2">

   <!-- Favicon -->
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <link rel="shortcut icon" type="image/icon" href=" <?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>" style="width:16px;height: 16px;"/>
      <?php endif; ?>
    <?php endif; ?>
   <!-- Main structure css file -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.0.10/font-awesome-animation.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
    <!-- <link href="https://multireload.com/demo/sepulsa/assets/u9media/sepulsa/style.css" rel="stylesheet"/> -->
    <!-- <link href="https://multireload.com/demo/sepulsa/assets/u9media/sepulsa/main.css" rel="stylesheet"/> -->

    <link href="<?php echo e(asset('/serpulsa/assets/u9media/serpulsa/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/serpulsa/assets/u9media/serpulsa/main.css')); ?>" rel="stylesheet">
   <style>
    @media  screen and (max-width: 780px) {

        .member-area{
            margin-top:8px;
        }

    }
    </style>

    <style>
      .navbar-default
      .navbar-nav>.active>a,
      .navbar-default
      .navbar-nav>.active>a:focus,
      .navbar-default
      .navbar-nav>.active>a:hover
      {
          color: #fff;
          background-color: #dd1d4e;
          border-radius: 3px;
      }

      /*.dropdown-menu>li>a:focus,
      .dropdown-menu>li>a:hover {
          color: #fff;
          text-decoration: none;
          background-color: #dd1d4e;
      }*/
    </style>
    <?php echo $__env->yieldContent('style'); ?>

   </head>

   <body style="" cz-shortcut-listen="true">
   <div id="app hidden-print">
       <div class="app-container">
          <div class="page-homepage">
             <header>
                <div></div>
                <div class="container-fluid">
                   <div class="react">
                      <nav class="navbar navbar-default">
                         <div class="container-fluid">
                            <div class="navbar-header">
                               <a id="header-logo" class="navbar-logo navbar-brand" href="<?php echo e(url('/')); ?>">
                                  <div class="logo-wrapper">
                                    <?php if(isset($logoku[1])): ?>
                                      <?php if($logoku[1]->img !='' || $logoku[1]->img !=null): ?>
                                          <span class="logo-lg"><img src="<?php echo e(asset('img/logo/'.$logoku[1]->img.'')); ?>" class="img-responsive max-height-100"></span>
                                      <?php else: ?>
                                          <span class="logo-lg"><b>PULSA TERLENGKAP</b></span>
                                      <?php endif; ?>
                                    <?php else: ?>
                                        <span class="logo-lg"><b>PULSA TERLENGKAP</b></span>
                                    <?php endif; ?>
                                  </div>
                               </a>
                               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse" aria-expanded="false" aria-controls="navbar"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
                            </div>
                            <div class="navbar-collapse collapse">
                               <ul class="navbar-right nav navbar-nav ">
                                  <!-- <li class="promo-home">
                                    <a id="header-download" class="btn btn-default btn-download" href="#">Download Aplikasi multireload.com</a>
                                  </li> -->

                                  <li class="<?php echo e(url('/') == request()->url() ? 'active' : ''); ?>">
                                    <a href="<?php echo e(url('/')); ?>" class="page-scroll">Home</a>
                                  </li>
                                  <li class="<?php echo e(url('/cara-transaksi') == request()->url() ? 'active' : ''); ?>">
                                    <a href="<?php echo e(url('/cara-transaksi')); ?>" class="page-scroll">Cara Transaksi</a>
                                  </li>
                                  <li class="<?php echo e(url('/deposit') == request()->url() ? 'active' : ''); ?>">
                                    <a href="<?php echo e(url('/deposit')); ?>" class="page-scroll">Cara Deposit</a>
                                  </li>
                                  <li class="dropdown favorite-nav">
                                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Harga Produk</a>
                                     <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url('/price/pembelian', $data->slug)); ?>" class="page-scroll"><?php echo e($data->product_name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $KategoriPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(url('/price/pembayaran', $data->slug)); ?>" class="page-scroll"><?php echo e($data->product_name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </ul>
                                  </li>
                                  <li class="<?php echo e(url('/contact') == request()->url() ? 'active' : ''); ?>">
                                    <a href="<?php echo e(url('/contact')); ?>" class="page-scroll">Kontak Kami</a>
                                  </li>
                                  <?php if(Auth::check()): ?>
                                    <li class="promo-home"><a id="header-download" class="btn btn-default btn-download" href="<?php echo e(url('/member')); ?>">Member Area</a></li>
                                  <?php else: ?>
                                    <li>
                                       <a href="<?php echo e(url('/register')); ?>" id="header-register" class="nav-menu nav-register">
                                          <div class="nav-header"></div>
                                          <div>Sign Up</div>
                                       </a>
                                    </li>
                                    <li>
                                       <a href="<?php echo e(url('/login')); ?>" id="header-signin" class="nav-menu nav-signin">
                                          <div class="nav-header"></div>
                                          <div>Sign In</div>
                                       </a>
                                    </li>
                                  <?php endif; ?>
                              </ul>
                          </div>
                        </div>
                      </nav>
                   </div>
                </div>
             </header>
             <?php echo $__env->yieldContent('img-back'); ?>;
             <?php echo $__env->yieldContent('content'); ?>

      <footer id="footer" class="v2 hidden-print">
         <div class="container">
          <div class="row footer-menu">
           <div class="col-lg-6 col-sm-6 col-xs-12">
            <div class="row">
               <div class="col-lg-12 col-sm-12 col-xs-12">
                <div id="footer-quicklink" class="footer-quicklink">
                  <ul>
                    <li><a href="<?php echo e(url('/about')); ?>">Tentang Kami</a></li>
                    <li><a href="<?php echo e(url('/tos')); ?>">Terms of Service</a></li>
                    <li><a href="<?php echo e(url('/privacy-policy')); ?>">Kebijakan Privasi</a></li>
                  </ul>
                </div>
               </div>
               <div class="col-lg-12 col-sm-12 col-xs-12">
                <div id="footer-social-media" class="social-media">
                 <span class="follow">Follow Us</span>
                 <ul>
                   <li>
                      <div><a href="#" alt="facebook"><span class="download-link facebook"></span></a></div>
                   </li>
                   <li>
                      <div><a href="#" alt="twitter"><span class="download-link twitter"></span></a></div>
                   </li>
                   <li>
                      <div><a href="#" alt="instagram"><span class="download-link instagram"></span></a></div>
                   </li>
                 </ul>
                </div>
               </div>
            </div>
           </div>
           <div class="col-lg-6 col-sm-6 col-xs-12">
            <div id="footer-payment-method" class="payment-method">
               <p>Metode Pembayaran</p>
               <ul>
                <li><a alt="payment-visa"><span class="icon icon-bank bank-cc"></span></a></li>
                <li><a alt="payment-bca"><span class="icon icon-bank bank-bca"></span></a></li>
                <li><a alt="payment-mandiri"><span class="icon icon-bank bank-mandiri"></span></a></li>
                <li><a alt="payment-bersama"><span class="icon icon-bank bank-bersama"></span></a></li>
                <li><a alt="payment-bni"><span class="icon icon-bank bank-bni"></span></a></li>
               </ul>
            </div>
           </div>
          </div>
         </div>
      </footer>
         </div>
       </div>
    </div>
    
   <!-- Javascript Files -->
    <!-- <script src="https://multireload.com/demo/sepulsa/assets/js/jquery.min.js"></script> -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
   
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js"></script>
    <!-- Facebook Pixel Code -->
    <script>
    
    
        $('.submit').on('click', function(){
           $('.submit').html("<i class='fa fa-spinner faa-spin animated' style='margin-right:5px;'></i> Loading...");
           $('.submit').attr('style', 'cursor:not-allowed;pointer-events: none;');
        });

        $(function () {
            // $('#msg').hide();
            $('#login_form').on('submit',function(e) {
              e.preventDefault();
              $('#phone_error').html('');
              $('#password_error').html('');
              var formdata = $('.login_form').serializeArray();
              $.ajax({
                type: "POST",
                url :"<?php echo e(url('/login')); ?>",
                data:{
                  phone:$('#phone_login').val(),
                  password:$('#password_login').val(),
                  _token:"<?php echo e(csrf_token()); ?>",
                },
                // data: {_token:"<?php echo e(csrf_token()); ?>",formdata},
                success: function(response){
                  $('#myModal').modal('hide');
                  if (response.redirect !== undefined && response.redirect) {
                      window.location.href = response.redirect_url;
                  }else{
                     window.location.href = '/member';
                  }
                },
                error: function (xhr, httpStatusMessage, customErrorMessage) {
                    if( xhr.status === 422 ) {
                        $.each(xhr.responseJSON, function(key, value){
                          $("#" + key + "_error").html(value);
                        });
                    }
                }
              })
            })
          });
    </script>
    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '127335881303196');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=127335881303196&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->

    <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-109211142-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-109211142-1');
    </script>
    <!-- End - Google Analytics -->

   <?php echo $__env->yieldContent('js'); ?>

   </body>
</html>
<?php /**PATH D:\Webpulsa baru\produk1\resources\views/layouts/app.blade.php ENDPATH**/ ?>