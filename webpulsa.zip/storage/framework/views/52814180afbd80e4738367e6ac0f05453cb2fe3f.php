<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title><?php echo e($GeneralSettings->nama_sistem); ?> | Member</title>
   <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
   <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="base-url" content="<?php echo e(asset('/')); ?>">
   <?php echo $__env->yieldContent('meta'); ?>
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <link rel="shortcut icon" type="image/icon" href=" <?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>" style="width:16px;height: 16px;"/>
      <?php endif; ?>
    <?php endif; ?>
   <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->

   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.4.1/croppie.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome-animation/0.0.10/font-awesome-animation.min.css">

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css"> 
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/themes/red/pace-theme-flash.min.css">

   
    <!-- Matrial Design-->
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-icons/3.0.1/iconfont/material-icons.min.css">

    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> -->

   <!-- Ico Fonts -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/icofont/css/icofont.css')); ?>">


    <!-- Bootstrap --> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.php?color='.urlencode($GeneralSettings->skin))); ?>">

    <!-- Admin LTE --> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/AdminLTE.php?color='.urlencode($GeneralSettings->skin))); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/_all-skins.php?color='.urlencode($GeneralSettings->skin))); ?>">
    
   <link rel="stylesheet" href="<?php echo e(asset('css/custom.php?color='.urlencode($GeneralSettings->skin))); ?>">
    <style>
         .bungkus {
            position: relative;
            text-align: center;
        }
        
        .center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            /*font-size: 18px;*/
        }
        
        .img-profile { 
            /*width: 100%;*/
            /*height: auto;*/
            opacity: 0.3;
        }
        .fa-check {
            opacity:0.5;               /* Opacity (Transparency) */
            color: rgba(0, 0, 0, 0.75);   /* RGBA Color (Alternative Transparency) */
        }
        .fa-check {
            color: #444;
        }
        
        .awe{
          margin: 0 auto;
          width: 45px;
          /*padding: 3px;*/
          /*border: 3px solid #d2d6de;*/
        }
        
        .img-verif{
            max-width:40px;
            /*opacity: 0.3;*/
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
   <!-- Google Font -->
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

   <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-109211142-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-109211142-1');
    </script>
    <!-- End - Google Analytics -->

   <script>
      
    </script>
   

   <!-- for Safari on iOS -->
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-status-bar-style" content="#006CAA">
   <meta name="apple-mobile-web-app-title" content="<?php echo e($GeneralSettings->nama_sistem); ?>">
   <link rel="apple-touch-icon" href="/assets/images/icons/icon-152x152.png">
   <!-- for windows -->
   <meta name="msapplication-TileImage" content="/assets/images/icons/icon-144x144.png">
   <meta name="msapplication-TileColor" content="#2F3BA2">

   <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
   <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
   <!--[if lt IE 9]>
   <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
   <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
   <![endif]-->
   <style>
        input[type=number]::-webkit-inner-spin-button, 
        input[type=number]::-webkit-outer-spin-button { 
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            margin: 0; 
        }
        table.dataTable thead .sorting:after{opacity:0.2;content:""}
        table.dataTable thead .sorting_asc:after{content:""}
        table.dataTable thead .sorting_desc:after{content:""}
        th.sorting_asc::after, th.sorting_desc::after { content:"" !important; }
        div.dataTables_wrapper div.dataTables_paginate{margin-right: 5px;}
   </style>
    <script>
    </script>
  
</head>
<body class="hold-transition custom__color fixed sidebar-mini">
   <div class="wrapper">

      <header class="main-header">
         <a href="<?php echo e(url('/member')); ?>" class="logo custom__bg-greenHover">
            <span class="logo-mini"><b>P</b>S</span>
            <?php if(isset($logoku[2])): ?>
              <?php if($logoku[2]->img !='' || $logoku[2]->img !=null): ?>
                  <span class="logo-lg"><img src="<?php echo e(asset('img/logo/'.$logoku[2]->img.'')); ?>" style="width:150px;"></span>
              <?php else: ?>
                  <span class="logo-lg"><b>PULSA TERLENGKAP</b></span>
              <?php endif; ?>
            <?php else: ?>
                <span class="logo-lg"><b>PULSA TERLENGKAP</b></span>
            <?php endif; ?>
         </a>
         <nav class="navbar navbar-static-top custom__bg-green" role="navigation">
            <a href="#" class="sidebar-toggle hidden-lg hidden-md hidden-sm" data-toggle="push-menu" role="button">
              <span class="sr-only">Toggle navigation</span>
            </a>

            <div class="navbar-custom-menu">
               <ul class="nav navbar-nav">
                  <li class="dropdown notifications-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        Pembayaran <i class="fa fa-bell-o"></i>
                        <?php if($countTagihan > 0): ?>
                            <span class="label label-success"><?php echo e($countTagihan); ?></span>
                        <?php else: ?>
                            <span class="label label-danger">0</span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu">
                            <li class="header">Anda Mempunyai <?php echo e($countTagihan); ?> Tagihan Belum Terbayar</li>
                        <li>
                            <!-- inner menu: contains the actual data -->
                            <ul class="menu">
                                <table class="table table-hover table-condensed">
                                    <?php $__currentLoopData = $tagihanNonBuy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tgh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(url('/member/tagihan-pembayaran/'.$tgh['id'].'')); ?>" class="btn-loading" style="color: #464646">
                                                            <div style="font-size: 12px;">#<?php echo e(isset($tgh['id'])?$tgh['id'] : '-'); ?></div>
                                                            <div style="font-size: 14px;font-weight: bold;"><?php echo e(isset($tgh['product_name'])?substr($tgh['product_name'], 0, 15).(strlen($tgh['product_name']) > 15 ? ' ...' : '') : '-'); ?></div>
                                                            <div style="font-size: 12px;"><?php echo e(isset($tgh['no_pelanggan'])?$tgh['no_pelanggan'] : '-'); ?></div>
                                                            <div style="font-size: 12px;"><?php echo e(isset($tgh['product_name'])?substr($tgh['nama'], 0, 15).(strlen($tgh['nama']) > 15 ? ' ...' : '') : '-'); ?></div>
                                                            <div style="font-size: 12px;"><?php echo e(isset($tgh['periode'])?$tgh['periode'] : '-'); ?></div>
                                                        </a>
                                                            
                                                </td>
                                                <td align="right">
                                                    <a href="<?php echo e(url('/member/tagihan-pembayaran/'.$tgh['id'].'')); ?>" class="btn-loading" style="color: #464646">
                                                            <div><small><i class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($tgh['created_at']))->diffForHumans()); ?></small></div>
                                                            <div><span class="label label-warning"><?php echo e(($tgh['status'] == 0) ? "MENUNGGU" :(($tgh['status'] == 1) ? "PROSES" :(($tgh['status'] == 2) ? "BERHASIL" :"GAGAL"))); ?></span></div>
                                                            <div><span class="label label-danger">Rp <?php echo e(number_format($tgh->jumlah_bayar, 0, '.', '.')); ?></span></div>
                                                    </a>
                                                </td>
                                            </tr>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </ul>
                        </li>
                        <li class="footer"><a href="<?php echo e(url('/member/tagihan-pembayaran')); ?>">See All</a></li>
                    </ul>
                  </li>
                  <li class="dropdown messages-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="fa fa-envelope"></i>
                        <?php if($ctmsg > 0): ?>
                            <span class="label label-success">NEW</span>
                        <?php else: ?>
                            <span class="label label-danger">0</span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <!--<li class="header">You have <?php echo e($ctmsg); ?> Reply</li>-->
                        <?php if(empty($detailMessage)): ?>
                            <li class="header">You have 0 Reply Unread</li>
                        <?php endif; ?>
                        <li>
                            <!-- inner menu: contains the actual data -->
                            <ul class="menu">
                                <?php $__currentLoopData = $detailMessage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(url('/member/messages-show/'.$msg['id'].'')); ?>">
                                            <div class="pull-left">
                                                
                                            <?php if($msg['image'] != null): ?>
                                              <img src="<?php echo e(asset('admin-lte/dist/img/avatar/'.$msg['image'])); ?>" class="img-circle" alt="">
                                            <?php else: ?>
                                              <img src="<?php echo e(asset('images/avatar.png')); ?>" class="img-circle" alt="">
                                            <?php endif; ?>
                                            </div>
                                            <h4>
                                                <?php echo e(isset($msg['subject'])?substr($msg['subject'], 0, 20).(strlen($msg['subject']) > 20 ? ' ...' : '') : '-'); ?>

                                                <small><i class="fa fa-clock-o"></i> <?php echo e(\Carbon\Carbon::createFromTimeStamp(strtotime($msg['created_at']))->diffForHumans()); ?></small>
                                            </h4>
                                            <p><?php echo e(isset($msg['message'])?substr($msg['message'], 0, 25).(strlen($msg['message']) > 25 ? ' ...' : '') : '-'); ?></p>
                                            <?php if($msg['reply_count'] == 0): ?>
                                              <p><span class="label label-danger"><?php echo e($msg['reply_count']); ?> Reply Unread</span></p>
                                            <?php else: ?>
                                              <p><span class="label label-success"><?php echo e($msg['reply_count']); ?> Reply Unread</span></p>
                                            <?php endif; ?>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <li class="footer"><a href="<?php echo e(url('/member/messages')); ?>">See All Messages</a></li>
                    </ul>
                  </li>
                  <li><a href="<?php echo e(url('/member/pusat-informasi')); ?>" class="btn-loading"><i class="fa fa-info-circle"></i></a></li>
               </ul>
            </div>
         </nav>
      </header>

      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
         <section class="sidebar">
            <div class="user-panel">
                  <div class="pull-left image">
                    <?php if($notifValidation == 0): ?>
                          <?php if(Auth::user()->image != null): ?>
                          <img src="<?php echo e(asset('admin-lte/dist/img/avatar/'.Auth::user()->image)); ?>" class="img-circle img-responsive" alt="User Image">
                          <?php else: ?>
                          <img src="<?php echo e(asset('images/avatar.png')); ?>" class="img-circle img-responsive" alt="User Image">
                          <?php endif; ?>
                    <?php else: ?>
                        <div class="bungkus">
                          <?php if(Auth::user()->image != null): ?>
                          <img src="<?php echo e(asset('admin-lte/dist/img/avatar/'.Auth::user()->image)); ?>" class="awe img-circle img-responsive img-profile" alt="User Image">
                          <?php else: ?>
                          <img src="<?php echo e(asset('images/avatar.png')); ?>" class="awe img-circle img-responsive img-profile" alt="User Image">
                          <?php endif; ?>
                        <div class="center"><img  class="img-verif" src="<?php echo e(asset('img/log-verified.png')); ?>" alt="<?php echo e(Auth::user()->name); ?>"></div>
                       </div>
                    <?php endif; ?>
                </div>
               <div class="pull-left info">
                  <p><?php echo e(isset(Auth::user()->name)?Auth::user()->name:''); ?></p>
                  <span style="text-transform:uppercase;font-size:12px;"><?php echo e(isset(Auth::user()->roles()->first()->display_name)?Auth::user()->roles()->first()->display_name:''); ?></span> 
               </div>
            </div>
            <ul class="sidebar-menu" data-widget="tree">
               <li class="<?php echo e(url('/member') == request()->url() ? 'active' : ''); ?>"><a href="<?php echo e(url('/member')); ?>" class="btn-loading"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
               <?php
                  $html_string = App\AppModel\MenuSubmenu::rendermenu();
                  echo $html_string;
                ?>
            </ul>
         </section>
      </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
              <div class="loading">
                  <?php if(!empty($pengumuman)): ?>
                      <div id="announcement" style="padding: 20px 30px;background: #FF6E2D;z-index: 999999;font-size: 16px;font-weight: 600;"><a onclick="closeAnnouncement();" class="pull-right" href="javascript:void(0);" data-toggle="tooltip" data-placement="left" title="" style="color: rgb(255, 255, 255); font-size: 20px;" data-original-title="">×</a><a style="color: rgba(255, 255, 255, 0.9); display: inline-block; margin-right: 10px; text-decoration: none;"><?php echo e(html_entity_decode($pengumuman, ENT_QUOTES)); ?></a></div>
                  <?php endif; ?>
                  <?php echo $__env->yieldContent('content'); ?>
              </div>
        </div>

        <style>
            .box__tab{
                display: none;
            }
            @media  screen and (max-width: 780px) {
            	.title-footer{
            	    font-size:11px;
            	    text-align:center;
            	}
            }
            @media(max-width: 576px){
                .box__tab{
                    position: fixed !important;
                    bottom: 0 !important;
                    background: #fff;
                    display: block;
                    width: 100%;
                }
                .box__tab ul{
                    align-items: center;
                    justify-content: space-around;
                    display: flex;
                    text-align: center;
                }
                .box__tab ul li a{
                    color: #ACACAC;
                }
                .box__tab ul li a.active{
                    color: var(--custom-color);
                }
                .box__tab ul li a i{
                   font-size: 24px;
                }
                .box__tab ul li a span{
                   font-size: 12px;
                }
                .box__tab ul li a:hover{
                    color: #ACACAC;
                }
                .box__tab ul li a:focus{
                    color: #ACACAC;
                }
                .paginate_button.active a{
                    background-color: #32CD32 !important;
                    border-color: #32CD32 !important;
                }
                .box__tab .nav li a{
                    padding: 10px 11px;
                }
            }
        </style>

        <!-- Tab Mobile --> 
        <nav class="box__tab">
            <ul class="nav " role="tablist" id="box__tab">
                <li class="nav-item" href="#" onclick="window.location.href=`<?php echo e(url('/member/')); ?>`">
                    <a class="nav-item nav-link <?php echo e(Request::is('member') ? 'active' : ''); ?>" data-toggle="pill" href="#" role="tab" aria-selected="true">
                        <i class="icofont icofont-ui-home"></i>
                        <div>Beranda</div>
                    </a>
                </li>
                <li class="nav-item" href="#" onclick="window.location.href=`<?php echo e(url('/member/deposit/')); ?>`">
                    <a class="nav-item nav-link <?php echo e(Request::is('member/deposit') ? 'active' : ''); ?>" data-toggle="pill" href="#" role="tab" aria-controls="tanggapan-pembeli" aria-selected="false">
                        <i class="icofont icofont-plus-circle"></i> <br>
                        <div>Isi Saldo</div>
                    </a>
                </li>
                <li class="nav-item" onclick="window.location.href=`<?php echo e(url('/member/riwayat-transaksi/')); ?>`">
                    <a class="nav-item nav-link <?php echo e(Request::is('member/riwayat-transaksi') ? 'active' : ''); ?>" data-toggle="pill" href="#" role="tab" aria-controls="tanggapan-pembeli" aria-selected="false">
                        <i class="fa fa-history"></i>
                        <div>Riwayat</div>
                    </a>
                </li>
                <li class="nav-item" onclick="window.location.href=`<?php echo e(url('/member/tagihan-pembayaran')); ?>`">
                    <a class="nav-item nav-link <?php echo e(Request::is('member/tagihan-pembayaran') ? 'active' : ''); ?>" data-toggle="pill" href="#" role="tab" aria-controls="tanggapan-pembeli" aria-selected="false">
                        <i class="icofont icofont-notification"></i>
                        <div>Notifikasi</div>
                    </a>
                </li>
                <?php
                    $link = 'https://wa.me/'.$GeneralSettings->hotline.'?text=Hallo,%20saya%20ingin%20menanyakan%20layanan%20'.$GeneralSettings->nama_sistem;
                ?>
                <li class="nav-item" target="_blank" onclick="window.open('<?php echo e($link); ?>')">
                    <a class="nav-item nav-link" data-toggle="pill" href="#" role="tab" aria-controls="tanggapan-pembeli" aria-selected="false">
                        <i class="icofont icofont-social-whatsapp"></i>
                        <div>Chat CS</div>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- Penutup Tab Mobile --> 

      <footer class="main-footer title-footer">
         <div class="pull-right hidden-xs hidden-sm">
            <b style="font-style: italic;"><?php echo e($GeneralSettings->motto); ?></b>
         </div>
         <strong>Copyright &copy; <a href="<?php echo e($GeneralSettings->website); ?>" class="custom__text-green"><?php echo e($GeneralSettings->nama_sistem); ?></a> <?php echo e(date('Y')); ?>.</strong>
      </footer>

   </div>
   <!-- ./wrapper -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
   <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.8/jquery.slimscroll.js"></script>
   <script src="<?php echo e(asset('admin-lte/dist/js/adminlte.min.js')); ?>"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.4.1/croppie.js"></script>
   <script src="https://cdn.jsdelivr.net/clipboard.js/1.5.12/clipboard.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js"></script>
   
   <script>
     toastr.options = {
       "positionClass": "toast-bottom-right",
     }
     <?php if(Session::has('alert-success')): ?>
         toastr.success("<?php echo addslashes(Session::get('alert-success')); ?>");
     <?php endif; ?>
     <?php if(Session::has('alert-info')): ?>
         toastr.info("<?php echo addslashes(Session::get('alert-info')); ?>");
     <?php endif; ?>
     <?php if(Session::has('alert-warning')): ?>
         toastr.warning("<?php echo addslashes(Session::get('alert-warning')); ?>");
     <?php endif; ?>
     <?php if(Session::has('alert-error')): ?>
         toastr.error("<?php echo addslashes(Session::get('alert-error')); ?>");
     <?php endif; ?>
   </script>
   <script>
        if (document.documentElement.clientWidth < 780) {
            $('.btn-loading').on('click', function(){
                // $('.loading').html("<div class='hidden-lg' style='text-align:center;'><i class='fa fa-spinner fa-4x faa-spin animated text-primary' style='margin-top:100px;'></i></div>");
                $('.sidebar-mini').removeClass('sidebar-open');
                
            });
            $('.box-penjelasan').addClass('collapsed-box');
            $('.box-minus').removeAttr('style');
            $('.header-profile').removeAttr('style');
        }
        $('.submit').on('click', function(){
           $('.submit').html("<i class='fa fa-spinner faa-spin animated' style='margin-right:5px;'></i> Loading...");
           $('.submit').attr('style', 'cursor:not-allowed;pointer-events: none;');
        });
        
        function closeAnnouncement() {
            $("#announcement").remove();
        }
        function closeAnnouncement() {
            $("#announcement").remove();
        }
         var base_url = function(url){
        
          return $('meta[name="base-url"]').attr('content')+"/"+url;
         }
    </script>
    
    <script>
        function triggerOnline() {
            $.ajax({
                url: "<?php echo e(url('/member/trigger-online')); ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(s) {
                    
                },
                error: function(e) {
                    console.log(e);
                }
            })
        }
        
        $(function() {
            triggerOnline();
            setInterval(triggerOnline, 60 * 1000);
        });
    </script>

   <?php echo $__env->yieldContent('js'); ?>
   
</body>
</html><?php /**PATH D:\Webpulsa baru\produk3\resources\views/layouts/member.blade.php ENDPATH**/ ?>