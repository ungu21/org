
<?php $__env->startSection('meta', '<meta http-equiv="refresh" content="60">'); ?>

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
<h1>Kontrol Banner <small>Banner</small></h1>
<ol class="breadcrumb">
 	<li><a href="#"><i class="fa fa-dashboard"></i> Kontrol Banner</a></li>
 	<li class="active">Banner</li>
</ol>
</section>
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box box-green">
            <div class="box-header with-border">
               <h3 class="box-title" style="font-size: 13px;font-weight: bold;">SLIDER</h3>
               
                <a href="<?php echo e(route('banner.menu.create')); ?>" class="btn-loading btn btn-primary pull-right" data-toggle="tooltip" data-placement="left" title="Tambah Banner" style="padding: 3px 7px;"><i class="fa fa-plus"></i></a>
               <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                 <table class="table table-striped" id="table-banner">
                    <thead>
                      <tr>
                          <th>No</th>
                          <th>ID</th>
                          <th>Nama Image</th>
                          <th>Image </th>
                          <th>Type</th>
                          <th>Action</th>
                      </tr>
                    </thead>
                     <tbody>
                        <?php $no=1; ?>
                        <?php $__currentLoopData = $databanner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="font-size: 14px;">
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($banner->id); ?></td>
                            <td><?php echo e(strtoupper($banner->name_img)); ?></td>
                            <!-- <td><img src="<?php echo e(public_path().$banner->img_path); ?>" alt="..."></td> -->
                            <!-- <td><img src="<?php echo e(public_path().$banner->img_path); ?>" alt="..."></td> -->
                            <!-- <img src="<?php echo e(asset('uploads/joew.png')); ?>" /> -->
                            <td class="text-center"><img src="<?php echo e(asset($banner->img_path)); ?>" height="20px"></td>
                            <!-- <td><?php echo e($banner->img_path); ?></td> -->
                            <td><?php echo e(strtoupper($banner->type_img)); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('delete.banner', $banner->id)); ?>" accept-charset="UTF-8">
                                    <input name="_method" type="hidden" value="DELETE">
                                    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                    <a href="<?php echo e(url('admin/banner/edit-banner/'.$banner->id )); ?>" class="btn-loading btn btn-primary btn-sm" style="padding: 3px 7px;"><i class="fa fa-pencil"></i></a>
                                    <!-- <a href="<?php echo e(url('/edit-banner/'.$banner->type_img.'/'.$banner->id )); ?>" class="btn-loading btn btn-primary btn-sm" style="padding: 3px 7px;"><i class="fa fa-pencil"></i></a> -->
                                    <button class="btn btn-danger btn-sm" style="padding: 3px 7px;" onclick="return confirm('Anda yakin akan menghapus data ?');" type="submit"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
               </table>
            </div>
            <!-- /.box-body -->
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
   $(function () {
      $('#table-banner').DataTable({
        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        "iDisplayLength": 50,
        "searching": true,
        "lengthChange": false,
        "info": false
      });
   });

  function nonaktifkanMenu($id)
  {
    console.log('nonaktifkan:',$id);
      var id = $id;
        $.ajax({
            url: "<?php echo e(route('menu.kontrol.nonaktifkan')); ?>",
            method: "POST",
            data: {_token:"<?php echo e(csrf_token()); ?>",id:id},
            success: function(response){
                  window.setTimeout(function(){
                     location.href="<?php echo e(route('kontrol.menu.index')); ?>";
                  } ,2000);

                // tableMenu = $('#table-menu').DataTable();
                // tableMenu.ajax.reload( null, false );
            },
            error: function(response){
                console.log(response.responseText);
            }
        });
  }

  function aktifkanMenu($id)
  {
    console.log('aktifkan:',$id);
        var id = $id;
        $.ajax({
            url: "<?php echo e(route('menu.kontrol.aktifkan')); ?>",
            method: "POST",
            data: {_token:"<?php echo e(csrf_token()); ?>",id:id},
            success: function(response){
                  window.setTimeout(function(){
                     location.href="<?php echo e(route('kontrol.menu.index')); ?>";
                  } ,2000);

                // tableMenu = $('#table-menu').DataTable();
                // tableMenu.ajax.reload( null, false );
            },
            error: function(response){
                console.log(response.responseText);
            }
        });
  }

  function nonaktifkanSubMenu($id)
  {
    console.log('nonaktifkan:',$id);
      var id = $id;
        $.ajax({
            url: "<?php echo e(route('sub.menu.kontrol.nonaktifkan')); ?>",
            method: "POST",
            data: {_token:"<?php echo e(csrf_token()); ?>",id:id},
            success: function(response){
                  window.setTimeout(function(){
                     location.href="<?php echo e(route('kontrol.menu.index')); ?>";
                  } ,2000);

                // tableSubMenu = $('#table-submenu').DataTable();
                // tableSubMenu.ajax.reload( null, false );
            },
            error: function(response){
                console.log(response.responseText);
            }
        });
  }

  function aktifkanSubMenu($id)
  {
    console.log('aktifkan:',$id);
        var id = $id;
        $.ajax({
            url: "<?php echo e(route('sub.menu.kontrol.aktifkan')); ?>",
            method: "POST",
            data: {_token:"<?php echo e(csrf_token()); ?>",id:id},
            success: function(response){
                  window.setTimeout(function(){
                     location.href="<?php echo e(route('kontrol.menu.index')); ?>";
                  } ,2000);

                // tableSubMenu = $('#table-submenu').DataTable();
                // tableSubMenu.ajax.reload( null, false );
            },
            error: function(response){
                console.log(response.responseText);
            }
        });
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/admin/banner/index.blade.php ENDPATH**/ ?>