<?php $__env->startSection('title', 'Kontak Kami | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="card wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
              <div class="ms-hero-bg-primary ms-hero-img-mountain">
                <h3 class="color-white index-1 text-center pb-4 pt-4 no-mb">Contact Us</h3>
              </div>
              <div class="card-body">
            <form action="<?php echo e(url('/messages')); ?>" class="form-horizontal" method="post" accept-charset="utf-8">
                    <?php echo csrf_field(); ?>
                <?php echo e($captcha->form_field(null, 'contact_captcha_id')); ?>                                                 
                <div class="form-group is-empty" style="padding-bottom: 0px;margin: 0px 0 0;">
                  <label for="nama" class="control-label">
                    Nama
                  </label>
                    <input type="text" class="form-control" name="name" id="nama" maxlength="32" required="required">
                </div>
                <div class="form-group is-empty" style="padding-bottom: 0px;margin: 0px 0 0;">
                  <label for="no_hp" class="control-label">
                      Email
                  </label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Masukkan email" required="required">
                </div>
                <div class="form-group is-empty" style="padding-bottom: 0px;margin: 0px 0 0;">
                  <label for="no_hp" class="control-label">
                    Nomor HP
                  </label>
                    <input type="text" class="form-control" name="phone" id="phone" maxlength="14" placeholder="08xxxxxxxxxx" required="required">
                </div>
                
                <div class="form-group is-empty" style="padding-bottom: 0px;margin: 0px 0 0;">
                  <label for="pesan" class="control-label">
                    Pesan
                  </label>
                    <textarea class="form-control" name="message" id="message" required="required" maxlength="160" rows="8"></textarea>
                </div>
                <div class="form-group is-empty" style="padding-bottom: 0px;margin: 0px 0 0;">
                  <label for="kode" class="control-label">
                    Kode Keamanan
                  </label>
                    <div class="input-group">
                      <input type="text" class="form-control" name="captcha" id="v"  required="required" style="width: auto;">
                      <span class="input-group-btn" style="padding: 0;">
                       <?php echo e($captcha->html_image(['style' => 'max-height: 32px'])); ?>

                      </span>
                    </div>
                </div>
                <div class="form-group text-right">
                  <div class="form-group">
                    <button type="submit" name="submit" value="send" class="btn btn-raised btn-primary">
                      <i class="fa fa-paper-plane-o"></i> Kirim
                    </button>
                  </div>
                </div>
              </form>              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="card card-primary wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
              <div class="ms-hero-bg-primary ms-hero-img-mountain">
                <h3 class="color-white index-1 text-center pb-4 pt-4 no-mb">Contact info</h3>
              </div>
              <div class="card-body">
                <div class="text-center mb-2">
                  <h3 class="no-m ms-site-title">
                   <?php echo e($GeneralSettings->nama_sistem); ?>

                  </h3>
                </div>
                <address class="no-mb">
                                    <p>
                    <i class="color-danger-light zmdi zmdi-pin mr-1"></i><?php echo e($GeneralSettings->alamat); ?></p>
                  <!--<p>
                    <i class="color-warning-light zmdi zmdi-map mr-1"></i> San Francisco, CA 94107</p>-->
                  <p>
                    <i class="color-info-light zmdi zmdi-email mr-1"></i>
                    <a href="mailto:<?php echo e($GeneralSettings->email); ?>"><?php echo e($GeneralSettings->email); ?></a>
                  </p>
                  <p>
                    <i class="color-success-light fa fa-whatsapp mr-1"></i><?php echo e($GeneralSettings->hotline); ?></p>
                  <!--<p>
                    <i class="color-success-light fa fa-fax mr-1"></i>+34 123 456 7890 </p>-->                </address>
              </div>
            </div>
            <div class="card card-primary animated fadeInUp animation-delay-7">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="zmdi zmdi-map"></i>Map</h3>
              </div>
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3955.9194281190335!2d111.20824181479921!3d-7.474149775761955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e79f0dde501d6bd%3A0xc80b3c36c5b959d9!2sP-Store.Net!5e0!3m2!1sen!2sid!4v1533763701346" width="100%" height="245" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/contact.blade.php ENDPATH**/ ?>