

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Pembelian <small>Operator</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;">Pembelian</a></li>
        <li><a href="<?php echo e(route('pembelian-operator.index')); ?>" class="btn-loading"> Operator</a></li>
    	<li class="active">Ubah Operator</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-md-6">
            <div class="box box-green">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(route('pembelian-operator.index')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Ubah Operator</h3>
                </div>
                <form role="form" action="<?php echo e(route('pembelian-operator.update', $operators->id)); ?>" method="post">
                <input type="hidden" name="_method" value="PATCH">
                <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <div class="form-group<?php echo e($errors->has('kategori') ? ' has-error' : ''); ?>">
                            <label>Kategori : </label>
                            <select name="kategori" class="form-control">
                                <option value="">-- Pilih Kategori --</option>
                                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($data->id); ?>" <?php echo e($operators->pembeliankategori_id == $data->id ? 'selected' : ''); ?>><?php echo e($data->product_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php echo $errors->first('kategori', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('product_id') ? ' has-error' : ''); ?>">
                            <label>ID Server : </label>
                            <input type="text" class="form-control" name="product_id" value="<?php echo e($operators->product_id ?? old('product_id')); ?>"  placeholder="Masukkan ID Operator Server">
                            <?php echo $errors->first('product_id', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('product_name') ? ' has-error' : ''); ?>">
                            <label>Nama Operator : </label>
                            <input type="text" class="form-control" name="product_name" value="<?php echo e($operators->product_name ?? old('product_name')); ?>"  placeholder="Masukkan Nama Operator">
                            <?php echo $errors->first('product_name', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('prefix') ? ' has-error' : ''); ?>">
                            <label>Nomor Prefix : </label>
                            <input type="text" class="form-control" name="prefix" value="<?php echo e($operators->prefix ?? old('prefix')); ?>" placeholder="Masukkan Nomor Prefix Operator">
                            <?php echo $errors->first('prefix', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('img_url') ? ' has-error' : ''); ?>">
                            <label>URL Gambar : </label>
                            <input type="text" class="form-control" name="img_url" value="<?php echo e($operators->img_url ?? old('img_url')); ?>"  placeholder="Masukkan URL Gambar Operator">
                            <?php echo $errors->first('img_url', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                        <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                            <label>Status Operator : </label>
                            <select name="status" class="form-control">
                                <option value="1" <?php echo e($operators->status == 1 ? 'selected' : ''); ?>>AKTIF</option>
                                <option value="0" <?php echo e($operators->status == 0 ? 'selected' : ''); ?>>TIDAK AKTIF</option>
                            </select>
                            <?php echo $errors->first('status', '<p class="help-block"><small>:message</small></p>'); ?>

                        </div>
                    </div>

                    <div class="box-footer">
                        <button type="submit" class="submit btn btn-primary btn-block">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-6">
            <div class="box box-solid box-penjelasan">
                <div class="box-header with-border">
                    <i class="fa fa-server"></i>
                    <h3 class="box-title">Data Operator 10 Terakhir</h3>
                    <div class="box-tools pull-right box-minus" style="display:none;">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                    <div class="box-body table-responsive no-padding">
                    <table class="table table-hover" style="font-size: 13px;">
                        <tr class="custom__text-green">
                            <th>No</th>
                            <th>Nama Operator</th>
                            <th>Kategori</th>
                            <th>Update Terakhir</th>
                        </tr>
                        <?php $no=1; ?>
                        <?php if($operatorsall->count() > 0): ?>
                        <?php $__currentLoopData = $operatorsall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($data->product_name); ?></td>
                            <td><?php echo e($data->pembeliankategori->product_name); ?></td>
                            <td><?php echo e($data->updated_at); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center;font-size: 12px;font-style: italic;background-color: #F5F5F5">Data tidak tersedia</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div><!-- /.box-body -->
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/admin/pembelian/operator/edit.blade.php ENDPATH**/ ?>