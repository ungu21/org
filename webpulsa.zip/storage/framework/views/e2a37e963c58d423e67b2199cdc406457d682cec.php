<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#"><img src="<?php echo e(asset('img/logo/'.$logoku[1]->img.'')); ?>" style="max-width:150px"></a>
    </div><!-- /.login-logo -->
    <div class="login-box-body">
        
         <?php if(Session::has('alert-success')): ?>
            <div class="alert alert-success alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
               <h4><i class="fa fa-check"></i>Berhasil</h4>
               <p><?php echo Session::get('alert-success'); ?></p>
            </div>
          <?php endif; ?>
         <?php if(Session::has('alert-error')): ?>
            <div class="alert alert-danger alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
               <h4><i class="fa fa-check"></i>Error</h4>
               <p><?php echo Session::get('alert-error'); ?></p>
            </div>
          <?php endif; ?>
          
        <form action="<?php echo e(url('/password/email')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo e($captcha->form_field()); ?>

            <div class="form-group has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email akun" autocomplete="off">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php echo $errors->first('email', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="row">
                <div class="col-md-8">
                   <div class="form-group has-feedback <?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                      <input id="captcha" name="captcha" class="form-control" placeholder="Masukkan kode Captcha disamping" type="text">
                      <span class="fa fa-lock form-control-feedback"></span>
                      <?php echo $errors->first('captcha', '<p class="help-block"><small>:message</small></p>'); ?>

                   </div>
                </div>
                <div class="col-md-4">
                   <div class="form-group">
                      <?php echo e($captcha->html_image(['style' => 'max-height: 32px'])); ?>

                   </div>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="submit btn btn-primary btn-block btn-flat">Reset Password</button>
            </div>
        </form>
        <div align="center">
            <span>Ingat Kata Sandi?</span>
            <h5 style="margin-top:5px;margin-bottom:0px;font-weight:bold;font-size:17px;"><a href="<?php echo e(url('/login')); ?>" class="custom__text-green">Masuk Sekarang</a></h5>
        </div>

    </div><!-- /.login-box-body -->
</div><!-- /.login-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebProgramming\WebpulsaNew\newpay\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>