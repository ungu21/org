

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Pembelian <small>Operator</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;">Pembelian</a></li>
    	<li class="active">Operator</li>
    </ol>
</section>
<section class="content">
    <div class="row hidden-xs hidden-sm">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Data Operator</h3>
                    <!--<a href="<?php echo e(route('pembelian-operator.create')); ?>" class="btn-loading btn btn-primary pull-right" data-toggle="tooltip" data-placement="left" title="Tambah Kategori" style="padding: 3px 7px;"><i class="fa fa-plus"></i></a>-->
                </div><!-- /.box-header -->
                <div class="box-body table-responsive no-padding">
                    <table id="DataTable" class="table table-hover">
                        <thead>
                            <tr class="custom__text-green">
                                <th>No</th>
                                <th>ID</th>
                                <th>ID Server</th>
                                <th>Nama Operator</th>
                                <th>Kategori</th>
                                <th>Jumlah Produk</th>
                                <th>Update Terakhir</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; ?>
                        <?php if($operators->count() > 0): ?>
                        <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr style="font-size: 14px;">
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->product_id); ?></td>
                            <td><?php echo e($data->product_name); ?></td>
                            <td><?php echo e($data->pembeliankategori->product_name); ?></td>
                            <td><?php echo e($data->pembelianproduk->count()); ?></td>
                            <td><?php echo e($data->updated_at); ?></td>
                            <?php if($data->status == 1): ?>
                            <td><label class="label label-success">AKTIF</label></td>
                            <?php else: ?>
                            <td><label class="label label-danger">TIDAK AKTIF</label></td>
                            <?php endif; ?>
                            <td>
                               <form method="POST" action="<?php echo e(route('pembelian-operator.destroy', $data->id)); ?>" accept-charset="UTF-8">
                                  <input name="_method" type="hidden" value="DELETE">
                                  <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                  <a href="<?php echo e(route('pembelian-operator.edit', $data->id)); ?>" class="btn-loading btn btn-primary btn-sm" style="padding: 3px 7px;"><i class="fa fa-pencil"></i></a>
                                  <button class="btn btn-danger btn-sm" style="padding: 3px 7px;" onclick="return confirm('Anda yakin akan menghapus data ?');" type="submit"><i class="fa fa-trash"></i></button>
                               </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="9" style="text-align: center;font-size: 12px;font-style: italic;background-color: #F5F5F5">Data tidak tersedia</td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
    <div class="row hidden-lg hidden-md">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(url('/admin')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Data Operator</h3>
                    <a href="<?php echo e(route('pembelian-operator.create')); ?>" class="btn-loading btn btn-primary pull-right" data-toggle="tooltip" data-placement="left" title="Tambah Kategori" style="padding: 3px 7px;"><i class="fa fa-plus"></i></a>
                </div><!-- /.box-header -->
                <div class="box-body" style="padding: 0px">
                    <table class="table table-hover">
                        <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div><small>ID : #<?php echo e($data->id); ?></small></div>
                                <div style="font-size: 14px;font-weight: bold;"><?php echo e($data->product_name); ?></div>
                                <div><?php echo e($data->pembeliankategori->product_name); ?></div>
                            </td>
                            <td align="right">
                                <div><small>ID Product : #<?php echo e($data->product_id); ?></small></div>
                                <div><span class="label label-success">AKTIF</span></div>
                                <div style="margin-top:5px;">
                                    <form method="POST" action="<?php echo e(route('pembelian-operator.destroy', $data->id)); ?>" accept-charset="UTF-8">
                                        <input name="_method" type="hidden" value="DELETE">
                                        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                        <a href="<?php echo e(route('pembelian-operator.edit', $data->id)); ?>" class="btn-loading btn btn-primary btn-sm" style="padding: 2px 5px;font-size:10px;">Detail</i></a>
                                        <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin akan menghapus data ?');" type="submit" style="padding: 2px 5px;font-size:10px;">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
$(function () {
   $('#DataTable').DataTable({
     "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
     "iDisplayLength": 50,
     "searching": false,
     "lengthChange": false,
     "info": false,
     "order": [[ 0, "asc" ]]
   });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mydn5829/system/resources/views/admin/pembelian/operator/index.blade.php ENDPATH**/ ?>