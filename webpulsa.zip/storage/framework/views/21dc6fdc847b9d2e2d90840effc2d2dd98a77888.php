<?php $actual_link = "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>
<!-- ============================== Hai :D Lagi ngapain bro :D ================================================
YA UDAH INTIP SEDIKIT AJA YAHH :D 
JANGAN BANYAK - BANYAK HAHAHAHA

Regards, P-Store.Net Tim :*
=======================================================================================================-->
<!DOCTYPE html>
<html lang="en">
   <head>
      <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Basic Page Needs
   ================================================== -->
   <meta charset="utf-8">
   <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta http-equiv="Cache-control" content="public">
   <meta name="robot" content="index, follow">
   <!-- Mobile Specific Metas
   ================================================== -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
  
   <!-- For Search Engine Meta Data  -->
   <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>" />
   <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>" />
   <meta name="author" content="<?php echo e($GeneralSettings->nama_sistem); ?>" />
   <meta property="business:contact_data:street_address" content="<?php echo e($GeneralSettings->alamat); ?>" />
   <meta property="business:contact_data:locality" content="Ngawi" />
   <meta property="business:contact_data:postal_code" content="63263" />
   <meta property="business:contact_data:country_name" content="Indonesia" />
   <meta property="business:contact_data:email" content="<?php echo e($GeneralSettings->email); ?>" />
   <meta property="business:contact_data:phone_number" content="<?php echo e($GeneralSettings->hotline); ?>" />
   <meta property="business:contact_data:website" content="<?php echo e($GeneralSettings->website); ?>" />

   <!-- Social Media Metta -->
   <meta property="fb:admins" content="<?php echo e($GeneralSettings->nama_sistem); ?>"/>
   <meta property="og:site_name" content="<?php echo e($GeneralSettings->nama_sistem); ?>">
   <meta property="og:url" content="<?php echo e($actual_link); ?>">
   <meta property="og:type" content="website">
   <meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>">
   <meta property="og:description" content="<?php echo $__env->yieldContent('description'); ?>">
   <meta property="og:image" content="<?php echo $__env->yieldContent('img'); ?>">

   <meta name="twitter:card" content="summary_large_image">
   <meta name="twitter:site" content="">
   <meta name="twitter:creator" content="">
   <meta name="twitter:url" content="<?php echo e($actual_link); ?>">
   <meta name="twitter:title" content="<?php echo $__env->yieldContent('title'); ?>">
   <meta name="twitter:description" content="<?php echo $__env->yieldContent('description'); ?>">
   <meta name="twitter:image" content="<?php echo $__env->yieldContent('img'); ?>">

    <!-- Add to home screen for mobile -->
   <link rel="manifest" href="/manifest.json">
   <!-- for Safari on iOS -->
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-status-bar-style" content="#006CAA">
   <meta name="apple-mobile-web-app-title" content="<?php echo e($GeneralSettings->nama_sistem); ?>">
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <link rel="apple-touch-icon" href=" <?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>">
      <?php endif; ?>
    <?php endif; ?>
   <!-- for windows -->
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <meta name="msapplication-TileImage" content="<?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>">
      <?php endif; ?>
    <?php endif; ?>
   <meta name="msapplication-TileColor" content="#2F3BA2">

   <!-- Favicon -->
    <?php if(isset($logoku[0])): ?>
      <?php if($logoku[0]->img !='' || $logoku[0]->img !=null): ?>
        <link rel="shortcut icon" type="image/icon" href=" <?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>" style="width:16px;height: 16px;"/>
      <?php endif; ?>
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(asset('materialpulsa/css/preload.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('materialpulsa/css/plugins.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('materialpulsa/css/style.light-blue-500.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('materialpulsa/css/custom.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.css">
    <style>
     
    </style>
    <?php echo $__env->yieldContent('css'); ?>
    
   </head>
   <body class="bd-scroll">
      <div class="ms-site-container">
<nav class="navbar navbar-expand-md navbar-static ms-navbar ms-navbar-primary shrink fixed-top">
   <div class="container container-full">
      <div class="navbar-header">
         <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
         <span class="ms-title">
         <img src="<?php echo e(asset('img/logo/'.$logoku[1]->img.'')); ?>" alt="" style="height: 32px;">
         </span>
         </a>
      </div>
      <div class="collapse navbar-collapse" id="ms-navbar" style="margin-right: 0px;">
          <ul class="navbar-nav">
            <li class="nav-item <?php echo e(url('/') == request()->url() ? 'active' : ''); ?>">
               <a href="<?php echo e(url('/')); ?>" class="nav-link animated fadeIn animation-delay-7">
               Home        
               </a>
            </li>
            <li class="nav-item <?php echo e(url('/cara-transaksi') == request()->url() ? 'active' : ''); ?>">
               <a href="<?php echo e(url('/cara-transaksi')); ?>" class="nav-link animated fadeIn animation-delay-7">
               Cara Transaksi
               </a>
            </li>
            <li class="nav-item <?php echo e(url('/deposit') == request()->url() ? 'active' : ''); ?>">
               <a href="<?php echo e(url('/deposit')); ?>" class="nav-link animated fadeIn animation-delay-7">
               Cara Deposit
               </a>
            </li>
            <li class="nav-item dropdown">
               <a href="#" class="nav-link dropdown-toggle animated fadeIn animation-delay-7" data-toggle="dropdown" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="false" data-name="page">Harga
               <i class="zmdi zmdi-chevron-down"></i>
               <div class="ripple-container"></div></a>
               <ul class="dropdown-menu " style="display: block;overflow-y: scroll;height: 500px;">
                    <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/price/pembelian', $data->slug)); ?>" class="dropdown-item"><i class="fa fa-<?php echo e($data->icon); ?>"></i> <?php echo e($data->product_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $KategoriPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/price/pembayaran', $data->slug)); ?>" class="dropdown-item"><i class="fa fa-<?php echo e($data->icon); ?>"></i> <?php echo e($data->product_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </li>
            <li class="nav-item <?php echo e(url('/contact') == request()->url() ? 'active' : ''); ?>">
               <a href="<?php echo e(url('/contact')); ?>" class="nav-link animated fadeIn animation-delay-7">
               Kontak Kami      
               </a>
            </li>
            
            <li class="nav-item">
               <a href="<?php echo e(url('/member')); ?>" class="nav-link animated fadeIn animation-delay-7 btn btn-raised btn-white color-primary">
               Member Area     
               </a>
            </li>
          </ul>
      </div>
      <a href="javascript:void(0)" class="ms-toggle-left btn-navbar-menu visible-xs">
      <i class="zmdi zmdi-menu"></i>
      </a>
   </div>
   <!-- container -->
</nav>     
      <?php echo $__env->yieldContent('content'); ?>
    <!-- container -->
      <aside class="ms-footbar">
        <div class="container">
          <div class="row">
            <div class="col-md-4 ms-footer-col hidden-xs">
              <div class="ms-footbar-block">
                <h3 class="ms-footbar-title">Tautan</h3>
                <ul class="list-unstyled ms-icon-list three_cols">
                  <li>
                    <a href="<?php echo e(url('/about')); ?>">
                      <i class="zmdi zmdi-edit"></i> Tentang</a>
                  </li>
                </ul>
                <ul class="list-unstyled ms-icon-list three_cols">
                  <li>
                    <a href="<?php echo e(url('/tos')); ?>">
                      <i class="zmdi zmdi-time"></i> Syarat dan Ketentuan</a>
                  </li>
                </ul>
                <ul class="list-unstyled ms-icon-list three_cols">
                  <li>
                    <a href="<?php echo e(url('/privacy-policy')); ?>">
                      <i class="zmdi zmdi-image-o"></i> Kebijakan Privasi</a>
                  </li>
                </ul>
                <ul class="list-unstyled ms-icon-list three_cols">
                  <li>
                    <a href="<?php echo e(url('/faq')); ?>">
                      <i class="zmdi zmdi-help"></i> F.A.Q</a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4 ms-footer-col ms-footer-alt-color hidden-xs">
              <div class="ms-footbar-block">
                  
                <center>
                <h3 class="ms-footbar-title">Social Media</h3>
                <div class="ms-footbar-social">
                  <a href="javascript:void(0)" class="btn-circle btn-facebook">
                    <i class="zmdi zmdi-facebook"></i>
                  </a>
                  <a href="javascript:void(0)" class="btn-circle btn-twitter">
                    <i class="zmdi zmdi-twitter"></i>
                  </a>
                  <a href="javascript:void(0)" class="btn-circle btn-google">
                    <i class="zmdi zmdi-google"></i>
                  </a>
                  <a href="javascript:void(0)" class="btn-circle btn-instagram">
                    <i class="zmdi zmdi-instagram"></i>
                  </a>
                </div>
                </center>
              </div>
            </div>
            <div class="col-md-4 ms-footer-col ms-footer-text-right">
              <div class="ms-footbar-block">
                <div class="ms-footbar-title">
                  <h3 class="no-m ms-site-title">
                   <?php echo e($GeneralSettings->nama_sistem); ?>

                  </h3>
                </div>
                <address class="no-mb">
                  <p>
                    <i class="color-danger-light zmdi zmdi-pin mr-1"></i> <?php echo e($GeneralSettings->alamat); ?>

                  </p>
                  <p>
                    <i class="color-info-light zmdi zmdi-email mr-1"></i>
                    <a href="mailto:<?php echo e($GeneralSettings->email); ?>"><?php echo e($GeneralSettings->email); ?></a>
                  </p>
                  <p>
                    <i class="color-success-light fa fa-whatsapp mr-1"></i><?php echo e($GeneralSettings->hotline); ?>

                  </p>
                </address>
              </div>
            </div>
          </div>
        </div>
      </aside>
      <footer class="ms-footer">
        <div class="container">
          <p>Copyright &copy; <?php echo e(date('Y')); ?>  <br>Dibuat dengan <i class="fa fa-heart faa-pulse animated" style="color:#f24141;"></i> oleh <a href="<?php echo e(url('/')); ?>" target="_blank"><?php echo e($GeneralSettings->nama_sistem); ?></a>.</p>
        </div>
      </footer>
      <div class="btn-back-top">
        <a href="#" data-scroll id="back-top" class="btn-circle btn-circle-primary btn-circle-sm btn-circle-raised ">
          <i class="zmdi zmdi-long-arrow-up"></i>
        </a>
      </div>    </div>
    <!-- ms-site-container -->
    <div class="ms-slidebar sb-slidebar sb-left sb-style-overlay visible-xs" id="ms-slidebar">
      <div class="sb-slidebar-container">
        <header class="ms-slidebar-header">
          <div class="ms-slidebar-login">
            <a href="<?php echo e(url('/logout')); ?>" class="withripple">
              <?php if((Auth::check())): ?>
            <a href="<?php echo e(url('/logout')); ?>" class="withripple">
                <i class="fa fa-sign-out"></i> Keluar
            </a>
              <?php else: ?>
            <a href="<?php echo e(url('/login')); ?>" class="withripple">
                <i class="fa fa-sign-in"></i> Login
            </a>
              <?php endif; ?>
          </div>
          <div class="ms-slidebar-title">
            <div class="ms-slidebar-t">
              <h3>
                <span><img src="<?php echo e(asset('img/logo/'.$logoku[0]->img.'')); ?>" alt="" style="height:32px;"></span>
              </h3>
            </div>
          </div>
        </header>
        <ul class="ms-slidebar-menu" id="slidebar-menu" role="tablist" aria-multiselectable="true">

          
          <li>
            <a class="link" href="<?php echo e(url('/')); ?>">
              <i class="fa fa-home"></i> Home</a>
          </li>
          <li>
            <a class="link" href="<?php echo e(url('cara-transaksi')); ?>">
              <i class="fa fa-question"></i> Cara Transaksi</a>
          </li>
          <li>
            <a class="link" href="<?php echo e(url('/deposit')); ?>">
              <i class="fa fa-question"></i> Cara Deposit</a>
          </li>
          <li class="card" role="tab" id="sch1">
            <a class="collapsed" role="button" data-toggle="collapse" href="#sc1" aria-expanded="false" aria-controls="sc2">
              <i class="fa fa-money"></i> Harga</a>
            <ul id="sc1" class="card-collapse collapse" role="tabpanel" aria-labelledby="sch1" data-parent="#slidebar-menu">
                    <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/price/pembelian', $data->slug)); ?>"><i class="fa fa-<?php echo e($data->icon); ?>"></i> <?php echo e($data->product_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $KategoriPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/price/pembayaran', $data->slug)); ?>"><i class="fa fa-<?php echo e($data->icon); ?>"></i> <?php echo e($data->product_name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
          <li>
            <a class="link" href="<?php echo e(url('/faq')); ?>">
              <i class="fa fa-question"></i> F.A.Q</a>
          </li>
          <li>
            <a class="link" href="<?php echo e(url('/blog')); ?>">
              <i class="fa fa-question"></i> Blog</a>
          </li>
          <li>
            <a class="link" href="<?php echo e(url('/contact')); ?>">
              <i class="fa fa-envelope-o"></i> Kontak Kami</a>
          </li>
          <li class="nav-item">
               <a href="<?php echo e(url('/member')); ?>" class="nav-link animated fadeIn animation-delay-7 btn btn-raised btn-white color-primary">
               Member Area     
               </a>
            </li>
        </ul>
      </div>
    </div>
    
    <div id="ms-preload" class="ms-preload">
      <div id="status">
        <div class="spinner">
          <div class="dot1"></div>
          <div class="dot2"></div>
        </div>
      </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('materialpulsa/js/plugins.min.js?v=1')); ?>"></script>
    <script src="<?php echo e(asset('materialpulsa/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('materialpulsa/js/notify.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('materialpulsa/js/jquery.easing.1.3.min.js')); ?>"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
	toastr.options = {
       "positionClass": "toast-bottom-right",
    }
     <?php if(Session::has('alert-success')): ?>
         toastr.success("<?php echo e(Session::get('alert-success')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-info')): ?>
         toastr.info("<?php echo e(Session::get('alert-info')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-warning')): ?>
         toastr.warning("<?php echo e(Session::get('alert-warning')); ?>");
     <?php endif; ?>

     <?php if(Session::has('alert-error')): ?>
         toastr.error("<?php echo e(Session::get('alert-error')); ?>");
     <?php endif; ?>
	</script>
    <?php echo $__env->yieldContent('js'); ?>
  </body>
</html><?php /**PATH /home/u1322614/system/resources/views/layouts/app.blade.php ENDPATH**/ ?>