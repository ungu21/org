

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Pembelian <small>Produk (Level Personal)</small></h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="Javascript:;">Pembelian</a></li>
    	<li class="active">Produk (Level Personal)</li>
    </ol>
</section>
<section class="content">
    <div class="row hidden-xs hidden-sm">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Data Produk (Level Personal)</h3><button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" style="padding: 3px 7px;margin-left:5px;"><i class="fa fa-trash"></i><span class="hidden-xs hidden-sm"> Hapus Semua Data Produk</span></button>
                </div><!-- /.box-header -->
                <div style="text-align: center;margin: 5px;">
                    <div id="desktop" class="hidden-xs hidden-sm">
                        <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/admin/pembelian-produk/markup/role-personal', $data->slug)); ?>" class="btn-loading btn btn-primary <?php echo e(url('/admin/pembelian-produk/markup/role-personal', $data->slug) == request()->url() ? 'active' : ''); ?>" style="padding: 3px 7px;margin: 2px"><?php echo e($data->product_name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="box-body table-responsive no-padding">
                    
                    <table id="DataTable" class="table table-hover" style="margin-bottom:20px;">
                        <thead>
                            <tr class="custom__text-green">
                                <th>ID</th>
                                <th>ID Server</th>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Update Terakhir</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; ?>
                            <?php if(count($produksWeb) > 0): ?>
                            <?php $__currentLoopData = $produksWeb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="font-size: 13px;">
                                <td>#<?php echo e($produk->id); ?></td>
                                <td>#<?php echo e($produk->product_id); ?></td>
                                <td><?php echo e($produk->product_name); ?></td>
                                <td>Rp. <?php echo e(number_format($produk->price, 0, '.', '.')); ?></td>
                                <td><?php echo e($produk->updated_at); ?></td>
                                <?php if($produk->status == 1): ?>
                                <td><label class="label label-success">Tersedia</label></td>
                                <?php else: ?>
                                <td><label class="label label-danger">Gangguan</label></td>
                                <?php endif; ?>
                                <td>
                                    <form method="POST" action="<?php echo e(route('admin.produkPersonal.delete', $produk->id)); ?>" accept-charset="UTF-8">
                                        <input name="_method" type="hidden" value="DELETE">
                                        <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
                                        <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin akan menghapus data ?');" type="submit" style="padding: 2px 5px;"><i class="fa fa-trash"></i></button>
                                     </form>
                               </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="6" style="font-style:italic;text-align:center;background-color:#F3F3F3;">Data Produk tidak ditemukan</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div><!-- /.box-body -->
            </div><!-- /.box -->
        </div>
    </div>
    <div class="row hidden-lg hidden-md">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title"><a href="<?php echo e(url('/admin')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Data Produk</h3><button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal" data-backdrop="static" data-keyboard="false" style="padding: 3px 7px;margin-left:5px;"><i class="fa fa-trash"></i><span class="hidden-xs hidden-sm"> Hapus Semua Data Produk</span></button>
                </div><!-- /.box-header -->
                <div style="text-align: center;margin-bottom: 10px;margin-top: 10px;">
                    <div id="mobile" class="hidden-lg hidden-md">
                        <?php $__currentLoopData = $KategoriPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/admin/pembelian-produk/markup/role-personal', $data->slug)); ?>" class="btn-loading btn btn-primary <?php echo e(url('/admin/pembelian-produk/markup/role-personal', $data->slug) == request()->url() ? 'active' : ''); ?>" style="width:30px;padding: 3px 7px;"><i class="fa fa-<?php echo e($data->icon); ?>"></i><span class="hidden-xs hidden-sm" style="margin-left:5px;"><?php echo e($data->product_name); ?></span></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="box-body" style="padding: 0px">
                    <table class="table table-hover">
                        <?php if($produksMobile->count() > 0): ?>
                        <?php $__currentLoopData = $produksMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div><small>ID : #<?php echo e($data->id); ?></small></div>
                                <div style="font-size: 14px;font-weight: bold;"><?php echo e($data->pembelianoperator->product_name); ?> - <?php echo e($data->product_name); ?></div>
                                <div><?php echo e($data->pembeliankategori->product_name); ?></div>
                            </td>
                            <td align="right" style="width:35%;">
                                <div><small>ID Product : #<?php echo e($data->product_id); ?></small></div>
                                <div><div>Rp <?php echo e(number_format($data->price, 0, '.', '.')); ?></div></div>
                                <?php if($data->status == 1): ?>
                                <div><span class="label label-success">Tersedia</span></div>
                                <?php else: ?>
                                <div><span class="label label-danger">Gangguan</span></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td class="colspan" style="text-align:center;font-style:italic;">produk tidak tersedia</td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div><!-- /.box-body -->
                <div class="box-footer" align="center" style="padding-top:13px;">
                   <?php echo $__env->make('pagination.default', ['paginator' => $produksMobile], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
            </div><!-- /.box -->
        </div>
   </div>
</section>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Hapus Semua Produk Operator</h4>
            </div>
            <div class="modal-body" style="text-align:center;">
                <div id="body">
                    <p>Apakah anda yakin ingin menghapus semua data produk dari semua operator yang tersedia?</p>
                    <p style="font-style:italic;"><small>Tindakan tersebut akan mengosongkan semua data produk dalam database, tetapi anda dapat mengisinya kembali dengan cara update produk yang terdapat dalam halaman produk.</small></p>
                </div>
            </div>
            <div class="modal-footer" style="text-align:center;">
                <button type="button" class="btn btn-primary" id="proses">Kosongkan Sekarang</button>
            </div>
        </div>
     </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(function () {
       $('#DataTable').DataTable({
         "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
         "iDisplayLength": 50,
         "searching": false,
         "lengthChange": false,
         "info": false,
         "order": [[ 0, "asc" ]]
       });
    });
    function loading() {
        $('#body').html('<div class="text-center" style="margin-top: 20px; margin-bottom:20px;"><i class="fa fa-spinner fa-2x faa-spin animated"></i></div>');
    }
    $('#proses').on('click', function(){
        loading();
        $('#proses').attr('disabled', true);
        $('#proses').text('Loading...');
         
        $.ajax({
            url: '/admin/pembelian-produk/markup/role-personal/delete',
            type: "post",
            data: {
                '_token': '<?php echo e(csrf_token()); ?>',
            },
            
            success: function(data){
                location.reload();
            }
        });     
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mydn5829/system/resources/views/admin/markup/pembelian/personal/index.blade.php ENDPATH**/ ?>