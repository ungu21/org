<?php $__env->startSection('title', 'Tentang Kami | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Tentang Kami
          </h1>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                <h3 class="color-primary text-center mb-4"><?php echo e($GeneralSettings->nama_sistem); ?></h3>
                     <div class="content-page">
                        <p>
                            <?php
                                $content = html_entity_decode($page->content, ENT_QUOTES);
                                $content = str_replace('[site_name]', $GeneralSettings->nama_sistem, $content);
                                $content = str_replace('[site_url]', url('/'), $content);
                                $content = str_replace('[site_motto]', $GeneralSettings->motto, $content);
                            ?>
                            <?php echo $content; ?>

                        </p>
                    <div>
                     <h2 class="page-title">Alamat</h2>
                     <div class="content-page">
                        <div>
                          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3955.9194281190335!2d111.20824181479921!3d-7.474149775761955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e79f0dde501d6bd%3A0xc80b3c36c5b959d9!2sP-Store.Net!5e0!3m2!1sen!2sid!4v1533763701346" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                        </div>
                     </div>
                  </div>
                     </div>
                </div>
            </div> 
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/about.blade.php ENDPATH**/ ?>