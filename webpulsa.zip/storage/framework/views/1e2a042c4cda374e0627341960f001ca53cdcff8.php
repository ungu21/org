

<?php $__env->startSection('style'); ?>
   <!-- fancy box -->
   <link rel="stylesheet" type="text/css" media="screen" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css" />
   <style type="text/css">
       a.fancybox img {
           border: none;
           box-shadow: 0 1px 7px rgba(0,0,0,0.6);
           -o-transform: scale(1,1); -ms-transform: scale(1,1); -moz-transform: scale(1,1); -webkit-transform: scale(1,1); transform: scale(1,1); -o-transition: all 0.2s ease-in-out; -ms-transition: all 0.2s ease-in-out; -moz-transition: all 0.2s ease-in-out; -webkit-transition: all 0.2s ease-in-out; transition: all 0.2s ease-in-out;
       } 
       a.fancybox:hover img {
           position: relative; z-index: 999; -o-transform: scale(1.03,1.03); -ms-transform: scale(1.03,1.03); -moz-transform: scale(1.03,1.03); -webkit-transform: scale(1.03,1.03); transform: scale(1.03,1.03);
       }
   </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
    <h1>Detail <small>Validasi</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?php echo e(url('/admin/validasi-users')); ?>" class="btn-loading"> Detail Validasi Users</a></li>
        <li class="active">Detail Validasi #<?php echo e($data->id); ?></li>
   </ol>
</section>
   <section class="content">
      <div class="row">
         <div class="col-md-12">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(url('/admin/validasi-users')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Detail Validasi</h3>
               </div>
               <div class="box-body">
                <table class="table" style="font-size:14px;">
                     <tr>
                        <td>ID Validasi</td>
                        <td>:</td>
                        <td>#<?php echo e($data->id); ?></td>
                     </tr>
                     <tr>
                        <td>Name</td>
                        <td>:</td>
                        <td><?php echo e($data->name); ?></td>
                     </tr>
                     <tr>
                        <td>Email User</td>
                        <td>:</td>
                        <td><?php echo e($data->email); ?></td>
                     </tr>
                     <tr>
                        <td>Phone</td>
                        <td>:</td>
                        <td><?php echo e($data->phone); ?></td>
                     </tr>
                     <tr>
                        <td>Tanggal</td>
                        <td>:</td>
                        <td><?php echo e(date("d M Y H:m:s", strtotime($data->created_at))); ?></td>
                     </tr>
                     <tr>
                        <td>Status</td>
                        <td>:</td>
                         <?php if($data->status == 0): ?>
                         <td><span class="label label-warning">MENUNGGU</span></td>
                         <?php else: ?>
                         <td><span class="label label-success">TERVALIDASI</span></td>
                         <?php endif; ?>
                     </tr>
                  </table>
               </div>
               <div class="box-footer">
                    <div class="row">
                        <div class="col-md-6" style="margin-bottom:8px;">
                            <a href="<?php echo e(url('/admin/validasi-users/approve', $data->id)); ?>" class="btn-loading btn btn-success btn-sm btn-block" onclick="return confirm('Anda yakin validasi akan di APPROVE ?');"><i class="fa fa-exclamation-circle"></i> APPROVE</a>
                        </div>
                        <div class="col-md-6" style="margin-bottom:8px;">
                            <a href="<?php echo e(url('/admin/validasi-users/nonapprove', $data->id)); ?>" class="btn-loading btn btn-danger btn-sm btn-block" onclick="return confirm('Anda yakin validasi akan di CENCEL DAN DIHAPUS ?');"><i class="fa fa-trash"></i> NON APPROVE</a>
                        </div>
                    </div>
               </div>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-md-4">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(url('/admin/validasi-users')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Foto KTP</h3>
               </div>
               <div class="box-body">
                    <img class="fancybox" src="<?php echo e(asset('/img/validation/ktp/'.$data->img_ktp)); ?>" height="250" width="325;">
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(url('/admin/validasi-users')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Foto SELFIE</h3>
               </div>
               <div class="box-body">
                    <img class="fancybox" src="<?php echo e(asset('/img/validation/selfie/'.$data->img_selfie)); ?>" height="250" width="325;">
               </div>
            </div>
         </div>
         
         <?php if(!empty($data->img_tabungan)): ?>
         <div class="col-md-4">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(url('/admin/validasi-users')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Foto Tabungan</h3>
               </div>
               <div class="box-body">
                    <img class="fancybox" src="<?php echo e(asset('/img/validation/tabungan/'.$data->img_tabungan)); ?>" height="250" width="325;">
               </div>
            </div>
         </div>
         <?php endif; ?>
         
      </div>
   </section>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   $(function($){
       var addToAll = false;
       var gallery = true;
       var titlePosition = 'inside';
       $(addToAll ? 'img' : 'img.fancybox').each(function(){
           var $this = $(this);
           var title = $this.attr('title');
           var src = $this.attr('data-big') || $this.attr('src');
           var a = $('<a href="#" class="fancybox"></a>').attr('href', src).attr('title', title);
           $this.wrap(a);
       });
       if (gallery)
           $('a.fancybox').attr('rel', 'fancyboxgallery');
       $('a.fancybox').fancybox({
           titlePosition: titlePosition
       });
   });
   $.noConflict();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/admin/validasi_user/show.blade.php ENDPATH**/ ?>