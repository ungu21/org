<?php $__env->startSection('title', 'Harga Produk | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', 'Harga Produk Termurah & Terlengkap '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Slideshow Section -->
<section class="pembayaran list-item-transaction">
  <section id="slideshow">
      <div class="container">
          <div class="row">
              <div class="no-slider" style="margin-top: 100px;">
                  <div class="animate-block" style="text-align: center;">
                      <div class="col-md-6 col-md-offset-3">
                          <h2><span id="word-rotating">Pulsa All Operator, Paket Internet, Voucher Game, Token PLN, Pembayaran PPOB</span></h2>
                          <p style="margin-top: 10px;margin-bottom: 80px;">Produk Terlengkap & Termurah Kami</p>
                      </div>
                  </div> <!--/ animate-block -->
                  <div class="clearfix"></div>
              </div>
          </div>
      </div>
  </section>
</section>
<!-- End Slideshow Section -->
<!-- Start Feature Section -->
<!-- <section class="pembayaran list-item-transaction"> -->
    <div class="container">
        <div class="row static-page">
            <div class="col-md-12" style="margin-bottom: 30px;">
                <div class="section-heading text-center" style="margin-bottom: 30px;">
                    <h2 class="title">Harga <?php echo e($kategoris->product_name); ?></h2>
                    <p>Harga Produk Terbaik Kami<br>Update <?php echo e(date("d-m-Y")); ?></p>
                </div>
            </div>
            <!-- Nav tabs -->
            <div class="col-md-12" style="margin-bottom:50px;">
                <?php $__currentLoopData = $kategoris->pembelianoperator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 style="font-size: 20px;"><?php echo e($operator->product_name); ?></h3>
                <table class="table table-striped table-bordered table-condensed" style="font-size: 15px;margin-bottom: 50px;">
                    <thead>
                        <tr align="center">
                            <th>Kode</th>
                            <th>Produk & Nominal</th>
                            <th class="text-right">Harga (<small class="text-danger">Personal</small>)</th>
                            <th class="text-right">Harga (<small class="text-danger">Agen</small>)</th>
                            <th class="text-right">Harga (<small class="text-danger">Enterprise</small>)</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody align="left">
                        <?php if(count($operator->pembelianproduk) > 0): ?>
                        <?php $__currentLoopData = $operator->pembelianproduk->sortBy('price_default'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($produk->product_id); ?></td>
                            <td><?php echo e($produk->product_name); ?></td>
                            <td class="text-right">Rp <?php echo e(number_format($produk->V_pembelianproduk_personal->price, 0, '.', '.')); ?></td>
                            <td class="text-right">Rp <?php echo e(number_format($produk->V_pembelianproduk_agen->price, 0, '.', '.')); ?></td>
                            <td class="text-right">Rp <?php echo e(number_format($produk->V_pembelianproduk_enterprise->price, 0, '.', '.')); ?></td>
                            <?php if($produk->status == 1): ?>
                            <td><p class="text-center"><span class="label label-success">TERSEDIA</span></p></td>
                            <?php else: ?>
                            <td><p class="text-center"><span class="label label-danger">GANGGUAN</span></p></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="3" align="center" style="font-style: italic;">Produk Belum Tersedia</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<!-- </section> -->
<!-- End Feature Section -->


   <section class="download-separator hidden-xs">&nbsp;</section>
   <section id="download" class="download">
      <div class="container">
         <div class="download-text">
            <p class="title">Download Aplikasi <?php echo e($GeneralSettings->nama_sistem); ?></p>
            <!-- <p><?php echo e($GeneralSettings->motto); ?></p> -->
            <div><a href="https://play.google.com/store/apps/details?id=apps.tripay.co.id" class="download-link googleplay">&nbsp;</a></div>
            <h2 class="title" style="font-style: italic;"><p>"<?php echo e($GeneralSettings->motto); ?>"</p></h2>
         </div>
         <div class="download-img hidden-xs">&nbsp;</div>
      </div>
   </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webpulsa baru\produk1\resources\views/price-pembelian.blade.php ENDPATH**/ ?>