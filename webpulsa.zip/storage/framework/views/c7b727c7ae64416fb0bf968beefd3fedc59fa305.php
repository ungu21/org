<?php $__env->startSection('title', 'Harga Produk | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>
<?php $__env->startSection('css'); ?>
<style>
    @media(max-width: 576px){
        .hidden-mobile{
            display:none;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Harga <?php echo e($kategoris->product_name); ?>

          </h1>
          <p style="color:#fff">Harga Produk Terbaik Kami<br>Update <?php echo e(date("d-m-Y")); ?></p>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                    <div class="col-md-12 hidden-mobile" style="margin-bottom:50px;">
                        <?php $__currentLoopData = $kategoris->pembelianoperator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h3 style="font-size: 20px;"><?php echo e($operator->product_name); ?></h3>
                        <table class="table table-striped table-bordered table-condensed" style="font-size: 15px;margin-bottom: 50px;">
                            <thead>
                                <tr align="center">
                                    <th>Kode</th>
                                    <th>Produk & Nominal</th>
                                    <th class="text-right">Harga (<small class="text-danger">Personal</small>)</th>
                                    <th class="text-right">Harga (<small class="text-danger">Agen</small>)</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody align="left">
                                <?php if(count($operator->pembelianproduk) > 0): ?>
                                <?php $__currentLoopData = $operator->pembelianproduk->sortBy('price_default'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($produk->product_id); ?></td>
                                    <td><?php echo e($produk->product_name); ?></td>
                                    <td class="text-right">Rp <?php echo e(number_format($produk->V_pembelianproduk_personal->price, 0, '.', '.')); ?></td>
                                    <td class="text-right">Rp <?php echo e(number_format($produk->V_pembelianproduk_agen->price, 0, '.', '.')); ?></td>
                                    <?php if($produk->status == 1): ?>
                                    <td><p class="text-center"><span class="label label-success">TERSEDIA</span></p></td>
                                    <?php else: ?>
                                    <td><p class="text-center"><span class="label label-danger">GANGGUAN</span></p></td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="3" align="center" style="font-style: italic;">Produk Belum Tersedia</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                     <div class="row hidden-lg hidden-md">
                        <div class="col-md-12">
                            <div class="box">
                                <div class="box-header">
                                    <h3 class="box-title" style="font-size:18px;"><a href="<?php echo e(url('/member')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a><?php echo e($kategoris->product_name); ?></h3>
                                </div><!-- /.box-header -->
                                <?php $__currentLoopData = $kategoris->pembelianoperator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4 style="font-weight: bold;text-align: center;"><?php echo e($data->product_name); ?></h4>
                                <div class="box-body" style="padding: 0px">
                                    <table class="table table-hover">
                                        <?php if(count($data->pembelianproduk) > 0): ?>
                                        <?php $__currentLoopData = $data->pembelianproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div><?php echo e($produk->product_id); ?></div>
                                                <div style="font-size: 14px;font-weight: bold;"><?php echo e($produk->product_name); ?></div>
                                                <div>Harga - (<?php echo e(price(optional($produk->V_pembelianproduk_personal)->price)); ?>)</div>
                                                <div>Harga Agen - (<?php echo e(price(optional($produk->V_pembelianproduk_agen)->price)); ?>)</div>
                                            </td>
                                            <td align="right" style="width:25%;">
                                                <?php if($produk->status == 1): ?>
                                                <div><span class="badge badge-success">Tersedia</span></div>
                                                <?php else: ?>
                                                <div><span class="badge badge-danger">Gangguan</span></div>
                                                <?php endif; ?>
                                                <div style="visibility: hidden;">text</div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td class="colspan" style="text-align:center;font-style:italic;">produk tidak tersedia</td>
                                        </tr>
                                        <?php endif; ?>
                                    </table>
                                </div><!-- /.box-body -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- /.box -->
                        </div>
                    </div>
                </div>
            </div> 
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/price-pembelian.blade.php ENDPATH**/ ?>