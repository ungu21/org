
<?php $__env->startSection('style'); ?>
<style>
     .verification-otp{
            font-size: 14px;
            color: #8799AD;
            text-align: left !important;
            margin-top: 0.5rem;
        }

        .verification-otp a{
            color: #0CB4FF !important;
            cursor: pointer;
        }

        .verification-otp a:hover{
            color: #0083BC !important;
        }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="login-logo">
        <a href="#"><img src="<?php echo e(asset('img/logo/'.$logoku[1]->img.'')); ?>" style="max-width:150px"></a>
    </div><!-- /.login-logo -->
    <div class="login-box-body">
        
         <?php if(Session::has('alert-success')): ?>
            <div class="alert alert-success alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
               <h4><i class="fa fa-check"></i>Berhasil</h4>
               <p><?php echo Session::get('alert-success'); ?></p>
            </div>
          <?php endif; ?>
         <?php if(Session::has('alert-error')): ?>
            <div class="alert alert-danger alert-dismissable">
               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
               <h4><i class="fa fa-check"></i>Error</h4>
               <p><?php echo Session::get('alert-error'); ?></p>
            </div>
          <?php endif; ?>
          
        <form action="<?php echo e(url('/cek_otp')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

           <input type="hidden" name="id" value="<?php echo e(session('otp_id')); ?>">
            <div class="form-group has-feedback <?php echo e($errors->has('kode_otp') ? ' has-error' : ''); ?>">
                <input type="number" name="kode_otp" class="form-control" value="" placeholder="Masukan Kode OTP" autocomplete="off">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <?php echo $errors->first('kode_otp', '<p class="help-block"><small>:message</small></p>'); ?>

            </div>
            <div class="form-group">
                <button type="submit" class="submit btn btn-primary btn-block btn-flat">Submit</button>
            </div>

            <div class="verification-otp">
                <?php if(session('countDown') > time()): ?>
                <span id="countDown" class="text__countDown"><?php echo e(gmdate('i:s', session('countDown') - time())); ?></span>
                <?php else: ?>
                    <span id="resend_text">Belum menerima Kode OTP ?</span>
                    <a onclick="resend()" id="resend">Kirim Ulang</a>
                <?php endif; ?>
            </div>
        </form>

    </div><!-- /.login-box-body -->
</div><!-- /.login-box -->
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('js'); ?>
<script>
    function startTimer(duration, display){
        console.log(duration);
        var timer = duration, minutes, seconds;
        setInterval(function(){
            minutes = parseInt(timer / 60, 10);
            seconds = parseInt(timer % 60, 10);

            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            display.textContent = minutes + ":" + seconds;

            if(--timer < 0){
                timer = duration;
                console.log(timer);
                $('#resend_text').remove();
                $('#resend').remove();
                $('#countDown').remove();
                $('.verification-otp').append('<span id="resend_text">Belum menerima kode otp ? </span><a onclick="resend()" id="resend">Kirim Ulang</a>');
            }
        }, 1000);
    }

    window.onload = function(){
        var twoMinutes = <?php echo e(session('countDown') - time()); ?>

            display = document.querySelector('#countDown');
        startTimer(twoMinutes, display);
    };

    function resend(){
        var form = '<form action="<?php echo e(url('/create_otp')); ?>" method="post" id="formResend">';
            form += '<input type="hidden" name="_token" value="' + $('meta[name="csrf-token"]').attr('content') + '">';
            form += '<input type="hidden" name="id" value="<?php echo e(session('otp_id')); ?>">';
            form += '<input type="hidden" name="is_resend" value="1">';
            form += '</form>';

            $('body').append(form);

            $form = $("#formResend");
            $form.submit();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/auth/otp.blade.php ENDPATH**/ ?>