

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
	<h1>Transaksi <small>Redeem Voucher</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
    	<li><a href="#">Transaksi</a></li>
 	    <li><a href="<?php echo e(url('/admin/transaksi/redeem')); ?>">Data Redeem Voucher</a></li>
    	<li class="active">Detail Data Redeem #<?php echo e($redeem->id); ?></li>
   </ol>
   </section>
   <section class="content">
      <div class="row">
         <div class="col-md-12">
            <div class="box box-default">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(url('/admin/transaksi/redeem')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Detail Redeem Voucher</h3>
               </div>
               <div class="box-body">
                  <table class="table" style="font-size:13px;">
                     <tr>
                        <td width="40%">ID Redeem</td>
                        <td width="5%">:</td>
                        <td>#<?php echo e($redeem->id); ?></td>
                     </tr>
                     <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td><?php echo e($redeem->user->name); ?></td>
                     </tr>
                     <tr>
                        <td>Kode Voucher</td>
                        <td>:</td>
                        <td><?php echo e($redeem->voucher->code); ?></td>
                     </tr>
                     <tr>
                        <td>Bonus Redeem (Rp)</td>
                        <td>:</td>
                        <td>Rp <?php echo e(number_format($redeem->voucher->bonus, 0, '.', '.')); ?></td>
                     </tr>
                     <tr>
                        <td>Tanggal Redeem</td>
                        <td>:</td>
                        <td><?php echo e($redeem->created_at); ?></td>
                     </tr>
                     
                  </table>
               </div>
            </div>
         </div>
      </div>
   </section>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/admin/transaksi/redeem/show.blade.php ENDPATH**/ ?>