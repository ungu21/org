
<?php $__env->startSection('title', 'FAQ | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', 'FAQ kumpulan pertanyaan yang sering di tanyakan pada '.$GeneralSettings->nama_sistem.'. '.$GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa, Cara Transaksi, Jalur Transaksi, API, H2H', 'Website'); ?>
<?php $__env->startSection('img', asset('assets/images/banner_1.png')); ?>

<?php $__env->startSection('content'); ?>
<!-- Start Slideshow Section -->
<section id="slideshow">
   <div class="container">
      <div class="row">
         <div class="no-slider" style="margin-top: 100px;">
            <div class="animate-block" style="text-align: center;">
            <div class="col-md-6 col-md-offset-3">
               <h1><span id="word-rotating">FAQ</span></h1>
               <p style="margin-top: 10px;margin-bottom: 80px;">Hal yang sering ditanyakan</p>
              </div>
            </div> <!--/ animate-block -->
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
</section>
<!-- End Slideshow Section -->

<!-- Start FAQ Section -->
<section id="faq" class="grey-bg padding-2x">
   <div class="container">
      <div class="row">
         <?php if($faqs->count() > 0): ?>
         <?php $__currentLoopData = array_chunk($faqs->all(), 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-sm-6">
            <!-- Start FAQ Block -->
            <div id="accordion" class="faq-block">
            <?php $__currentLoopData = $col; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            
               <div class="panel accordion-panel">
                  <h4 class="faq-heading">
                     <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#<?php echo e(str_slug($data->pertanyaan, '-')); ?>" aria-expanded="false">Q : <?php echo e($data->pertanyaan); ?></a>
                  </h4>
                  <div id="<?php echo e(str_slug($data->pertanyaan, '-')); ?>" class="accordion-body collapse">
                     <p><?php echo e($data->jawaban); ?></p>
                  </div>
               </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!-- End FAQ Block -->
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
         <div align="center">
            <i class="fa fa-frown-o fa-5x"></i>
            <h3>Belum ada FAQ</h3>
            <small>Jadilah yang pertama memberikan pertanyaan seputar sistem kami</small>
         </div>
         <?php endif; ?>
      </div>
   </div>
</section>
<!-- End FAQ Section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/produk3/resources/views/faq.blade.php ENDPATH**/ ?>