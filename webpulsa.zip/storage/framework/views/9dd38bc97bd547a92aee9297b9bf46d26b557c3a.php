<?php $__env->startSection('title', 'Terms Of Service | '.$GeneralSettings->nama_sistem.' - '.$GeneralSettings->motto); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>

<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Terms Of Service
          </h1>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
                <div class="card-body">
                <h3 class="color-primary text-center mb-4">Ketentuan Layanan</h3>
                     <div class="content-page">
                        <div>
                           Syarat & ketentuan yang ditetapkan di bawah ini mengatur pemakaian jasa yang ditawarkan oleh <?php echo e($GeneralSettings->nama_sistem); ?> terkait penggunaan situs <?php echo e($GeneralSettings->nama_sistem); ?>. Pengguna disarankan membaca dengan seksama karena dapat berdampak kepada hak dan kewajiban Pengguna di bawah hukum.
                        </div>
                        <div>
                           Dengan mendaftar dan/atau menggunakan situs <?php echo e($GeneralSettings->website); ?>, maka pengguna dianggap telah membaca, mengerti, memahami dan menyutujui semua isi dalam Syarat & ketentuan. Syarat & ketentuan ini merupakan bentuk kesepakatan yang dituangkan dalam sebuah perjanjian yang sah antara Pengguna dengan <?php echo e($GeneralSettings->nama_sistem); ?>. Jika pengguna tidak menyetujui salah satu, sebagian, atau seluruh isi Syarat & ketentuan, maka pengguna tidak diperkenankan menggunakan layanan di <?php echo e($GeneralSettings->website); ?>.
                        </div>
                        <div>
                                 <?php $__currentLoopData = $tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h2 id="<?php echo e($data->slug); ?>"><strong style="text-transform: capitalize;"><?php echo e($data->title); ?></strong></h2>
                                    <?php echo $data->content; ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                     </div>
                </div>
            </div> 
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1322614/system/resources/views/tos.blade.php ENDPATH**/ ?>