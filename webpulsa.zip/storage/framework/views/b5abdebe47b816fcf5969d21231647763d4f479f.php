<?php $__env->startSection('title', 'Deposit Saldo | '.$GeneralSettings->nama_sistem); ?>
<?php $__env->startSection('description', $GeneralSettings->description); ?>
<?php $__env->startSection('keywords', 'Distributor, Distributor Pulsa, Pulsa, Server Pulsa, Pulsa H2H, Pulsa Murah, distributor pulsa elektrik termurah dan terpercaya, Pulsa Isi Ulang, Pulsa Elektrik, Pulsa Data, Pulsa Internet, Voucher Game, Game Online, Token Listrik, Token PLN, Pascaprabayar, Prabayar, PPOB, Server Pulsa Terpercaya, Bisnis Pulsa Terpercaya, Bisnis Pulsa termurah, website pulsa'); ?>
<?php $__env->startSection('css'); ?>
<style>
    .card-payment{
      margin-left:15px;
      border-radius: 8px;
      border: none;
   }
   .payment-card{
      padding: 1rem;
      text-align: center !important;
   }
   
   .card-payment > .payment-card{
      width: 150px; 
      height: 73px;
      box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      -webkit-box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      -moz-box-shadow: 0px 4px 24px 0px rgba(16,16,16,0.08) !important;
      border: none;
      border-radius: 8px;
   }
   
   .card-payment > .payment-card:hover{
      width: 150px; 
      height: 73px;
      box-shadow: 0px 8px 24px 0px var(--custom-color) !important;
      -webkit-box-shadow: 0px 8px 24px 0px var(--custom-color-hover) !important;
      -moz-box-shadow: 0px 8px 24px 0px var(--custom-color-hover) !important;
      border: solid 1px var(--custom-color);
      border-radius: 8px;
   }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="ms-hero-page-override ms-hero-img-city2 ms-hero-bg-info">
    <div class="container">
       <div class="text-center">
          <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Cara Deposit Saldo
          </h1>
          <p style="color: #fff">Setelah Mendaftar menjadi agen pulsa kami, langkah selanjutnya adalah deposit pulsa / menambah saldo agar dapat digunakan untuk transaksi semua produk terlengkap dari TriPay.</p>
       </div>
    </div>
 </div>
          <div class="container">
            <div class="card card-hero animated slideInUp animation-delay-8 mb-6">
               <div class="card-body">
                <h3 class="color-primary text-center mb-4">Tidak Ada Minimal Deposit</h3>
                  <div class="row">
                     <div class="col-sm-4 col-md-4">
                        <!-- Start User Friendly Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-edit color-warning"></i>
                           </div>
                           <h3>Request Deposit</h3>
                           <p>PLangkah pertama, lakukan request deposit pada halaman member dengan memilih menu DEPOSIT SALDO lalu memilih bank serta nominal deposit yang diinginkan dan sistem akan menampilkan detail deposit anda, berupa Nominal Transfer & Bank tujuan.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                     <div class="col-sm-4 col-md-4">
                        <!-- Start Supper Fast Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-plane color-primary"></i>
                           </div>
                           <h3>Transfer Pembayaran</h3>
                           <p>Langkah kedua, anda akan di minta untuk melakukan transfer sejumlah nominal transfer yang tertera pada detail deposit, nominal transfer memiliki 3 angka unik di belakang sehingga disarankan untuk transfer pembayaran sesuai nominal transfer yang tertera.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                     <div class="col-sm-4 col-md-4">
                        <!-- Start Analytics Block -->
                        <div class="box-content text-center">
                           <div class="block-icon">
                              <i class="fa fa-3x fa-check-circle color-success"></i>
                           </div>
                           <h3>Konfirmasi Pembayaran</h3>
                           <p>Langkah terakhir, konfirmasi pembayaran anda dengan cara menghubungi CS kami untuk segera diproses, Saldo anda akan bertambah setelah kami memverifikasi pembayaran anda. Disarankan untuk melakukan Deposit Saldo pada jam kerja TriPay.</p>
                        </div>
                        <!-- End Block -->
                     </div>
                  </div>
                <hr>
               
                      <div class="offset-1 col-sm-10 col-md-10 text-center" style="margin-top:20px">
               <h3>Jadwal Offline Bank</h3>
               <p>Deposit pulsa murah dapat dilakukan selama 24 jam selama bank tidak maintenance. Namun layanan internet banking dari Bank BCA, BNI, Mandiri, BRI, dan Muamalat pada jam-jam tertentu pasti Offline / Maintenance setiap harinya. Tidak ada jadwal yang resmi dari bank kapan akan melakukan maintenance, Namun rata-rata Bank Offline antara jam 21:00 - 00:00 WIB. Sehingga transfer deposit yang dilakukan pada saat bank offline akan diproses setelah bank kembali normal.</p>
           </div>
                </div>
              </div>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/newpay/resources/views/deposit.blade.php ENDPATH**/ ?>